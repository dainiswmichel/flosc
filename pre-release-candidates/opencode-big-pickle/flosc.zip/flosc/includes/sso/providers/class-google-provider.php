<?php
/**
 * Google SSO Provider
 *
 * Implements Google OAuth2 login for FLOSC.
 *
 * @package FLOSC
 * @subpackage SSO\Providers
 * @since 1.4.0
 */

namespace FLOSC\SSO\Providers;

use FLOSC\SSO\SSO_Provider_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Google Provider Class
 */
class Google_Provider extends SSO_Provider_Base {

	/**
	 * Constructor
	 */
	public function __construct() {
		$this->provider_id   = 'google';
		$this->provider_name = 'Google';
		$this->provider_icon = '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 48 48"><path fill="#FFC107" d="M43.611,20.083H42V20H24v8h11.303c-1.649,4.657-6.08,8-11.303,8c-6.627,0-12-5.373-12-12c0-6.627,5.373-12,12-12c3.059,0,5.842,1.154,7.961,3.039l5.657-5.657C34.046,6.053,29.268,4,24,4C12.955,4,4,12.955,4,24c0,11.045,8.955,20,20,20c11.045,0,20-8.955,20-20C44,22.659,43.862,21.35,43.611,20.083z"/><path fill="#FF3D00" d="M6.306,14.691l6.571,4.819C14.655,15.108,18.961,12,24,12c3.059,0,5.842,1.154,7.961,3.039l5.657-5.657C34.046,6.053,29.268,4,24,4C16.318,4,9.656,8.337,6.306,14.691z"/><path fill="#4CAF50" d="M24,44c5.166,0,9.86-1.977,13.409-5.192l-6.19-5.238C29.211,35.091,26.715,36,24,36c-5.202,0-9.619-3.317-11.283-7.946l-6.522,5.025C9.505,39.556,16.227,44,24,44z"/><path fill="#1976D2" d="M43.611,20.083H42V20H24v8h11.303c-0.792,2.237-2.231,4.166-4.087,5.571c0.001-0.001,0.002-0.001,0.003-0.002l6.19,5.238C36.971,39.205,44,34,44,24C44,22.659,43.862,21.35,43.611,20.083z"/></svg>';

		$this->auth_url  = 'https://accounts.google.com/o/oauth2/v2/auth';
		$this->token_url = 'https://oauth2.googleapis.com/token';
		// v1.4.6: Use v2 userinfo endpoint (aligned with BuddyBoss proven implementation)
		$this->user_info_url = 'https://www.googleapis.com/oauth2/v2/userinfo';

		// v1.4.6: Scopes aligned with BuddyBoss (email + profile)
		$this->scopes = array(
			'email',
			'profile',
		);

		parent::__construct();
	}

	/**
	 * Customize authorization parameters for Google
	 *
	 * @param array $params Default parameters
	 * @return array Modified parameters
	 */
	protected function customize_auth_params( $params ) {
		// Add Google-specific parameters
		$params['access_type']   = 'offline';  // Get refresh token
		$params['prompt']        = 'select_account'; // Always show account selector
		$params['response_mode'] = 'form_post'; // Deliver code/state via POST callback

		return $params;
	}

	/**
	 * Get user info from Google
	 * v1.4.6: Override to request explicit fields (BuddyBoss pattern)
	 *
	 * @param string $access_token OAuth access token
	 * @return array|\WP_Error User data or error
	 */
	public function get_user_info( $access_token, $token_data = array() ) {
		$url = add_query_arg(
			array(
				'fields' => 'id,name,email,family_name,given_name,picture',
				'alt'    => 'json',
			),
			$this->user_info_url
		);

		$response = wp_remote_get(
			$url,
			array(
				'timeout' => 30,
				'headers' => array(
					'Authorization' => 'Bearer ' . $access_token,
					'Accept'        => 'application/json',
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( isset( $body['error'] ) ) {
			return new \WP_Error(
				'user_info_error',
				isset( $body['error']['message'] ) ? $body['error']['message'] : 'Failed to get user info'
			);
		}

		return $this->normalize_user_data( $body );
	}

	/**
	 * Normalize Google user data to standard format
	 *
	 * @param array $raw_data Raw user data from Google
	 * @return array Normalized user data
	 */
	protected function normalize_user_data( $raw_data ) {
		// v1.4.6: Handle both v2 (id) and v3 (sub) response formats
		// Pass 8: json_decode of provider JSON does not sanitize — field-sanitize here.
		$provider_id = sanitize_text_field( (string) ( $raw_data['id'] ?? ( $raw_data['sub'] ?? '' ) ) );

		// v1.4.6: Get larger avatar (BuddyBoss pattern: replace s96 with s360)
		$avatar = esc_url_raw( (string) ( $raw_data['picture'] ?? '' ) );
		if ( $avatar !== '' && strpos( $avatar, '=s96-c' ) !== false ) {
			$avatar = str_replace( '=s96-c', '=s360-c', $avatar );
		}

		$email_verified = $raw_data['email_verified'] ?? false;
		if ( is_string( $email_verified ) ) {
			$email_verified = in_array( strtolower( $email_verified ), array( 'true', '1', 'yes' ), true );
		}

		return array(
			'provider_id'    => $provider_id,
			'email'          => sanitize_email( (string) ( $raw_data['email'] ?? '' ) ),
			'email_verified' => (bool) $email_verified,
			'name'           => sanitize_text_field( (string) ( $raw_data['name'] ?? '' ) ),
			'first_name'     => sanitize_text_field( (string) ( $raw_data['given_name'] ?? '' ) ),
			'last_name'      => sanitize_text_field( (string) ( $raw_data['family_name'] ?? '' ) ),
			'avatar'         => $avatar,
			'locale'         => sanitize_text_field( (string) ( $raw_data['locale'] ?? '' ) ),
			// Do not retain the full decoded provider blob for hooks/storage.
			'raw_data'       => array(),
		);
	}

	/**
	 * Get provider-specific user ID
	 *
	 * @param array $raw_data Raw user data
	 * @return string Provider user ID
	 */
	public function get_provider_user_id( $raw_data ) {
		// v1.4.6: Handle both v2 (id) and v3 (sub) formats
		return $raw_data['id'] ?? ( $raw_data['sub'] ?? '' );
	}

	/**
	 * Get button colors
	 *
	 * @return array
	 */
	public function get_button_colors() {
		return array(
			'background' => '#ffffff',
			'text'       => '#757575',
			'border'     => '#dadce0',
		);
	}

	/**
	 * Get setup instructions for Google OAuth
	 *
	 * @return string HTML instructions
	 */
	public function get_setup_instructions() {
		$callback_url = $this->get_callback_url();

		return '
        <div class="flosc-sso-setup-instructions">
            <h4>Google OAuth Setup Instructions</h4>
            <ol>
                <li>Go to the <a href="https://console.cloud.google.com/apis/credentials" target="_blank">Google Cloud Console</a></li>
                <li>Create a new project or select an existing one</li>
                <li>Navigate to "APIs & Services" → "Credentials"</li>
                <li>Click "Create Credentials" → "OAuth client ID"</li>
                <li>Select "Web application" as the application type</li>
                <li>Add the following Authorized redirect URI:
                    <code class="flosc-code-block">' . esc_html( $callback_url ) . '</code>
                </li>
                <li>Click "Create" to generate your Client ID and Client Secret</li>
                <li>Copy the Client ID and Client Secret into the fields above</li>
            </ol>
            <p><strong>Note:</strong> You may need to configure the OAuth consent screen first. Set it to "External" for production use.</p>
        </div>';
	}
}
