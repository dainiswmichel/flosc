<?php
/**
 * FLOSC Content Tab
 *
 * Merges former Member Levels + Lessons admin into one Content tab (C of FLOSC).
 *
 * Sections:
 * 1. Content types (repeater: singular / plural — Lesson/Lessons, Recipe/Recipes, …)
 * 2. Member levels (registry)
 * 3. Content groups (quiz → WP category)
 * 4. Content protection
 * 5. Complimentary pool / selection (guests)
 * 6. Guest chat caps
 *
 * Setting keys: free_content_item_*, content_item_*, exclude_items_from_freeline.
 *
 * @package FLOSC
 * @since 8.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

flosc_tab_header( '📦', 'Content' );

$flosc_flow_settings = $GLOBALS['flosc_current_settings'] ?? array();
$flosc_settings_key  = $GLOBALS['flosc_settings_key'] ?? '';
$flosc_current_ivr   = $GLOBALS['flosc_current_ivr'] ?? '';

$flosc_content_docs_url           = add_query_arg(
	array(
		'page' => 'flosc-settings',
		'ivr'  => $flosc_current_ivr,
		'tab'  => 'documentation',
		'doc'  => 'ref-admin',
	),
	admin_url( 'admin.php' )
) . '#tab-content';
$flosc_content_docs_inventory_url = add_query_arg(
	array(
		'page' => 'flosc-settings',
		'ivr'  => $flosc_current_ivr,
		'tab'  => 'documentation',
		'doc'  => 'ref-admin',
	),
	admin_url( 'admin.php' )
) . '#inventory-content-family';

// Content types: list of { singular, plural }. Migrate legacy single-label fields.
$flosc_content_types = $flosc_flow_settings['content_types'] ?? array();
if ( ! is_array( $flosc_content_types ) ) {
	$flosc_content_types = array();
}
if ( empty( $flosc_content_types ) ) {
	$flosc_legacy_s = trim( (string) ( $flosc_flow_settings['content_item_label_singular'] ?? '' ) );
	$flosc_legacy_p = trim( (string) ( $flosc_flow_settings['content_item_label_plural'] ?? '' ) );
	if ( $flosc_legacy_s !== '' || $flosc_legacy_p !== '' ) {
		$flosc_content_types[] = array(
			'singular' => $flosc_legacy_s,
			'plural'   => $flosc_legacy_p !== '' ? $flosc_legacy_p : $flosc_legacy_s,
		);
	}
}
if ( empty( $flosc_content_types ) ) {
	$flosc_content_types[] = array(
		'singular' => '',
		'plural'   => '',
	);
}
$flosc_item_s_disp = '';
$flosc_item_p_disp = '';
foreach ( $flosc_content_types as $flosc_ct ) {
	$flosc_s = trim( (string) ( $flosc_ct['singular'] ?? '' ) );
	$flosc_p = trim( (string) ( $flosc_ct['plural'] ?? '' ) );
	if ( $flosc_s !== '' ) {
		$flosc_item_s_disp = $flosc_s;
		$flosc_item_p_disp = $flosc_p !== '' ? $flosc_p : $flosc_s;
		break;
	}
}
if ( $flosc_item_s_disp === '' ) {
	$flosc_item_s_disp = __( 'content item', 'flosc' );
	$flosc_item_p_disp = __( 'content items', 'flosc' );
}

$flosc_member_levels = $flosc_flow_settings['member_levels'] ?? array();
if ( empty( $flosc_member_levels ) ) {
	$flosc_member_levels[''] = array(
		'slug'        => '',
		'name'        => '',
		'description' => '',
	);
}

$flosc_categories = get_categories( array( 'hide_empty' => false ) );
$flosc_tags       = get_tags( array( 'hide_empty' => false ) );
if ( ! is_array( $flosc_tags ) ) {
	$flosc_tags = array();
}

// Empty = no quizzes for this flow. Never invent a sample quiz ID.
$flosc_enabled_quizzes = $flosc_flow_settings['enabled_quizzes'] ?? array();
if ( ! is_array( $flosc_enabled_quizzes ) ) {
	$flosc_enabled_quizzes = array();
}
$flosc_enabled_quizzes = array_values( array_filter( array_map( 'sanitize_key', $flosc_enabled_quizzes ) ) );
$flosc_quiz_label_map  = array();
if ( class_exists( 'FLOSC_Quiz_Registry' ) ) {
	$flosc_all_quiz_types = FLOSC_Quiz_Registry::get_all_quizzes();
	foreach ( $flosc_all_quiz_types as $flosc_qid => $flosc_qt ) {
		$flosc_quiz_label_map[ $flosc_qid ] = ( $flosc_qt instanceof FLOSC_Abstract_Quiz_Type )
			? $flosc_qt->get_name()
			: ucwords( str_replace( array( '_', 'flosc-', 'flosc_' ), array( ' ', '', '' ), $flosc_qid ) );
	}
}

$flosc_content_item_groups = $flosc_flow_settings['content_item_groups'] ?? array();
if ( empty( $flosc_content_item_groups ) && ! empty( $flosc_flow_settings['content_item_category'] ) ) {
	$flosc_content_item_groups = array(
		array(
			'quiz_id'  => '',
			'category' => $flosc_flow_settings['content_item_category'],
		),
	);
}
if ( empty( $flosc_content_item_groups ) ) {
	$flosc_content_item_groups = array(
		array(
			'quiz_id'  => '',
			'category' => '',
		),
	);
}

$flosc_saved_levels    = $flosc_flow_settings['member_levels'] ?? $flosc_member_levels;
$flosc_protected_items = $flosc_flow_settings['protected_content'] ?? array();

/*
 * The two axes of access, as the selects present them.
 *
 * The tier is a FLOOR: Visitors also covers guests and members, Guests excludes
 * visitors, Members excludes both. Depth is how much of the post that tier
 * gets. FLOSC_Site_Content_Index holds the same two vocabularies as TIERS and
 * DEPTHS and is the thing that reads them back at retrieval time.
 */
$flosc_vgm_tiers  = flosc_vgm_tier_labels();
$flosc_vgm_depths = flosc_vgm_depth_labels();

$flosc_default_vgm = $flosc_flow_settings['content_default_vgm'] ?? array();
foreach ( array_keys( $flosc_vgm_tiers ) as $flosc_tier_key ) {
	$flosc_d                              = (string) ( $flosc_default_vgm[ $flosc_tier_key ] ?? '' );
	$flosc_default_vgm[ $flosc_tier_key ] = isset( $flosc_vgm_depths[ $flosc_d ] ) ? $flosc_d : 'full';
}
$flosc_free_content_item_mode          = $flosc_flow_settings['free_content_item_mode'] ?? 'fixed';
$flosc_free_content_item_count         = $flosc_flow_settings['free_content_item_count'] ?? 1;
$flosc_free_content_item_proportion    = $flosc_flow_settings['free_content_item_proportion'] ?? '1/3';
$flosc_guest_access_days               = $flosc_flow_settings['guest_access_days'] ?? 0;
$flosc_free_content_item_guaranteed    = $flosc_flow_settings['free_content_item_guaranteed'] ?? 0;
$flosc_free_content_item_pool_category = sanitize_title( (string) ( $flosc_flow_settings['free_content_item_pool_category'] ?? '' ) );
$flosc_pool_exclude                    = (string) ( $flosc_flow_settings['exclude_items_from_freeline'] ?? '' );
$flosc_guest_max_chats                 = isset( $flosc_flow_settings['guest_max_chats'] )
	? max( 0, intval( $flosc_flow_settings['guest_max_chats'] ) )
	: 0;
$flosc_guest_can_delete_chats          = ! isset( $flosc_flow_settings['guest_can_delete_chats'] )
	|| ! empty( $flosc_flow_settings['guest_can_delete_chats'] );
$flosc_guest_can_rename_chats          = ! isset( $flosc_flow_settings['guest_can_rename_chats'] )
	|| ! empty( $flosc_flow_settings['guest_can_rename_chats'] );
$flosc_guest_new_chat_limit_message    = (string) ( $flosc_flow_settings['guest_new_chat_limit_message']
	?? 'Your guest account allows {max} chats listed below. If you would like to start a new chat, you can delete one below.' );
$flosc_chat_list_settings_url          = add_query_arg(
	array(
		'page' => 'flosc-settings',
		'ivr'  => $flosc_current_ivr,
		'tab'  => 'ui',
		'view' => 'single',
	),
	admin_url( 'admin.php' )
);
?>

<div class="flosc-docs-link-wrap">
	<a href="<?php echo esc_url( $flosc_content_docs_url ); ?>" class="flosc-docs-link"><?php echo esc_html__( 'Docs', 'flosc' ); ?></a>
</div>

<p class="description">
	<?php echo esc_html__( 'Content is the C of FLOSC for this flow: items in WordPress, which member levels unlock them, and the guest complimentary pool/selection. Offers grant levels (Offers tab). Sale checkout is separate. DA1 catalogs are separate (DA1 tab).', 'flosc' ); ?>
</p>

<!-- 1. Content types -->
<h2>
	<?php echo esc_html__( 'Content Types', 'flosc' ); ?>
	<a href="<?php echo esc_url( $flosc_content_docs_inventory_url ); ?>" class="flosc-docs-link"><?php echo esc_html__( 'Docs', 'flosc' ); ?></a>
</h2>
<p><?php echo esc_html__( 'Add any number of content type names for this flow. Examples: Lesson / Lessons, Recipe / Recipes. Empty rows are ignored. Default chrome uses “content item(s)” when none are set.', 'flosc' ); ?></p>
<table class="widefat flosc-content-types-table flosc-table-max-860">
	<thead>
		<tr>
			<th><?php echo esc_html__( 'Singular', 'flosc' ); ?></th>
			<th><?php echo esc_html__( 'Plural', 'flosc' ); ?></th>
			<th class="flosc-col-actions"><?php echo esc_html__( 'Actions', 'flosc' ); ?></th>
		</tr>
	</thead>
	<tbody id="flosc-content-types-body">
		<?php foreach ( $flosc_content_types as $flosc_ct ) : ?>
		<tr class="flosc-content-type-row">
			<td>
				<input type="text" name="content_type_singular[]" class="regular-text"
					value="<?php echo esc_attr( (string) ( $flosc_ct['singular'] ?? '' ) ); ?>"
					placeholder="<?php echo esc_attr__( 'Lesson', 'flosc' ); ?>">
			</td>
			<td>
				<input type="text" name="content_type_plural[]" class="regular-text"
					value="<?php echo esc_attr( (string) ( $flosc_ct['plural'] ?? '' ) ); ?>"
					placeholder="<?php echo esc_attr__( 'Lessons', 'flosc' ); ?>">
			</td>
			<td class="flosc-text-center">
				<button type="button" class="button flosc-remove-content-type" title="<?php echo esc_attr__( 'Remove', 'flosc' ); ?>">&times;</button>
			</td>
		</tr>
		<?php endforeach; ?>
	</tbody>
</table>
<p class="flosc-margin-top-10">
	<button type="button" class="button" id="flosc-add-content-type"><?php echo esc_html__( '+ Add Content Type', 'flosc' ); ?></button>
</p>

<!-- 2. Levels -->
<hr class="flosc-member-levels-divider">
<h2>
	<?php echo esc_html__( 'Member levels', 'flosc' ); ?>
	<a href="<?php echo esc_url( $flosc_content_docs_inventory_url ); ?>" class="flosc-docs-link"><?php echo esc_html__( 'Docs', 'flosc' ); ?></a>
</h2>
<p><?php echo esc_html__( 'Define membership levels for this flow. Offers grant a level. Protection rules require a level.', 'flosc' ); ?></p>

<table class="widefat flosc-levels-table flosc-member-levels-table">
	<thead>
		<tr>
			<th class="flosc-member-levels-col-slug"><?php echo esc_html__( 'Slug', 'flosc' ); ?> <span class="flosc-note-optional">(<?php echo esc_html__( 'machine name', 'flosc' ); ?>)</span></th>
			<th class="flosc-member-levels-col-name"><?php echo esc_html__( 'Display Name', 'flosc' ); ?></th>
			<th class="flosc-member-levels-col-description"><?php echo esc_html__( 'Description', 'flosc' ); ?> <span class="flosc-note-optional">(<?php echo esc_html__( 'optional', 'flosc' ); ?>)</span></th>
			<th class="flosc-member-levels-col-actions"><?php echo esc_html__( 'Actions', 'flosc' ); ?></th>
		</tr>
	</thead>
	<tbody id="flosc-levels-body">
		<?php foreach ( $flosc_member_levels as $flosc_level_key => $flosc_level ) : ?>
		<tr class="flosc-level-row">
			<td>
				<input type="text" name="level_slug[]"
					value="<?php echo esc_attr( $flosc_level['slug'] ?? $flosc_level_key ); ?>"
					class="regular-text flosc-level-slug"
					placeholder="full_access"
					pattern="[a-z0-9_]+"
					title="<?php echo esc_attr__( 'Lowercase letters, numbers, underscores only', 'flosc' ); ?>">
			</td>
			<td>
				<input type="text" name="level_name[]"
					value="<?php echo esc_attr( $flosc_level['name'] ?? '' ); ?>"
					class="regular-text"
					placeholder="Full Access">
			</td>
			<td>
				<input type="text" name="level_description[]"
					value="<?php echo esc_attr( $flosc_level['description'] ?? '' ); ?>"
					class="regular-text"
					placeholder="<?php echo esc_attr__( 'Complete access to all content', 'flosc' ); ?>">
			</td>
			<td class="flosc-text-center">
				<button type="button" class="button flosc-remove-level" title="<?php echo esc_attr__( 'Remove this level', 'flosc' ); ?>">&times;</button>
			</td>
		</tr>
		<?php endforeach; ?>
	</tbody>
</table>
<p class="flosc-margin-top-10">
	<button type="button" class="button" id="flosc-add-level"><?php echo esc_html__( '+ Add Level', 'flosc' ); ?></button>
</p>

<!-- 3. Content groups -->
<hr class="flosc-member-levels-divider">
<h2>
	<?php echo esc_html__( 'Content groups', 'flosc' ); ?>
	<a href="<?php echo esc_url( $flosc_content_docs_inventory_url ); ?>" class="flosc-docs-link"><?php echo esc_html__( 'Docs', 'flosc' ); ?></a>
</h2>
<p>
	<?php
	echo esc_html(
		sprintf(
			/* translators: %s: plural content item label */
			__( 'Map an optional quiz to a WordPress category of %s. Categories without a quiz are standalone libraries.', 'flosc' ),
			$flosc_item_p_disp
		)
	);
	?>
</p>
<table class="widefat flosc-lesson-groups-table flosc-table-max-860">
	<thead>
		<tr>
			<th class="flosc-col-quiz"><?php echo esc_html__( 'Quiz', 'flosc' ); ?> <span class="flosc-note-optional">(<?php echo esc_html__( 'optional', 'flosc' ); ?>)</span></th>
			<th class="flosc-col-category"><?php echo esc_html__( 'Category', 'flosc' ); ?> <span class="flosc-note-optional">(<?php echo esc_html__( 'required', 'flosc' ); ?>)</span></th>
			<th class="flosc-col-actions"><?php echo esc_html__( 'Actions', 'flosc' ); ?></th>
		</tr>
	</thead>
	<tbody id="flosc-lesson-groups-body">
		<?php foreach ( $flosc_content_item_groups as $flosc_group ) : ?>
		<tr class="flosc-lesson-group-row">
			<td>
				<select name="content_item_group_quiz[]" class="regular-text flosc-width-full">
					<option value=""><?php echo esc_html__( '— No Quiz (Standalone) —', 'flosc' ); ?></option>
					<?php foreach ( $flosc_enabled_quizzes as $flosc_eq ) : ?>
						<option value="<?php echo esc_attr( $flosc_eq ); ?>" <?php selected( $flosc_group['quiz_id'] ?? '', $flosc_eq ); ?>>
							<?php echo esc_html( $flosc_quiz_label_map[ $flosc_eq ] ?? $flosc_eq ); ?>
						</option>
					<?php endforeach; ?>
				</select>
			</td>
			<td>
				<select name="content_item_group_category[]" class="regular-text flosc-width-full">
					<option value=""><?php echo esc_html__( '— Select Category —', 'flosc' ); ?></option>
					<?php foreach ( $flosc_categories as $flosc_cat ) : ?>
						<option value="<?php echo esc_attr( $flosc_cat->slug ); ?>" <?php selected( $flosc_group['category'] ?? '', $flosc_cat->slug ); ?>>
							<?php echo esc_html( $flosc_cat->name ); ?> (<?php echo esc_html( (string) $flosc_cat->count ); ?> posts)
						</option>
					<?php endforeach; ?>
				</select>
			</td>
			<td class="flosc-text-center">
				<button type="button" class="button flosc-remove-lesson-group" title="<?php echo esc_attr__( 'Remove this group', 'flosc' ); ?>">&times;</button>
			</td>
		</tr>
		<?php endforeach; ?>
	</tbody>
</table>
<p class="flosc-margin-top-10">
	<button type="button" class="button" id="flosc-add-lesson-group"><?php echo esc_html__( '+ Add Content Group', 'flosc' ); ?></button>
</p>
<p class="description flosc-margin-top-6">
	<?php echo esc_html__( 'Posts in the category may use number tags (e.g. 5, phoneme-5) so quiz misses map to the matching item.', 'flosc' ); ?>
</p>

<!-- 4. Protection -->
<hr class="flosc-member-levels-divider">
<h2>
	<?php echo esc_html__( 'Content protection', 'flosc' ); ?>
	<a href="<?php echo esc_url( $flosc_content_docs_inventory_url ); ?>" class="flosc-docs-link"><?php echo esc_html__( 'Docs', 'flosc' ); ?></a>
</h2>
<p><?php echo esc_html__( 'Assign WordPress content to member levels. Guests only open complimentary selection from the pool below until Sale grants a level.', 'flosc' ); ?></p>
<p class="description">
	<?php echo esc_html__( 'Access has two axes. Visitors / Guests / Members says WHO — and it is a floor, so a rule set to Visitors also covers guests and members, one set to Guests excludes visitors, and one set to Members excludes both. Available says HOW MUCH of the post that tier gets: the title alone, the excerpt, everything down to the read-more break, or the whole body.', 'flosc' ); ?>
</p>
<p class="description">
	<?php echo esc_html__( 'Most specific wins: a rule on a post overrides one on its tags, which overrides one on its categories, which overrides the site default below. Several rules on the same scope combine, so one post can be read-more for visitors and full for guests.', 'flosc' ); ?>
</p>

<table class="widefat flosc-protection-table flosc-default-vgm-table">
	<thead>
		<tr>
			<th colspan="4"><?php echo esc_html__( 'Site default — every post no rule below names', 'flosc' ); ?></th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<?php foreach ( $flosc_vgm_tiers as $flosc_tier_key => $flosc_tier_label ) : ?>
				<td>
					<label for="flosc-default-vgm-<?php echo esc_attr( $flosc_tier_key ); ?>"><?php echo esc_html( $flosc_tier_label ); ?></label><br>
					<select name="content_default_vgm[<?php echo esc_attr( $flosc_tier_key ); ?>]"
						id="flosc-default-vgm-<?php echo esc_attr( $flosc_tier_key ); ?>" class="flosc-width-full">
						<?php echo flosc_vgm_options_markup( $flosc_vgm_depths, (string) $flosc_default_vgm[ $flosc_tier_key ] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built escaped in flosc_vgm_options_markup() ?>
					</select>
				</td>
			<?php endforeach; ?>
			<td class="description">
				<?php echo esc_html__( 'Published is public, so this ships as the whole body for everybody.', 'flosc' ); ?>
			</td>
		</tr>
	</tbody>
</table>

<table class="widefat flosc-protection-table flosc-member-protection-table flosc-margin-top-10">
	<thead>
		<tr>
			<th class="flosc-member-protection-col-type"><?php echo esc_html__( 'Type', 'flosc' ); ?></th>
			<th class="flosc-member-protection-col-content"><?php echo esc_html__( 'Content', 'flosc' ); ?></th>
			<th class="flosc-member-protection-col-vgm"><?php echo esc_html__( 'Who', 'flosc' ); ?></th>
			<th class="flosc-member-protection-col-depth"><?php echo esc_html__( 'Available', 'flosc' ); ?></th>
			<th class="flosc-member-protection-col-level"><?php echo esc_html__( 'Required Level', 'flosc' ); ?></th>
			<th class="flosc-member-protection-col-actions"><?php echo esc_html__( 'Actions', 'flosc' ); ?></th>
		</tr>
	</thead>
	<tbody id="flosc-protection-body">
		<?php if ( ! empty( $flosc_protected_items ) ) : ?>
			<?php foreach ( $flosc_protected_items as $flosc_item ) : ?>
			<tr class="flosc-protection-row">
				<td>
					<select name="protection_type[]" class="flosc-protection-type flosc-width-full">
						<option value="category" <?php selected( $flosc_item['type'] ?? '', 'category' ); ?>><?php echo esc_html__( 'Category', 'flosc' ); ?></option>
						<option value="tag" <?php selected( $flosc_item['type'] ?? '', 'tag' ); ?>><?php echo esc_html__( 'Tag', 'flosc' ); ?></option>
						<option value="post" <?php selected( $flosc_item['type'] ?? '', 'post' ); ?>><?php echo esc_html__( 'Post (ID)', 'flosc' ); ?></option>
						<option value="page" <?php selected( $flosc_item['type'] ?? '', 'page' ); ?>><?php echo esc_html__( 'Page (ID)', 'flosc' ); ?></option>
					</select>
				</td>
				<td>
					<?php
					$flosc_item_type = $flosc_item['type'] ?? 'category';
					if ( in_array( $flosc_item_type, array( 'post', 'page' ), true ) ) :
						?>
						<input type="text" name="protection_value[]"
							value="<?php echo esc_attr( $flosc_item['id'] ?? '' ); ?>"
							class="regular-text flosc-protection-value"
							placeholder="<?php echo esc_attr__( 'Post/Page ID', 'flosc' ); ?>">
					<?php else : ?>
						<select name="protection_value[]" class="flosc-protection-value flosc-width-full">
							<option value=""><?php echo esc_html__( '— Select —', 'flosc' ); ?></option>
							<?php if ( 'category' === $flosc_item_type ) : ?>
								<?php foreach ( $flosc_categories as $flosc_cat ) : ?>
									<option value="<?php echo esc_attr((string) $flosc_cat->term_id); ?>" <?php selected( $flosc_item['id'] ?? '', $flosc_cat->term_id ); ?>>
										<?php echo esc_html( $flosc_cat->name ); ?> (<?php echo esc_html( (string) $flosc_cat->count ); ?> posts)
									</option>
								<?php endforeach; ?>
							<?php elseif ( 'tag' === $flosc_item_type ) : ?>
								<?php foreach ( $flosc_tags as $flosc_tag ) : ?>
									<option value="<?php echo esc_attr((string) $flosc_tag->term_id); ?>" <?php selected( $flosc_item['id'] ?? '', $flosc_tag->term_id ); ?>>
										<?php echo esc_html( $flosc_tag->name ); ?> (<?php echo esc_html( (string) $flosc_tag->count ); ?> posts)
									</option>
								<?php endforeach; ?>
							<?php endif; ?>
						</select>
					<?php endif; ?>
				</td>
				<td>
					<select name="protection_vgm[]" class="flosc-protection-vgm flosc-width-full">
						<?php echo flosc_vgm_options_markup( $flosc_vgm_tiers, (string) ( $flosc_item['vgm'] ?? 'member' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built escaped in flosc_vgm_options_markup() ?>
					</select>
				</td>
				<td>
					<select name="protection_depth[]" class="flosc-protection-depth flosc-width-full">
						<?php echo flosc_vgm_options_markup( $flosc_vgm_depths, (string) ( $flosc_item['depth'] ?? 'full' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built escaped in flosc_vgm_options_markup() ?>
					</select>
				</td>
				<td>
					<select name="protection_level[]" class="flosc-protection-level-select flosc-width-full">
						<option value=""><?php echo esc_html__( '— Any Member —', 'flosc' ); ?></option>
						<?php
						foreach ( $flosc_saved_levels as $flosc_lk => $flosc_lv ) :
							$flosc_slug = $flosc_lv['slug'] ?? $flosc_lk;
							if ( empty( $flosc_slug ) ) {
								continue;
							}
							?>
							<option value="<?php echo esc_attr( $flosc_slug ); ?>" <?php selected( $flosc_item['level'] ?? '', $flosc_slug ); ?>>
								<?php echo esc_html( ( $flosc_lv['name'] ?? '' ) ?: $flosc_slug ); ?>
							</option>
						<?php endforeach; ?>
					</select>
				</td>
				<td class="flosc-text-center">
					<button type="button" class="button flosc-remove-protection-row" title="<?php echo esc_attr__( 'Remove', 'flosc' ); ?>">&times;</button>
				</td>
			</tr>
			<?php endforeach; ?>
		<?php endif; ?>
	</tbody>
</table>
<p class="flosc-margin-top-10">
	<button type="button" class="button" id="flosc-add-protection"><?php echo esc_html__( '+ Add Protection Rule', 'flosc' ); ?></button>
</p>

<?php
/*
 * Rules a floscAdmin set on the object's own screen. Listed, not editable
 * here — a rule has one home, and this tab's job is to show that the site has
 * it. Without this the Content tab is an overview of only half the rules.
 */
$flosc_object_rules = class_exists( 'FLOSC_Site_Content_Index' )
	? FLOSC_Site_Content_Index::rules_written_on_objects()
	: array();
?>
<?php if ( ! empty( $flosc_object_rules ) ) : ?>
	<h3><?php echo esc_html__( 'Set on the object itself', 'flosc' ); ?></h3>
	<p class="description"><?php echo esc_html__( 'These were set on a post, category or tag screen. Edit them there.', 'flosc' ); ?></p>
	<table class="widefat flosc-protection-table">
		<thead>
			<tr>
				<th><?php echo esc_html__( 'Type', 'flosc' ); ?></th>
				<th><?php echo esc_html__( 'Content', 'flosc' ); ?></th>
				<th><?php echo esc_html__( 'Who', 'flosc' ); ?></th>
				<th><?php echo esc_html__( 'Available', 'flosc' ); ?></th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ( $flosc_object_rules as $flosc_obj_rule ) : ?>
				<tr>
					<td><?php echo esc_html( $flosc_obj_rule['kind'] ); ?></td>
					<td>
						<?php if ( ! empty( $flosc_obj_rule['edit_url'] ) ) : ?>
							<a href="<?php echo esc_url( $flosc_obj_rule['edit_url'] ); ?>"><?php echo esc_html( $flosc_obj_rule['name'] ); ?></a>
						<?php else : ?>
							<?php echo esc_html( $flosc_obj_rule['name'] ); ?>
						<?php endif; ?>
					</td>
					<td><?php echo esc_html( $flosc_vgm_tiers[ $flosc_obj_rule['vgm'] ] ?? $flosc_obj_rule['vgm'] ); ?></td>
					<td><?php echo esc_html( $flosc_vgm_depths[ $flosc_obj_rule['depth'] ] ?? $flosc_obj_rule['depth'] ); ?></td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
<?php endif; ?>

<!-- 5. Pool / selection -->
<hr class="flosc-member-levels-divider">
<h2>
	<?php echo esc_html__( 'Complimentary pool & selection (guests)', 'flosc' ); ?>
	<a href="<?php echo esc_url( $flosc_content_docs_inventory_url ); ?>" class="flosc-docs-link"><?php echo esc_html__( 'Docs', 'flosc' ); ?></a>
</h2>
<p>
	<?php
	echo esc_html(
		sprintf(
			/* translators: 1: content items plural, 2: example count */
			__( 'Content is the full set. The pool is the complimentary subset. Selection is how many a Guest receives (e.g. %2$flosc_s of your %1$flosc_s). More requires Member via Sale.', 'flosc' ),
			$flosc_item_p_disp,
			'2'
		)
	);
	?>
</p>
<table class="form-table">
	<tr>
		<th scope="row"><label for="flow_free_content_item_pool_category"><?php echo esc_html__( 'Pool (category)', 'flosc' ); ?></label></th>
		<td>
			<select name="flow_free_content_item_pool_category" id="flow_free_content_item_pool_category" class="regular-text">
				<option value=""><?php echo esc_html__( '— Same as content group category —', 'flosc' ); ?></option>
				<?php
				foreach ( $flosc_categories as $flosc_cat ) :
					$flosc_cat_label = $flosc_cat->name;
					if ( ! empty( $flosc_cat->parent ) ) {
						$flosc_cat_parent = get_category( (int) $flosc_cat->parent );
						if ( $flosc_cat_parent && ! is_wp_error( $flosc_cat_parent ) ) {
							$flosc_cat_label = $flosc_cat_parent->name . ' → ' . $flosc_cat->name;
						}
					}
					?>
					<option value="<?php echo esc_attr( $flosc_cat->slug ); ?>" <?php selected( $flosc_free_content_item_pool_category, $flosc_cat->slug ); ?>>
						<?php echo esc_html( $flosc_cat_label ); ?> (<?php echo esc_html( (string) $flosc_cat->count ); ?> posts)
					</option>
				<?php endforeach; ?>
			</select>
			<p class="description"><?php echo esc_html__( 'Only published posts in this category (with content numbers) can be complimentary samples.', 'flosc' ); ?></p>
		</td>
	</tr>
	<tr>
		<th scope="row"><label for="flow_exclude_items_from_freeline"><?php echo esc_html__( 'Exclude from freeline', 'flosc' ); ?></label></th>
		<td>
			<input type="text" id="flow_exclude_items_from_freeline" name="flow_exclude_items_from_freeline"
				value="<?php echo esc_attr( $flosc_pool_exclude ); ?>"
				class="large-text" placeholder="e.g. 1, 2, 7, 12">
			<p class="description"><?php echo esc_html__( 'Content item numbers that freeline selection must never grant, even if those posts are in the pool category (e.g. 1, 2, 7, 12).', 'flosc' ); ?></p>
		</td>
	</tr>
	<tr>
		<th scope="row"><label for="flow_free_content_item_mode"><?php echo esc_html__( 'Selection mode', 'flosc' ); ?></label></th>
		<td>
			<select name="flow_free_content_item_mode" id="flow_free_content_item_mode">
				<option value="fixed" <?php selected( $flosc_free_content_item_mode, 'fixed' ); ?>><?php echo esc_html__( 'Fixed number', 'flosc' ); ?></option>
				<option value="proportion" <?php selected( $flosc_free_content_item_mode, 'proportion' ); ?>><?php echo esc_html__( 'Proportion of missed (non-IPA)', 'flosc' ); ?></option>
			</select>
		</td>
	</tr>
	<tr id="flow_free_content_item_count_row">
		<th scope="row"><label for="flow_free_content_item_count"><?php echo esc_html__( 'Guest selection count', 'flosc' ); ?></label></th>
		<td>
			<input type="number" id="flow_free_content_item_count" name="flow_free_content_item_count"
				value="<?php echo esc_attr( (string) $flosc_free_content_item_count ); ?>" min="1" max="50" class="small-text">
			<p class="description">
				<?php
				echo esc_html(
					sprintf(
						/* translators: %s: plural content label */
						__( 'How many %s a Guest receives from the pool (e.g. 2).', 'flosc' ),
						$flosc_item_p_disp
					)
				);
				?>
			</p>
		</td>
	</tr>
	<tr id="flow_free_content_item_proportion_row">
		<th scope="row"><label for="flow_free_content_item_proportion"><?php echo esc_html__( 'Proportion of missed', 'flosc' ); ?></label></th>
		<td>
			<select name="flow_free_content_item_proportion" id="flow_free_content_item_proportion">
				<option value="1/5" <?php selected( $flosc_free_content_item_proportion, '1/5' ); ?>>1/5</option>
				<option value="1/4" <?php selected( $flosc_free_content_item_proportion, '1/4' ); ?>>1/4</option>
				<option value="1/3" <?php selected( $flosc_free_content_item_proportion, '1/3' ); ?>>1/3</option>
				<option value="1/2" <?php selected( $flosc_free_content_item_proportion, '1/2' ); ?>>1/2</option>
			</select>
		</td>
	</tr>
	<tr>
		<th scope="row"><label for="flow_free_content_item_guaranteed"><?php echo esc_html__( 'Bonus item number', 'flosc' ); ?></label></th>
		<td>
			<input type="number" id="flow_free_content_item_guaranteed" name="flow_free_content_item_guaranteed"
				value="<?php echo esc_attr( (string) $flosc_free_content_item_guaranteed ); ?>" min="0" max="9999" class="small-text">
			<p class="description"><?php echo esc_html__( 'Optional extra number always included when in pool and not excluded. 0 = off.', 'flosc' ); ?></p>
		</td>
	</tr>
	<tr>
		<th scope="row"><label for="flow_guest_access_days"><?php echo esc_html__( 'Guest access duration', 'flosc' ); ?></label></th>
		<td>
			<input type="number" id="flow_guest_access_days" name="flow_guest_access_days"
				value="<?php echo esc_attr( (string) $flosc_guest_access_days ); ?>" min="0" max="365" class="small-text">
			<?php echo esc_html__( 'days', 'flosc' ); ?>
			<p class="description"><?php echo esc_html__( '0 = unlimited.', 'flosc' ); ?></p>
		</td>
	</tr>
</table>

<!-- 6. Guest chats -->
<hr class="flosc-member-levels-divider">
<h2>
	<?php echo esc_html__( 'Guest chats', 'flosc' ); ?>
	<a href="<?php echo esc_url( $flosc_content_docs_inventory_url ); ?>" class="flosc-docs-link"><?php echo esc_html__( 'Docs', 'flosc' ); ?></a>
</h2>
<p><?php echo esc_html__( 'Chat list caps for guests (not content delivery). Profile bar labels live under Profile Bar / UI.', 'flosc' ); ?></p>
<table class="form-table">
	<tr>
		<th scope="row"><label for="flow_guest_max_chats"><?php echo esc_html__( 'Guest max chats', 'flosc' ); ?></label></th>
		<td>
			<input type="number" id="flow_guest_max_chats" name="flow_guest_max_chats"
				value="<?php echo esc_attr( (string) $flosc_guest_max_chats ); ?>" min="0" max="9999" class="small-text">
			<p class="description"><?php echo esc_html__( '0 = unlimited.', 'flosc' ); ?></p>
		</td>
	</tr>
	<tr>
		<th scope="row"><?php echo esc_html__( 'Guest chat management', 'flosc' ); ?></th>
		<td>
			<label for="flow_guest_can_delete_chats">
				<input type="checkbox" id="flow_guest_can_delete_chats" name="flow_guest_can_delete_chats" value="1" <?php checked( $flosc_guest_can_delete_chats ); ?>>
				<?php echo esc_html__( 'Guest may delete chats', 'flosc' ); ?>
			</label>
			<br>
			<label for="flow_guest_can_rename_chats">
				<input type="checkbox" id="flow_guest_can_rename_chats" name="flow_guest_can_rename_chats" value="1" <?php checked( $flosc_guest_can_rename_chats ); ?>>
				<?php echo esc_html__( 'Guest may rename chats', 'flosc' ); ?>
			</label>
		</td>
	</tr>
	<tr>
		<th scope="row"><label for="flow_guest_new_chat_limit_message"><?php echo esc_html__( 'Guest New chat limit message', 'flosc' ); ?></label></th>
		<td>
			<textarea id="flow_guest_new_chat_limit_message" name="flow_guest_new_chat_limit_message" class="large-text" rows="3"><?php echo esc_textarea( $flosc_guest_new_chat_limit_message ); ?></textarea>
			<p class="description"><?php echo esc_html__( 'Placeholders: {max}, {count}, {flow_name}, {name}.', 'flosc' ); ?>
				<a href="<?php echo esc_url( $flosc_chat_list_settings_url ); ?>"><?php echo esc_html__( 'Profile Bar / Chat Navigation', 'flosc' ); ?></a>
			</p>
		</td>
	</tr>
</table>

<div class="flosc-member-levels-info-box">
	<h3 class="flosc-member-levels-info-box__title">
		<?php echo esc_html__( 'How Content + Sale work together', 'flosc' ); ?>
		<a href="<?php echo esc_url( $flosc_content_docs_url ); ?>" class="flosc-docs-link"><?php echo esc_html__( 'Docs', 'flosc' ); ?></a>
	</h3>
	<p class="flosc-member-levels-info-box__lead">
		<strong>1.</strong> <?php echo esc_html__( 'Define levels and content groups.', 'flosc' ); ?><br>
		<strong>2.</strong> <?php echo esc_html__( 'Protect content by level.', 'flosc' ); ?><br>
		<strong>3.</strong> <?php echo esc_html__( 'Set guest pool + selection count.', 'flosc' ); ?><br>
		<strong>4.</strong> <?php echo esc_html__( 'Offers grant a level on Sale (PayPal / Access Code).', 'flosc' ); ?><br>
		<strong>5.</strong> <?php echo esc_html__( 'Member unlocks the rest of content.', 'flosc' ); ?>
	</p>
</div>

<?php
ob_start();
?>
jQuery(document).ready(function($) {
	$('#flosc-add-content-type').on('click', function() {
		var row = '<tr class="flosc-content-type-row">'
			+ '<td><input type="text" name="content_type_singular[]" class="regular-text" placeholder="Lesson"></td>'
			+ '<td><input type="text" name="content_type_plural[]" class="regular-text" placeholder="Lessons"></td>'
			+ '<td class="flosc-text-center"><button type="button" class="button flosc-remove-content-type" title="Remove">&times;</button></td>'
			+ '</tr>';
		$('#flosc-content-types-body').append(row);
	});
	$(document).on('click', '.flosc-remove-content-type', function() {
		if ($('.flosc-content-type-row').length > 1) {
			$(this).closest('tr').remove();
		} else {
			$(this).closest('tr').find('input').val('');
		}
	});

	$('#flosc-add-level').on('click', function() {
		var row = '<tr class="flosc-level-row">'
			+ '<td><input type="text" name="level_slug[]" class="regular-text flosc-level-slug" placeholder="full_access" pattern="[a-z0-9_]+"></td>'
			+ '<td><input type="text" name="level_name[]" class="regular-text" placeholder="Full Access"></td>'
			+ '<td><input type="text" name="level_description[]" class="regular-text" placeholder=""></td>'
			+ '<td class="flosc-text-center"><button type="button" class="button flosc-remove-level" title="Remove">&times;</button></td>'
			+ '</tr>';
		$('#flosc-levels-body').append(row);
	});
	$(document).on('click', '.flosc-remove-level', function() {
		if ($('.flosc-level-row').length > 1) {
			$(this).closest('tr').remove();
		} else {
			$(this).closest('tr').find('input').val('');
		}
	});
	$(document).on('input', '.flosc-level-row input[name="level_name[]"]', function() {
		var $slug = $(this).closest('tr').find('.flosc-level-slug');
		if ($slug.val() === '') {
			$slug.val($(this).val().toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, ''));
		}
	});
	$(document).on('blur', '.flosc-level-slug', function() {
		$(this).val($(this).val().toLowerCase().replace(/[^a-z0-9_]+/g, '_').replace(/^_|_$/g, ''));
	});

	var quizOptions = 
	<?php
		$flosc_opts = '<option value="">— No Quiz (Standalone) —</option>';
	foreach ( $flosc_enabled_quizzes as $flosc_eq ) {
		$flosc_label = esc_html( $flosc_quiz_label_map[ $flosc_eq ] ?? $flosc_eq );
		$flosc_opts .= '<option value="' . esc_attr( $flosc_eq ) . '">' . $flosc_label . '</option>';
	}
		echo wp_json_encode( $flosc_opts );
	?>
	;
	var catOptions = 
	<?php
		$flosc_opts = '<option value="">— Select Category —</option>';
	foreach ( $flosc_categories as $flosc_cat ) {
		$flosc_opts .= '<option value="' . esc_attr( $flosc_cat->slug ) . '">' . esc_html( $flosc_cat->name ) . ' (' . esc_html( (string) $flosc_cat->count ) . ' posts)</option>';
	}
		echo wp_json_encode( $flosc_opts );
	?>
	;
	$('#flosc-add-lesson-group').on('click', function() {
		var row = '<tr class="flosc-lesson-group-row">'
			+ '<td><select name="content_item_group_quiz[]" class="regular-text flosc-width-full">' + quizOptions + '</select></td>'
			+ '<td><select name="content_item_group_category[]" class="regular-text flosc-width-full">' + catOptions + '</select></td>'
			+ '<td class="flosc-text-center"><button type="button" class="button flosc-remove-lesson-group" title="Remove">&times;</button></td>'
			+ '</tr>';
		$('#flosc-lesson-groups-body').append(row);
	});
	$(document).on('click', '.flosc-remove-lesson-group', function() {
		if ($('.flosc-lesson-group-row').length > 1) {
			$(this).closest('tr').remove();
		}
	});

	var categoryOptions = 
	<?php
		$flosc_opts = '<option value="">— Select —</option>';
	foreach ( $flosc_categories as $flosc_cat ) {
		$flosc_opts .= '<option value="' . esc_attr((string) $flosc_cat->term_id) . '">' . esc_html( $flosc_cat->name ) . '</option>';
	}
		echo wp_json_encode( $flosc_opts );
	?>
	;
	var tagOptions = 
	<?php
		$flosc_opts = '<option value="">— Select —</option>';
	foreach ( $flosc_tags as $flosc_tag ) {
		$flosc_opts .= '<option value="' . esc_attr((string) $flosc_tag->term_id) . '">' . esc_html( $flosc_tag->name ) . '</option>';
	}
		echo wp_json_encode( $flosc_opts );
	?>
	;
	var levelOptions = 
	<?php
		$flosc_opts = '<option value="">— Any Member —</option>';
	foreach ( $flosc_saved_levels as $flosc_lk => $flosc_lv ) {
		$flosc_slug = $flosc_lv['slug'] ?? $flosc_lk;
		if ( empty( $flosc_slug ) ) {
			continue;
		}
		$flosc_label = ( $flosc_lv['name'] ?? '' ) ?: $flosc_slug;
		$flosc_opts .= '<option value="' . esc_attr( $flosc_slug ) . '">' . esc_html( $flosc_label ) . '</option>';
	}
		echo wp_json_encode( $flosc_opts );
	?>
	;
	function buildContentField(type) {
		if (type === 'post' || type === 'page') {
			return '<input type="text" name="protection_value[]" class="regular-text flosc-protection-value" placeholder="Post/Page ID">';
		}
		if (type === 'tag') {
			return '<select name="protection_value[]" class="flosc-protection-value flosc-width-full">' + tagOptions + '</select>';
		}
		return '<select name="protection_value[]" class="flosc-protection-value flosc-width-full">' + categoryOptions + '</select>';
	}
	/* A new rule starts where every rule stored before these columns existed
		already sits: members only, whole body. */
	var vgmOptions = <?php echo wp_json_encode( flosc_vgm_options_markup( $flosc_vgm_tiers, 'member' ) ); ?>;
	var depthOptions = <?php echo wp_json_encode( flosc_vgm_options_markup( $flosc_vgm_depths, 'full' ) ); ?>;
	$('#flosc-add-protection').on('click', function() {
		var row = '<tr class="flosc-protection-row">'
			+ '<td><select name="protection_type[]" class="flosc-protection-type flosc-width-full"><option value="category">Category</option><option value="tag">Tag</option><option value="post">Post (ID)</option><option value="page">Page (ID)</option></select></td>'
			+ '<td>' + buildContentField('category') + '</td>'
			+ '<td><select name="protection_vgm[]" class="flosc-protection-vgm flosc-width-full">' + vgmOptions + '</select></td>'
			+ '<td><select name="protection_depth[]" class="flosc-protection-depth flosc-width-full">' + depthOptions + '</select></td>'
			+ '<td><select name="protection_level[]" class="flosc-protection-level-select flosc-width-full">' + levelOptions + '</select></td>'
			+ '<td class="flosc-text-center"><button type="button" class="button flosc-remove-protection-row">&times;</button></td>'
			+ '</tr>';
		$('#flosc-protection-body').append(row);
	});
	$(document).on('change', '.flosc-protection-type', function() {
		$(this).closest('tr').find('td:eq(1)').html(buildContentField($(this).val()));
	});
	$(document).on('click', '.flosc-remove-protection-row', function() {
		$(this).closest('tr').remove();
	});

	function toggleFreeLessonFields() {
		var mode = $('#flow_free_content_item_mode').val();
		if (mode === 'fixed') {
			$('#flow_free_content_item_count_row').show();
			$('#flow_free_content_item_proportion_row').hide();
		} else {
			$('#flow_free_content_item_count_row').hide();
			$('#flow_free_content_item_proportion_row').show();
		}
	}
	toggleFreeLessonFields();
	$('#flow_free_content_item_mode').on('change', toggleFreeLessonFields);
});
<?php
wp_add_inline_script( 'flosc-admin', ob_get_clean() );
