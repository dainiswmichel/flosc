<?php
/**
 * FLOSC Offer Manager
 *
 * Manages purchasable offers:
 * - One-time purchases (lifetime access, lesson packs)
 * - Subscriptions (monthly, yearly)
 * - Token/Credit packs
 * - Hybrid offers
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class FLOSC_Offer_Manager {

	private $option_key = 'flosc_offers';
	/** @var array Offer id aliases (empty in core; instances may filter). */
	private $offer_aliases = array();

	/**
	 * @return array<string,string>
	 */
	private function get_offer_aliases() {
		$aliases = apply_filters( 'flosc_offer_aliases', $this->offer_aliases );
		return is_array( $aliases ) ? $aliases : array();
	}

	/**
	 * Offer types
	 */
	const TYPE_ONE_TIME     = 'one_time';
	const TYPE_SUBSCRIPTION = 'subscription';
	const TYPE_TOKENS       = 'tokens';
	const TYPE_HYBRID       = 'hybrid';

	/**
	 * Subscription intervals
	 */
	const INTERVAL_MONTHLY = 'month';
	const INTERVAL_YEARLY  = 'year';
	const INTERVAL_WEEKLY  = 'week';

	/**
	 * Get all offers
	 * v1.6.2: Flow-aware — reads from per-flow storage first, falls back to global
	 * v1.6.5: Seeds defaults into per-flow storage on first access so admin can edit them
	 */
	public function get_all_offers( $flow_id = null ) {
		// v1.6.2: Try per-flow storage first (where admin offers.php saves)
		if ( $flow_id ) {
			$flow_key      = 'flosc_flow_' . sanitize_key( $flow_id );
			$flow_settings = get_option( $flow_key, array() );
			if ( ! empty( $flow_settings['offers'] ) ) {
				$offers = $flow_settings['offers'];
				$synced = $this->sync_ivr_offers_into_offers( $offers, $flow_id );
				if ( $synced !== $offers ) {
					$flow_settings['offers'] = $synced;
					update_option( $flow_key, $flow_settings );
					return $synced;
				}
				return $offers;
			}
		}

		// Fallback to global option for backward compat.
		$offers = get_option( $this->option_key, array() );

		// Ensure default structure.
		if ( empty( $offers ) ) {
			$offers = $this->get_default_offers();
			update_option( $this->option_key, $offers );
		}

		$offers = $this->sync_ivr_offers_into_offers( $offers, $flow_id );

		// v1.6.5: Seed defaults into per-flow storage so admin UI can see/edit them.
		if ( $flow_id ) {
			$flow_key                = 'flosc_flow_' . sanitize_key( $flow_id );
			$flow_settings           = get_option( $flow_key, array() );
			$flow_settings['offers'] = $offers;
			update_option( $flow_key, $flow_settings );
		}

		return $offers;
	}

	/**
	 * Get active (published) offers
	 * v1.6.2: Flow-aware
	 */
	public function get_active_offers( $flow_id = null ) {
		$offers = $this->get_all_offers( $flow_id );
		return array_filter(
			$offers,
			function ( $offer ) {
				return ( $offer['status'] ?? 'active' ) === 'active';
			}
		);
	}

	/**
	 * Get a specific offer by ID
	 * v1.6.2: Flow-aware
	 */
	public function get_offer( $offer_id, $flow_id = null ) {
		$offers = $this->get_all_offers( $flow_id );
		if ( isset( $offers[ $offer_id ] ) ) {
			return $offers[ $offer_id ];
		}
		$aliases = $this->get_offer_aliases();
		$alias   = $aliases[ $offer_id ] ?? null;
		return $alias && isset( $offers[ $alias ] ) ? $offers[ $alias ] : null;
	}

	/**
	 * Get offers by type
	 */
	public function get_offers_by_type( $type ) {
		$offers = $this->get_active_offers();
		return array_filter(
			$offers,
			function ( $offer ) use ( $type ) {
				return $offer['type'] === $type;
			}
		);
	}

	/**
	 * Create a new offer
	 */
	public function create_offer( $data ) {
		$offers = $this->get_all_offers();

		$offer_id = $data['id'] ?? 'offer_' . uniqid();

		$offer = $this->validate_offer_data(
			array_merge(
				array(
					'id'         => $offer_id,
					'created_at' => current_time( 'mysql' ),
				),
				$data
			)
		);

		$offers[ $offer_id ] = $offer;
		update_option( $this->option_key, $offers );

		do_action( 'flosc_offer_created', $offer_id, $offer );

		return $offer;
	}

	/**
	 * Update an offer
	 */
	public function update_offer( $offer_id, $data ) {
		$offers = $this->get_all_offers();

		if ( ! isset( $offers[ $offer_id ] ) ) {
			return new WP_Error( 'not_found', __( 'Offer not found', 'flosc' ) );
		}

		$offer = $this->validate_offer_data(
			array_merge(
				$offers[ $offer_id ],
				$data,
				array( 'updated_at' => current_time( 'mysql' ) )
			)
		);

		$offers[ $offer_id ] = $offer;
		update_option( $this->option_key, $offers );

		do_action( 'flosc_offer_updated', $offer_id, $offer );

		return $offer;
	}

	/**
	 * Delete an offer
	 */
	public function delete_offer( $offer_id ) {
		$offers = $this->get_all_offers();

		if ( ! isset( $offers[ $offer_id ] ) ) {
			return new WP_Error( 'not_found', __( 'Offer not found', 'flosc' ) );
		}

		$offer = $offers[ $offer_id ];
		unset( $offers[ $offer_id ] );
		update_option( $this->option_key, $offers );

		do_action( 'flosc_offer_deleted', $offer_id, $offer );

		return true;
	}

	/**
	 * Sync IVR-defined offer messages into the editable offer registry.
	 * Keeps the IVR file as the source of truth for visible offer copy/format.
	 */
	private function sync_ivr_offers_into_offers( $offers, $flow_id = null ) {
		if ( empty( $flow_id ) ) {
			return $offers;
		}

		$messages = array();

		// Primary source: per-flow DB messages (what IVR Messages tab is editing).
		$flow_key      = 'flosc_flow_' . sanitize_key( $flow_id );
		$flow_settings = get_option( $flow_key, array() );
		$db_messages   = flosc_flow_get_messages( $flow_settings );
		if ( is_array( $db_messages ) && ! empty( $db_messages ) ) {
			$messages = $db_messages;
		}

		// Fallback source: active IVR file if DB messages are not available.
		if ( empty( $messages ) ) {
			$ivr_file = $this->get_flow_ivr_file( $flow_id );
			if ( ! $ivr_file || ! file_exists( $ivr_file ) ) {
				return $offers;
			}

			if ( ! class_exists( 'FLOSC_IVR_Parser' ) ) {
				require_once FLOSC_PLUGIN_DIR . 'includes/portability/class-ivr-parser.php';
			}

			if ( ! class_exists( 'FLOSC_IVR_Parser' ) ) {
				return $offers;
			}

			$parser   = FLOSC_IVR_Parser::flosc_instance();
			$parsed   = $parser->flosc_parse( flosc_fs_get_contents( $ivr_file ) );
			$messages = $parsed['messages'] ?? array();
		}

		if ( empty( $messages ) || ! is_array( $messages ) ) {
			return $offers;
		}

		$updated = $offers;
		foreach ( $messages as $msg_id => $msg ) {
			$msg_type   = strtolower( trim( (string) ( $msg['type'] ?? '' ) ) );
			$msg_phase  = strtolower( trim( (string) ( $msg['phase'] ?? '' ) ) );
			$msg_action = strtolower( trim( (string) ( $msg['action'] ?? '' ) ) );

			$is_offer_scope = ( $msg_type === 'offer' )
				|| ( $msg_phase === 'offer' && $msg_type === 'suggested_user_autoprompt' )
				|| strpos( $msg_action, 'show_offer' ) !== false
				|| strpos( $msg_action, 'checkout' ) !== false
				|| strpos( $msg_action, 'sandbox_purchase' ) !== false;

			if ( ! $is_offer_scope ) {
				continue;
			}

			$offer_id = sanitize_key( $msg['offer_id'] ?? ( $msg['name'] ?? $msg_id ) );
			if ( ! $offer_id ) {
				continue;
			}

			$existing             = $updated[ $offer_id ] ?? array();
			$updated[ $offer_id ] = $this->normalize_ivr_offer_message( $existing, $msg, $offer_id );
		}

		return $updated;
	}

	/**
	 * Build a normalized offer record from an IVR offer message.
	 */
	private function normalize_ivr_offer_message( $existing, $msg, $offer_id ) {
		$name = trim( (string) ( $msg['title'] ?? '' ) );
		if ( $name === '' ) {
			$name = trim( (string) ( $msg['name'] ?? '' ) );
		}
		if ( $name === '' ) {
			$name = $offer_id;
		}

		$description = trim( (string) ( $msg['content'] ?? '' ) );
		if ( $description === '' && ! empty( $existing['description'] ) ) {
			$description = $existing['description'];
		}

		$display_format = trim( (string) ( $msg['display_format'] ?? '' ) );
		if ( $display_format === '' ) {
			if ( ( $msg['type'] ?? '' ) === 'suggested_user_autoprompt' ) {
				$display_format = 'pill';
			} else {
				$display_format = $existing['display_format'] ?? 'featured';
			}
		}

		// Preserve admin status/active. Previously this always forced status=active,
		// which re-enabled sandbox offers after floscAdmin turned them off.
		if ( ! empty( $existing ) && is_array( $existing ) ) {
			$status = strtolower( (string) ( $existing['status'] ?? 'active' ) );
			if ( ! in_array( $status, array( 'active', 'inactive', 'draft' ), true ) ) {
				$status = 'active';
			}
			if ( array_key_exists( 'active', $existing ) ) {
				$is_active = ! empty( $existing['active'] );
			} else {
				$is_active = ( $status === 'active' );
			}
			// Keep status/active consistent with each other.
			if ( $status === 'active' && ! $is_active ) {
				$status = 'inactive';
			}
			if ( $is_active && $status !== 'active' ) {
				$is_active = false;
			}
		} else {
			$status    = 'active';
			$is_active = true;
		}

		$normalized = array_merge(
			$existing,
			array(
				'id'             => $offer_id,
				'name'           => $name,
				'description'    => $description,
				'headline'       => $name,
				'type'           => $existing['type'] ?? self::TYPE_ONE_TIME,
				'status'         => $status,
				'active'         => $is_active,
				'display_format' => $display_format,
				'display_price'  => $existing['display_price'] ?? '',
				'cta'            => $existing['cta'] ?? '',
				'reveal_phrase'  => trim( (string) ( $msg['user_input'] ?? ( $existing['reveal_phrase'] ?? '' ) ) ),
				'condition'      => trim( (string) ( $msg['conditions'] ?? ( $existing['condition'] ?? 'always' ) ) ),
				'timer_seconds'  => isset( $msg['timer'] ) ? intval( $msg['timer'] ) * 60 : ( $existing['timer_seconds'] ?? 0 ),
				'meta'           => array_merge(
					$existing['meta'] ?? array(),
					array(
						'icon' => $msg['icon'] ?? ( $existing['meta']['icon'] ?? '⭐' ),
					)
				),
			)
		);

		if ( empty( $normalized['display_formats'] ) || ! is_array( $normalized['display_formats'] ) ) {
			$normalized['display_formats'] = array();
		}
		if ( ! isset( $normalized['display_formats'][ $display_format ] ) ) {
			$normalized['display_formats'][ $display_format ] = array( 'enabled' => true );
		}

		return $this->validate_offer_data( $normalized );
	}

	/**
	 * Resolve the active IVR file for a flow.
	 */
	private function get_flow_ivr_file( $flow_id ) {
		$flow_key        = 'flosc_flow_' . sanitize_key( $flow_id );
		$flow_settings   = get_option( $flow_key, array() );
		$candidate_files = array();

		// Primary source: per-flow selected IVR file in settings UI.
		$active_ivr_file = sanitize_file_name( (string) ( $flow_settings['active_ivr_file'] ?? '' ) );
		if ( $active_ivr_file !== '' ) {
			$candidate_files[] = $active_ivr_file;
		}

		// Flow registry fallback: flosc_flows[flow_id].ivr_file.
		$all_flows = get_option( 'flosc_flows', array() );
		if ( is_array( $all_flows ) && ! empty( $all_flows[ $flow_id ]['ivr_file'] ) ) {
			$registry_ivr_file = sanitize_file_name( (string) $all_flows[ $flow_id ]['ivr_file'] );
			if ( $registry_ivr_file !== '' ) {
				$candidate_files[] = $registry_ivr_file;
			}
		}

		// If flow_id itself includes .md, try it directly.
		$flow_id_file = sanitize_file_name( (string) $flow_id );
		if ( substr( $flow_id_file, -3 ) === '.md' ) {
			$candidate_files[] = $flow_id_file;
		}

		// Default inference from flow_id.
		$candidate_files[] = sanitize_file_name( (string) $flow_id ) . '.md';

		$candidate_files = array_values( array_unique( array_filter( $candidate_files ) ) );

		foreach ( $candidate_files as $candidate ) {
			$path = flosc_config_file( $candidate );
			if ( file_exists( $path ) ) {
				return $path;
			}
		}

		// Return the first candidate path for diagnostics/logging if no file exists.
		$fallback = $candidate_files[0] ?? ( 'flosc_default_technical_ivr.md' );
		return flosc_config_file( $fallback );
	}

	/**
	 * Validate and normalize offer data
	 */
	private function validate_offer_data( $data ) {
		$defaults = array(
			'id'             => '',
			'name'           => '',
			'description'    => '',
			'type'           => self::TYPE_ONE_TIME,
			'status'         => 'active',

			// Pricing (provider-specific)
			'pricing'        => array(
				'stripe'       => array(
					'price_id'   => '',       // Stripe Price ID.
					'product_id' => '',     // Stripe Product ID.
				),
				'tokens'       => array(
					'cost' => 0,            // Cost in tokens.
				),
				'affiliate'    => array(
					'credit_amount' => 0,   // How much affiliate credit unlocks this.
				),
				'redirect_url' => '',       // MTS-2026-02-03: External checkout URL.
			),

			// Display pricing (for UI, not for charging)
			'display_price'  => '',          // e.g., "€144" or "500 tokens" or "Free with purchase".
			'original_price' => '',         // MTS-2026-02-03: Original price (for strikethrough)

			// MTS-2026-02-03: [DISPLAY-OPTIONS] Configurable display format.
			'display_format' => 'card',     // pill, card, compact, banner, featured, text, inline-checkout.
			'cta'            => '',                    // Custom CTA button text.
			'timer_seconds'  => 3600,        // Countdown timer (0 = no timer)
			'guarantee'      => '',              // Guarantee text (e.g., "30-day money-back guarantee")

			// For subscriptions
			'subscription'   => array(
				'interval'       => self::INTERVAL_MONTHLY,
				'interval_count' => 1,
				'trial_days'     => 0,
			),

			// For token packs
			'tokens'         => array(
				'amount' => 0,              // How many tokens this grants.
				'bonus'  => 0,               // Bonus tokens.
			),

			// Access grants.
			'grants'         => array(
				'features'      => array(),           // Feature flags to enable.
				'level'         => '',              // Member level to grant (MTS-2026-02-03)
				'duration_days' => 0,       // 0 = lifetime.
				'usage_limits'  => array(),       // e.g., ['ai_queries' => 1000]
			),

			// Metadata.
			'meta'           => array(
				'badge'   => '',              // Badge text (e.g., "Most Popular")
				'savings' => '',            // Savings text (e.g., "Save 20%")
				'icon'    => '',               // Emoji or icon.
			),

			'sort_order'     => 0,
			'created_at'     => '',
			'updated_at'     => '',
		);

		return wp_parse_args( $data, $defaults );
	}

	/**
	 * Get default offers (starter configuration)
	 */
	private function get_default_offers() {
		return array(
			'free_trial'                => array(
				'id'             => 'free_trial',
				'name'           => 'Free Trial',
				'description'    => 'Try the quiz and one free lesson',
				'type'           => self::TYPE_ONE_TIME,
				'status'         => 'active',
				'price'          => 0.00,
				'original_price' => 0.00,
				'display_price'  => 'Free',
				'pricing'        => array(
					'price'     => 0.00,
					'currency'  => 'USD',
					'processor' => 'free',
					'stripe'    => array( 'price_id' => '' ),
					'tokens'    => array( 'cost' => 0 ),
					'affiliate' => array( 'credit_amount' => 0 ),
				),
				'grants'         => array(
					'features'      => array( 'quiz', 'free_lesson' ),
					'duration_days' => 0,
					'usage_limits'  => array(
						'quizzes' => 3,
						'lessons' => 1,
					),
				),
				'meta'           => array( 'icon' => '🎁' ),
				'sort_order'     => 0,
				'created_at'     => current_time( 'mysql' ),
			),

			'full_access'               => array(
				'id'             => 'full_access',
				'name'           => 'Full Access',
				'description'    => 'Lifetime access to all lessons',
				'type'           => self::TYPE_ONE_TIME,
				'status'         => 'active',
				'price'          => 49.00,
				'original_price' => 97.00,
				'display_price'  => '$49.00',
				'headline'       => 'Get Full Access — 50% Off Today!',
				'cta'            => 'Get Full Access Now',
				'guarantee'      => 'Risk-free with our 30-day money-back guarantee',
				'pricing'        => array(
					'price'     => 49.00,
					'currency'  => 'USD',
					'processor' => 'paypal',  // Change to 'stripe' when Stripe is configured.
					'stripe'    => array(
						'price_id'   => '',
						'product_id' => '',
					),
					'tokens'    => array( 'cost' => 1000 ),
					'affiliate' => array( 'credit_amount' => 50 ),
				),
				'grants'         => array(
					'features'      => array( 'quiz', 'all_lessons', 'ai_coach', 'certificates' ),
					'level'         => 'full_access',
					'duration_days' => 0, // Lifetime.
					'usage_limits'  => array(),
				),
				'grants_level'   => 'full_access',
				'meta'           => array(
					'icon'    => '⭐',
					'badge'   => 'Best Value',
					'savings' => 'Save $48!',
				),
				'sort_order'     => 10,
				'created_at'     => current_time( 'mysql' ),
			),

			'token_pack_small'          => array(
				'id'            => 'token_pack_small',
				'name'          => '100 Tokens',
				'description'   => 'Pay-per-use credits',
				'type'          => self::TYPE_TOKENS,
				'status'        => 'draft', // Not active by default.
				'display_price' => 'Configure in Stripe',
				'pricing'       => array(
					'stripe'    => array( 'price_id' => '' ),
					'tokens'    => array( 'cost' => 0 ),
					'affiliate' => array( 'credit_amount' => 5 ),
				),
				'tokens'        => array(
					'amount' => 100,
					'bonus'  => 0,
				),
				'grants'        => array(
					'features'      => array(),
					'duration_days' => 0,
				),
				'meta'          => array( 'icon' => '🪙' ),
				'sort_order'    => 20,
				'created_at'    => current_time( 'mysql' ),
			),

			'monthly_sub'               => array(
				'id'            => 'monthly_sub',
				'name'          => 'Monthly Access',
				'description'   => 'Full access, billed monthly',
				'type'          => self::TYPE_SUBSCRIPTION,
				'status'        => 'draft', // Not active by default.
				'display_price' => 'Configure in Stripe',
				'pricing'       => array(
					'stripe'    => array( 'price_id' => '' ),
					'tokens'    => array( 'cost' => 0 ),
					'affiliate' => array( 'credit_amount' => 10 ),
				),
				'subscription'  => array(
					'interval'       => self::INTERVAL_MONTHLY,
					'interval_count' => 1,
					'trial_days'     => 7,
				),
				'grants'        => array(
					'features'      => array( 'quiz', 'all_lessons', 'ai_coach' ),
					'duration_days' => 30,
				),
				'meta'          => array( 'icon' => '📅' ),
				'sort_order'    => 30,
				'created_at'    => current_time( 'mysql' ),
			),

			// ============================================
			// Example site-owner content offers only.
			// Never seed a paid "buy the FLOSC plugin" / plugin-feature unlock.
			// (WordPress.org guidelines 5 and 9 — WPORG-01).
			// ============================================

			'simplified_solfeggio_full' => array(
				'id'             => 'simplified_solfeggio_full',
				'name'           => 'Simplified Solfeggio - Complete Course',
				'description'    => 'Master sight-singing with the Michel Hand of Music! All lessons, exercises, and lifetime access to the course.',
				'type'           => self::TYPE_ONE_TIME,
				'status'         => 'active',
				'display_price'  => '$47',
				'original_price' => '$97',
				'pricing'        => array(
					'stripe'       => array(
						'price_id'   => '',
						'product_id' => '',
					),
					'tokens'       => array( 'cost' => 0 ),
					'affiliate'    => array( 'credit_amount' => 20 ),
					'redirect_url' => '',
				),
				'display_format' => 'featured',
				'cta'            => 'Start Learning Music',
				'timer_seconds'  => 0,
				'guarantee'      => '30-day money-back guarantee',
				'grants'         => array(
					'features'      => array( 'solfeggio_lessons', 'solfeggio_exercises', 'ai_coach', 'all_quizzes' ),
					'level'         => 'simplified_solfeggio_member',
					'duration_days' => 0, // Lifetime.
					'usage_limits'  => array(),
				),
				'meta'           => array(
					'icon'    => '🎵',
					'badge'   => 'Music Course',
					'savings' => 'Save $50',
				),
				'product_id'     => 'simplified_solfeggio',
				'sort_order'     => 101,
				'created_at'     => current_time( 'mysql' ),
			),

			'pronunciation_full'        => array(
				'id'             => 'pronunciation_full',
				'name'           => 'Pronunciation — Full Access',
				'description'    => 'Full access to all American English pronunciation lessons, IPA training, audio recordings, and AI coaching.',
				'type'           => self::TYPE_SUBSCRIPTION,
				'status'         => 'active',
				'price'          => 10.00,
				'display_price'  => '$10/month or $100/year',
				'original_price' => '',
				'pricing'        => array(
					'price'        => 10.00,
					'currency'     => 'USD',
					'processor'    => 'paypal',
					'stripe'       => array(
						'price_id'   => '',
						'product_id' => '',
					),
					'tokens'       => array( 'cost' => 0 ),
					'affiliate'    => array( 'credit_amount' => 30 ),
					'redirect_url' => '',
				),
				'subscription'   => array(
					'interval'       => self::INTERVAL_MONTHLY,
					'interval_count' => 1,
					'trial_days'     => 0,
					'plans'          => array(
						'monthly' => array(
							'price' => 10.00,
							'label' => '$10/month',
						),
						'yearly'  => array(
							'price' => 100.00,
							'label' => '$100/year — save $20!',
						),
					),
				),
				'display_format' => 'featured',
				'cta'            => 'Start Learning Now',
				'timer_seconds'  => 0,
				'guarantee'      => '',
				'grants'         => array(
					'features'      => array( 'all_lessons', 'pronunciation_exercises', 'audio_recordings', 'ipa_training', 'ai_coach' ),
					'level'         => 'pronunciation_learners',
					'duration_days' => 30,
					'usage_limits'  => array(),
				),
				'grants_level'   => 'pronunciation_learners',
				'meta'           => array(
					'icon'    => '🎤',
					'badge'   => 'Pre-Launch Price',
					'savings' => 'Save $20 with yearly!',
				),
				'product_id'     => '',
				'sort_order'     => 102,
				'created_at'     => current_time( 'mysql' ),
			),
		);
	}

	/**
	 * Get offer types for admin UI
	 */
	public function get_offer_types() {
		return array(
			self::TYPE_ONE_TIME     => array(
				'label'       => 'One-Time Purchase',
				'description' => 'Single payment for lifetime or fixed-period access',
			),
			self::TYPE_SUBSCRIPTION => array(
				'label'       => 'Subscription',
				'description' => 'Recurring payment for ongoing access',
			),
			self::TYPE_TOKENS       => array(
				'label'       => 'Token Pack',
				'description' => 'Purchase credits for pay-per-use features',
			),
			self::TYPE_HYBRID       => array(
				'label'       => 'Hybrid',
				'description' => 'Subscription with included tokens',
			),
		);
	}

	/**
	 * Get subscription intervals for admin UI
	 */
	public function get_intervals() {
		return array(
			self::INTERVAL_WEEKLY  => 'Weekly',
			self::INTERVAL_MONTHLY => 'Monthly',
			self::INTERVAL_YEARLY  => 'Yearly',
		);
	}

	/**
	 * MTS-2026-02-03: [DISPLAY-FORMATS] Get available display formats for admin UI
	 */
	public function get_display_formats() {
		return array(
			'card'            => array(
				'label'       => 'Card (Default)',
				'description' => 'Rich card with content, timer, and CTA button',
				'icon'        => '🃏',
			),
			'pill'            => array(
				'label'       => 'Pill',
				'description' => 'Compact inline pill - great for PromptPanel',
				'icon'        => '💊',
			),
			'compact'         => array(
				'label'       => 'Compact Card',
				'description' => 'Smaller card with icon, title, and price',
				'icon'        => '📦',
			),
			'banner'          => array(
				'label'       => 'Banner',
				'description' => 'Full-width promotional banner',
				'icon'        => '📢',
			),
			'featured'        => array(
				'label'       => 'Featured',
				'description' => 'Large prominent card with features list',
				'icon'        => '⭐',
			),
			'text'            => array(
				'label'       => 'Text',
				'description' => 'Simple text-based with clickable link',
				'icon'        => '📝',
			),
			'inline-checkout' => array(
				'label'       => 'Inline Checkout',
				'description' => 'Stripe card form embedded in chat',
				'icon'        => '💳',
			),
		);
	}

	/**
	 * Calculate effective price from an offer for a provider
	 */
	public function get_offer_price( $offer_id, $provider_id ) {
		$offer = $this->get_offer( $offer_id );

		if ( ! $offer ) {
			return null;
		}

		return $offer['pricing'][ $provider_id ] ?? null;
	}

	/**
	 * Get offer by product ID (site-owner content products only).
	 * Does not map a paid unlock of the FLOSC plugin itself.
	 */
	public function get_offer_by_product( $product_id ) {
		$product_id = sanitize_key( (string) $product_id );
		if ( $product_id === '' || $product_id === 'flosc_plugin' ) {
			return null;
		}
		// Resolve from the named flow's default offer (instance config), not a brand map.
		$offer_id = '';
		if ( function_exists( 'flosc_get_setting' ) ) {
			$offer_id = sanitize_key( (string) flosc_get_setting( 'default_offer_id', '', $product_id ) );
		}
		if ( $offer_id === '' && function_exists( 'flosc_flows' ) ) {
			$flow = flosc_flows()->get_flow( $product_id );
			if ( is_array( $flow ) && ! empty( $flow['default_offer_id'] ) ) {
				$offer_id = sanitize_key( (string) $flow['default_offer_id'] );
			}
		}
		if ( $offer_id !== '' ) {
			return $this->get_offer( $offer_id );
		}

		return null;
	}

	/**
	 * Get member level for a site-owner content product (flow default level).
	 */
	public function get_member_level_for_product( $product_id ) {
		$product_id = sanitize_key( (string) $product_id );
		if ( $product_id === '' || $product_id === 'flosc_plugin' ) {
			return 'member';
		}
		$level = '';
		if ( function_exists( 'flosc_get_setting' ) ) {
			$level = sanitize_key( (string) flosc_get_setting( 'default_member_level', '', $product_id ) );
		}
		return $level !== '' ? $level : 'member';
	}

	/**
	 * Product IDs = configured flow IDs (site instances of FLOSC), not brand seeds.
	 */
	public function get_product_ids() {
		$ids = array();
		if ( function_exists( 'flosc_flows' ) && method_exists( flosc_flows(), 'get_all_flows' ) ) {
			$flows = flosc_flows()->get_all_flows();
			if ( is_array( $flows ) ) {
				foreach ( $flows as $flow ) {
					if ( ! is_array( $flow ) ) {
						continue;
					}
					$id = sanitize_key( (string) ( $flow['id'] ?? '' ) );
					if ( $id !== '' && $id !== 'flosc_plugin' ) {
						$ids[] = $id;
					}
				}
			}
		}
		if ( empty( $ids ) ) {
			$flows = get_option( 'flosc_flows', array() );
			if ( is_array( $flows ) ) {
				foreach ( $flows as $flow ) {
					if ( ! is_array( $flow ) ) {
						continue;
					}
					$id = sanitize_key( (string) ( $flow['id'] ?? '' ) );
					if ( $id !== '' && $id !== 'flosc_plugin' ) {
						$ids[] = $id;
					}
				}
			}
		}
		return array_values( array_unique( $ids ) );
	}

	/**
	 * Product metadata from a configured flow (instance), not hard-coded brands.
	 */
	public function get_product_metadata( $product_id ) {
		$product_id = sanitize_key( (string) $product_id );
		if ( $product_id === '' || $product_id === 'flosc_plugin' ) {
			return null;
		}
		$flow = null;
		if ( function_exists( 'flosc_flows' ) ) {
			$flow = flosc_flows()->get_flow( $product_id );
		}
		if ( ! is_array( $flow ) ) {
			$flows = get_option( 'flosc_flows', array() );
			if ( is_array( $flows ) ) {
				foreach ( $flows as $candidate ) {
					if ( is_array( $candidate ) && sanitize_key( (string) ( $candidate['id'] ?? '' ) ) === $product_id ) {
						$flow = $candidate;
						break;
					}
				}
			}
		}
		if ( ! is_array( $flow ) ) {
			return null;
		}
		$identity = is_array( $flow['identity'] ?? null ) ? $flow['identity'] : array();
		return array(
			'id'           => $product_id,
			'name'         => (string) ( $identity['name'] ?? $flow['name'] ?? $product_id ),
			'tagline'      => (string) ( $identity['tagline'] ?? $flow['tagline'] ?? '' ),
			'icon'         => (string) ( $flow['icon'] ?? '📦' ),
			'ivr_file'     => (string) ( $flow['ivr_file'] ?? $flow['ivr'] ?? '' ),
			'member_level' => $this->get_member_level_for_product( $product_id ),
			'offer_id'     => (string) ( function_exists( 'flosc_get_setting' )
				? flosc_get_setting( 'default_offer_id', '', $product_id )
				: '' ),
		);
	}
}
