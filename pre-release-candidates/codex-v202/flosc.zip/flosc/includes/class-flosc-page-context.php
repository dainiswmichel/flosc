<?php
/**
 * On-demand page/post content for AI chat context.
 * Injects access-filtered post body only when a message needs it - never on navigation.
 *
 * @package FLOSC
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Page context.
 */
class FLOSC_Page_Context {

	/**
	 * Instance.
	 *
	 * @var mixed
	 */
	private static $instance = null;

	const MAX_CONTENT_CHARS = 12000;
	const SESSION_TTL       = HOUR_IN_SECONDS;

	/**
	 * Instance.
	 *
	 * @return mixed
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Resolve and persist browsing post ID for chat logs — never loads post body.
	 *
	 * @param array $eval_context By reference.
	 */
	public function normalize_browsing_post_id( array &$eval_context ) {
		if ( ! $this->is_page_context_handoff_enabled() ) {
			return;
		}

		/*
		 * A BuddyBoss group page is not a WordPress post, so resolving a post
		 * id for a site's own BuddyBoss group URL returns nothing and
		 * the companion arrives on that page knowing nothing about it.
		 *
		 * Record the group instead. The chatpack's group catalogue already
		 * carries the row; this just says which one the person is looking at.
		 */
		if ( function_exists( 'bp_is_group' ) && function_exists( 'bp_get_current_group_id' ) && bp_is_group() ) {
			$flosc_group_id = (int) bp_get_current_group_id();
			if ( $flosc_group_id > 0 ) {
				$eval_context['browsing_row_id'] = 'bb_group:' . $flosc_group_id;
				if ( empty( $eval_context['browsing_page_title'] ) && function_exists( 'bp_get_current_group_name' ) ) {
					$eval_context['browsing_page_title'] = sanitize_text_field( (string) bp_get_current_group_name() );
				}
				return;
			}
		}

		$current_id = $this->resolve_current_browsing_post_id( $eval_context );
		if ( $current_id <= 0 ) {
			return;
		}

		$eval_context['browsing_page_post_id'] = $current_id;

		$post = get_post( $current_id );
		if ( $post ) {
			if ( empty( $eval_context['browsing_page_title'] ) ) {
				$eval_context['browsing_page_title'] = sanitize_text_field( (string) get_the_title( $post ) );
			}
			if ( empty( $eval_context['browsing_page_url'] ) ) {
				$permalink = get_permalink( $post );
				if ( is_string( $permalink ) && '' !== $permalink ) {
					$eval_context['browsing_page_url'] = esc_url_raw( $permalink );
				}
			}
		}
	}

	/**
	 * Find a link when the current post or one accessible index entry is named.
	 *
	 * @param string $message      Visitor message.
	 * @param array  $eval_context Chat context.
	 * @param string $flow_id      Flow stem, for legacy per-flow indexes.
	 * @return string Page link reply, or an empty string when no clear match exists.
	 */
	public function find_named_page_reply( $message, array $eval_context, $flow_id ) {
		if ( ! $this->is_page_context_handoff_enabled() ) {
			return '';
		}

		$query = $this->normalize_page_name( $message );
		if ( false === strpos( $query, '-' ) ) {
			return '';
		}

		$index        = FLOSC_Site_Content_Index::instance();
		$document     = $index->load( $flow_id );
		$rows         = $document['posts'];
		$current_id   = absint( $eval_context['browsing_page_post_id'] ?? 0 );
		$access_level = (string) ( $eval_context['access_level'] ?? 'visitor' );
		$current_row  = $rows[ $current_id ] ?? array();

		if ( $current_id && empty( $current_row['excluded'] ) && 'title' !== $index->row_depth( $current_row, $access_level ) ) {
			$current_reply = $this->get_named_post_link( $current_id, $query );
			if ( '' !== $current_reply ) {
				return $current_reply;
			}
		}

		$reply = '';
		foreach ( $rows as $row ) {
			$post_id = absint( $row['post_id'] ?? 0 );
			if ( ! $post_id || $current_id === $post_id || ! empty( $row['excluded'] ) || 'title' === $index->row_depth( $row, $access_level ) ) {
				continue;
			}

			$path = (string) wp_parse_url( (string) ( $row['url'] ?? '' ), PHP_URL_PATH );
			if ( ! $this->query_names_page( $query, (string) ( $row['title'] ?? '' ), wp_basename( untrailingslashit( $path ) ) ) ) {
				continue;
			}

			$candidate = $this->get_named_post_link( $post_id, $query );
			if ( '' === $candidate ) {
				continue;
			}
			if ( '' !== $reply ) {
				return '';
			}
			$reply = $candidate;
		}

		return $reply;
	}

	/**
	 * Revalidate an index or browsing match against the live WordPress post.
	 *
	 * @param int    $post_id Post ID.
	 * @param string $query   Normalized message.
	 * @return string Page link reply or an empty string.
	 */
	private function get_named_post_link( $post_id, $query ) {
		$post = get_post( $post_id );
		if ( ! $post || 'publish' !== $post->post_status || ! is_post_publicly_viewable( $post ) || '' !== $post->post_password ) {
			return '';
		}

		$title = sanitize_text_field( html_entity_decode( get_the_title( $post ), ENT_QUOTES, 'UTF-8' ) );
		if ( '' === $title || ! $this->query_names_page( $query, $title, $post->post_name ) ) {
			return '';
		}

		if ( ! FLOSC_Content_Protection::instance()->user_can_access( $post_id ) ) {
			return '';
		}

		$url = esc_url_raw( (string) get_permalink( $post ), array( 'http', 'https' ) );
		if ( '' === $url ) {
			return '';
		}

		return sprintf(
			/* translators: 1: WordPress post title, 2: link to the post. */
			__( "You can find %1\$s here:\n%2\$s", 'flosc' ),
			$title,
			$url
		);
	}

	/**
	 * Compare whole titles or slugs instead of partial keyword hits.
	 *
	 * @param string $query Normalized message.
	 * @param string $title WordPress post title.
	 * @param string $slug  WordPress post slug.
	 * @return bool
	 */
	private function query_names_page( $query, $title, $slug ) {
		foreach ( array( $title, $slug ) as $name ) {
			$name = $this->normalize_page_name( $name );
			if ( false !== strpos( $name, '-' ) && false !== strpos( '-' . $query . '-', '-' . $name . '-' ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Normalize text with the same conventions WordPress uses for slugs.
	 *
	 * @param string $text Message, title, or slug.
	 * @return string
	 */
	private function normalize_page_name( $text ) {
		return sanitize_title( html_entity_decode( $text, ENT_QUOTES, 'UTF-8' ) );
	}

	/**
	 * Attach post content to eval_context when the user message warrants it.
	 *
	 * @param array  $eval_context By reference.
	 * @param string $message      User message.
	 * @param string $session_key  Visitor session id or server session id string.
	 */
	public function maybe_attach_to_context( array &$eval_context, $message, $session_key = '' ) {
		if ( ! $this->is_page_context_handoff_enabled() ) {
			return;
		}

		$message = trim( (string) $message );
		if ( '' === $message ) {
			return;
		}

		$this->normalize_browsing_post_id( $eval_context );

		// Location-only questions need title/URL/post ID (already in chatpack) — not full body.
		if ( $this->message_is_page_location_query( $message ) ) {
			return;
		}

		$post_id = $this->resolve_post_id_for_content_injection( $eval_context, $message, $session_key );
		if ( $post_id <= 0 ) {
			return;
		}

		$access_level = sanitize_key( (string) ( $eval_context['access_level'] ?? 'visitor' ) );
		$user_id      = absint( $eval_context['user_id'] ?? 0 );
		$content      = $this->load_post_content( $post_id, $access_level );

		if ( '' === $content ) {
			return;
		}

		$post                                  = get_post( $post_id );
		$eval_context['browsing_page_post_id'] = $post_id;
		$eval_context['browsing_page_content'] = $content;
		$eval_context['page_content_injected'] = true;

		if ( $post && empty( $eval_context['browsing_page_title'] ) ) {
			$eval_context['browsing_page_title'] = sanitize_text_field( (string) get_the_title( $post ) );
		}

		if ( '' !== $session_key ) {
			set_transient( $this->session_transient_key( $session_key ), $post_id, self::SESSION_TTL );
		}
	}

	/**
	 * Session transient key.
	 *
	 * @param mixed $session_key Session key.
	 * @return mixed
	 */
	private function session_transient_key( $session_key ) {
		return 'flosc_page_focus_' . md5( sanitize_text_field( (string) $session_key ) );
	}

	/**
	 * Get session focus post ID.
	 *
	 * @param mixed $session_key Session key.
	 * @return mixed
	 */
	private function get_session_focus_post_id( $session_key ) {
		if ( '' === $session_key ) {
			return 0;
		}
		return absint( get_transient( $this->session_transient_key( $session_key ) ) );
	}

	/**
	 * Is page context handoff enabled.
	 *
	 * @return mixed
	 */
	private function is_page_context_handoff_enabled() {
		$pass_page_context = flosc_get_setting( 'companion_pass_page_context', '1' );
		return filter_var( $pass_page_context, FILTER_VALIDATE_BOOLEAN );
	}

	/**
	 * Resolve current browsing post ID.
	 *
	 * @param array $eval_context Eval context.
	 * @return mixed
	 */
	private function resolve_current_browsing_post_id( array $eval_context ) {
		// Companion already hands off the post ID — trust it when valid.
		$explicit_id = absint( $eval_context['browsing_page_post_id'] ?? 0 );
		if ( $explicit_id > 0 ) {
			$resolved = $this->resolve_post_id( $explicit_id );
			if ( $resolved > 0 ) {
				return $resolved;
			}
		}

		$page_url = esc_url_raw( (string) ( $eval_context['browsing_page_url'] ?? '' ) );
		if ( '' !== $page_url ) {
			return $this->resolve_post_id_from_url( $page_url );
		}

		return 0;
	}

	/**
	 * Resolve post ID for content injection.
	 *
	 * @param array $eval_context Eval context.
	 * @param mixed $message      Message.
	 * @param mixed $session_key  Session key.
	 * @return mixed
	 */
	private function resolve_post_id_for_content_injection( array $eval_context, $message, $session_key ) {
		$current_id = absint( $eval_context['browsing_page_post_id'] ?? 0 );
		if ( $current_id <= 0 ) {
			return 0;
		}

		$title         = sanitize_text_field( (string) ( $eval_context['browsing_page_title'] ?? '' ) );
		$session_focus = $this->get_session_focus_post_id( $session_key );

		// Follow-up on same focused page (reuse cached focus, no re-ingest every turn).
		if ( $session_focus > 0 && $current_id === $session_focus && $this->message_is_short_followup( $message ) ) {
			return $session_focus;
		}

		// On-demand body load: only when the user message targets this page/post/product.
		if ( $this->message_targets_current_page( $message, $title ) ) {
			return $current_id;
		}

		return 0;
	}

	/**
	 * Resolve post ID.
	 *
	 * @param mixed $explicit_id Explicit ID.
	 * @return mixed
	 */
	private function resolve_post_id( $explicit_id ) {
		if ( $explicit_id > 0 ) {
			$post = get_post( $explicit_id );
			if ( $post && 'publish' === $post->post_status ) {
				return (int) $post->ID;
			}
		}

		return 0;
	}

	/**
	 * Resolve post ID from URL.
	 *
	 * @param mixed $url URL.
	 * @return mixed
	 */
	private function resolve_post_id_from_url( $url ) {
		$url = esc_url_raw( (string) $url );
		if ( '' === $url ) {
			return 0;
		}

		$site_host = wp_parse_url( home_url(), PHP_URL_HOST );
		$url_host  = wp_parse_url( $url, PHP_URL_HOST );
		if ( $site_host && $url_host && strtolower( (string) $site_host ) !== strtolower( (string) $url_host ) ) {
			return 0;
		}

		$candidates = array( $url );
		$parsed     = wp_parse_url( $url );
		if ( ! empty( $parsed['path'] ) ) {
			$path_only    = home_url( $parsed['path'] );
			$candidates[] = $path_only;
			$candidates[] = trailingslashit( $path_only );
			$candidates[] = untrailingslashit( $path_only );
		}

		foreach ( array_unique( $candidates ) as $candidate ) {
			$resolved = $this->resolve_post_id( absint( url_to_postid( $candidate ) ) );
			if ( $resolved > 0 ) {
				return $resolved;
			}
		}

		return 0;
	}

	/**
	 * Message is page location query.
	 *
	 * @param mixed $message Message.
	 * @return mixed
	 */
	private function message_is_page_location_query( $message ) {
		$msg = strtolower( trim( (string) $message ) );
		if ( '' === $msg ) {
			return false;
		}

		return (bool) preg_match(
			'/\b(what page|which page|where am i|page am i on|page i\'m on|page i am on|current page|am i on)\b/',
			$msg
		);
	}

	/**
	 * Message targets current page.
	 *
	 * @param mixed $message Message.
	 * @param mixed $title   Title.
	 * @return mixed
	 */
	private function message_targets_current_page( $message, $title ) {
		$msg = strtolower( trim( $message ) );

		foreach ( $this->get_page_intent_phrases() as $phrase ) {
			if ( '' !== $phrase && false !== strpos( $msg, $phrase ) ) {
				return true;
			}
		}

		if ( '' !== $title && strlen( $title ) > 4 ) {
			$title_clean = strtolower( preg_replace( '/[^a-z0-9\s]/', ' ', $title ) );
			$words       = array_filter(
				explode( ' ', $title_clean ),
				function ( $w ) {
					return strlen( $w ) > 3;
				}
			);
			$hits        = 0;
			foreach ( $words as $word ) {
				if ( false !== strpos( $msg, $word ) ) {
					++$hits;
				}
			}
			if ( $hits >= 2 ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Page-intent phrases the AI treats as "the user is asking about the current page,"
	 * which triggers on-demand page-content injection. Ships with the FLOSC defaults;
	 * floscAdmins append their own via the per-flow "Page Intent Phrases" setting (one per
	 * line or comma-separated), and extensions can adjust the final list via the filter.
	 * Matching is lowercase substring.
	 *
	 * @return string[]
	 */
	private function get_page_intent_phrases() {
		$defaults = array(
			'this page',
			'this post',
			'this product',
			'this course',
			'this song',
			'this article',
			'this item',
			'this listing',
			'this lesson',
			'more about this',
			'about this',
			'about the song',
			'about the page',
			'about the post',
			'about the product',
			'about the article',
			'about the lesson',
			'about the course',
			'about the item',
			'what i\'m looking at',
			'what i am looking at',
			'on this page',
			'tell me about this',
			'what is this',
			'explain this',
			'describe this',
			'summarize this',
			'summary of this',
			'read this',
			'page content',
			'product description',
			'post content',
			'looking at this',
			'what\'s this',
			'whats this',
			'what is this page',
			'what\'s this page',
			'what is this about',
			'what\'s this about',
			'what\'s on this page',
			'what is this product',
			'what\'s this product',
			'what is this lesson',
			'what\'s this lesson',
			'tell me about this page',
			'tell me about this product',
			'tell me about this lesson',
		);

		// floscAdmin additions — per-flow setting, one phrase per line (or comma-separated).
		$custom = array();
		$raw    = (string) flosc_get_setting( 'companion_page_intent_phrases', '' );
		if ( '' !== $raw ) {
			foreach ( preg_split( '/[\r\n,]+/', $raw ) as $line ) {
				$line = strtolower( trim( (string) $line ) );
				if ( '' !== $line ) {
					$custom[] = $line;
				}
			}
		}

		$phrases = array_values( array_unique( array_merge( $defaults, $custom ) ) );

		/**
		 * Filter the page-intent phrase list (shipped defaults + admin additions).
		 *
		 * @param string[] $phrases Lowercase substrings that mark a page-content question.
		 */
		$phrases = apply_filters( 'flosc_companion_page_intent_phrases', $phrases );

		return is_array( $phrases ) ? $phrases : $defaults;
	}

	/**
	 * Message is short followup.
	 *
	 * @param mixed $message Message.
	 * @return mixed
	 */
	private function message_is_short_followup( $message ) {
		$msg = strtolower( trim( $message ) );

		if ( '' === $msg ) {
			return false;
		}

		// Language/meta conversation choices are not page-content follow-ups.
		if ( preg_match( '/\b(english|latvian|german|spanish|french|language|prefer|servus|sveiks)\b/i', $msg ) ) {
			return false;
		}

		// Explicit continuation confirmations.
		if ( in_array( $msg, array( 'yes', 'yeah', 'yep', 'sure', 'please', 'ok', 'okay' ), true ) ) {
			return true;
		}

		// Pronoun-based continuation of the current page/topic.
		if ( preg_match( '/\b(it|its|this|that|these|those|they|them|there)\b/', $msg ) ) {
			return true;
		}

		// Short question-style follow-ups are likely same-thread continuations.
		if (
			strlen( $msg ) <= 120
			&& preg_match( '/^(what|how|why|where|when|which|who|can|could|would|should|do|does|did|is|are|was|were)\b/', $msg )
			&& ! preg_match( '/\b(testimonial|testimonials|review|reviews|another page|different page|new page|other page)\b/', $msg )
		) {
			return true;
		}

		return false;
	}

	/**
	 * Load post content.
	 *
	 * @param mixed $post_id      Post ID.
	 * @param mixed $access_level Access level.
	 * @return mixed
	 */
	private function load_post_content( $post_id, $access_level ) {
		$post = get_post( $post_id );
		if ( ! $post || 'publish' !== $post->post_status ) {
			return '';
		}

		$raw = $post->post_content;

		$protection = FLOSC_Content_Protection::instance();
		$check      = $protection->check_post_protection( $post_id );

		if ( ! empty( $check['protected'] ) ) {
			if ( ! $protection->user_can_access( $post_id ) ) {
				$visibility = $protection->get_post_visibility( $post_id );
				$raw        = $protection->apply_visibility_tier( $raw, $visibility, $post_id );
			}
		}

		$filter = FLOSC_Content_Filter::instance();
		$raw    = $filter->filter_post_content( $raw, $access_level );

		$text = wp_strip_all_tags( $raw );
		$text = preg_replace( '/\s+/u', ' ', $text );
		$text = trim( $text );

		if ( '' === $text ) {
			return '';
		}

		if ( strlen( $text ) > self::MAX_CONTENT_CHARS ) {
			$text = substr( $text, 0, self::MAX_CONTENT_CHARS ) . '...';
		}

		return $text;
	}
}
