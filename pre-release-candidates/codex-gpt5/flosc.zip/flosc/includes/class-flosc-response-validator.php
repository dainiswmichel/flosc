<?php
/**
 * FLOSC Response Validator
 * Last-resort validation of AI outputs before showing to users
 *
 * @package FLOSC
 * @since 1.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Response validator.
 */
class FLOSC_Response_Validator {

	/**
	 * User session.
	 *
	 * @var mixed
	 */
	private $flosc_user_session;

	/**
	 * Construct.
	 *
	 * @param mixed $flosc_user_session User session.
	 */
	public function __construct( $flosc_user_session ) {
		$this->flosc_user_session = $flosc_user_session;
	}

	/**
	 * Validate AI response
	 *
	 * @param string $flosc_response AI response text.
	 * @param array  $flosc_tool_calls_made Tools that were called.
	 * @return array Validation result
	 */
	public function flosc_validate( $flosc_response, $flosc_tool_calls_made = array() ) {
		$flosc_violations = array();

		// Check 1: Lesson content without tool use.
		if ( $this->flosc_contains_lesson_content( $flosc_response ) &&
			! $this->flosc_used_lesson_tool( $flosc_tool_calls_made ) ) {
			$flosc_violations[] = 'lesson_content_without_tool';
		}

		// Check 2: Pricing to visitors.
		if ( $this->flosc_contains_pricing( $flosc_response ) &&
			'flosc_visitor' === $this->flosc_user_session->flosc_get( 'flosc_user_type' ) ) {
			$flosc_violations[] = 'premature_pricing';
		}

		if ( empty( $flosc_violations ) ) {
			return array(
				'flosc_valid'    => true,
				'flosc_response' => $flosc_response,
			);
		}

		if ( defined( 'FLOSC_DEBUG' ) && FLOSC_DEBUG ) {
			if ( defined( 'FLOSC_DEBUG' ) && FLOSC_DEBUG ) {
				flosc_log( 'FLOSC Response Integrity Violation: ' . implode( ', ', $flosc_violations ) );
			}
		}

		return array(
			'flosc_valid'      => false,
			'flosc_violations' => $flosc_violations,
			'flosc_response'   => $this->flosc_get_override_response(),
		);
	}

	/**
	 * Contains lesson content.
	 *
	 * @param mixed $flosc_response Response.
	 * @return mixed
	 */
	private function flosc_contains_lesson_content( $flosc_response ) {
		return strlen( $flosc_response ) > 3000 || preg_match( '/^Lesson \d+:/m', $flosc_response );
	}

	/**
	 * Used lesson tool.
	 *
	 * @param mixed $flosc_tool_calls Tool calls.
	 * @return mixed
	 */
	private function flosc_used_lesson_tool( $flosc_tool_calls ) {
		foreach ( $flosc_tool_calls as $flosc_call ) {
			if ( in_array( $flosc_call['name'], array( 'flosc_get_lesson_content', 'flosc_deliver_free_lesson' ), true ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Contains pricing.
	 *
	 * @param mixed $flosc_response Response.
	 * @return mixed
	 */
	private function flosc_contains_pricing( $flosc_response ) {
		$flosc_keywords = array( '$', 'price', 'cost', 'pay', 'purchase', 'buy' );
		foreach ( $flosc_keywords as $flosc_keyword ) {
			if ( false !== stripos( $flosc_response, $flosc_keyword ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Get override response.
	 *
	 * @return mixed
	 */
	private function flosc_get_override_response() {
		$flosc_user_type = $this->flosc_user_session->flosc_get( 'flosc_user_type' );

		$flosc_overrides = array(
			'flosc_visitor' => "I'd love to help! First, take our quick 2-minute quiz to get your personalized free lesson. 🎯",
			'flosc_guest'   => 'To access all lessons, unlock full access and continue your learning journey. ✨',
		);

		return $flosc_overrides[ $flosc_user_type ] ?? 'Let me rephrase that.';
	}
}
