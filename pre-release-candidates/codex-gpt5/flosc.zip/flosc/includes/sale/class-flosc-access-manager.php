<?php
/**
 * FLOSC Access Manager
 *
 * Manages user access based on:
 * - Purchased offers
 * - Active subscriptions
 * - Token balances
 * - Feature flags
 * - Usage limits
 * - Expiration dates
 *
 * User States (FLOSC determines):
 * - visitor: not logged in
 * - guest: logged in, hasn't paid
 * - member: has paid (has active offer or subscription)
 *
 * @package FLOSC
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Access manager.
 */
class FLOSC_Access_Manager {

	/**
	 * Meta key.
	 *
	 * @var string
	 */
	private $meta_key = '_flosc_access';

	/**
	 * Get user's complete access state
	 *
	 * @param mixed $user_id User ID.
	 */
	public function get_user_access( $user_id ) {
		$access = get_user_meta( $user_id, $this->meta_key, true );
		if ( ! $access ) {
			$access = array();
		}

		return wp_parse_args(
			$access,
			array(
				'features'     => array(),
				'offers'       => array(),          // Purchased offers and their grants.
				'subscription' => null,  // Active subscription details.
				'expires_at'   => null,    // Overall access expiration.
				'granted_at'   => null,
				'updated_at'   => null,
			)
		);
	}

	/**
	 * Normalize a flow id / ivr path to the stem used in flosc_flow_* options and meta.
	 *
	 * @param string|null $flow_id Flow id, ivr filename, or stem. Empty → current flow when available.
	 * @return string Stem or '' when none can be resolved.
	 */
	public function normalize_flow_stem( $flow_id = null ) {
		$raw = is_string( $flow_id ) || is_numeric( $flow_id ) ? (string) $flow_id : '';
		if ( '' === $raw && function_exists( 'flosc' ) && is_object( flosc() ) && method_exists( flosc(), 'get_current_flow' ) ) {
			$flow = flosc()->get_current_flow();
			if ( is_array( $flow ) ) {
				$raw = (string) ( $flow['ivr_file'] ?? $flow['ivr'] ?? $flow['id'] ?? '' );
			}
		}
		$stem = sanitize_key( pathinfo( basename( $raw ), PATHINFO_FILENAME ) );
		if ( '' === $stem && '' !== $raw ) {
			$stem = sanitize_key( $raw );
		}
		return $stem;
	}

	/**
	 * Member levels that grant paid access on a given flow (never guest* roles).
	 *
	 * @param string $stem Flow stem.
	 * @return string[]
	 */
	public function get_flow_member_levels( $stem ) {
		$stem   = sanitize_key( (string) $stem );
		$levels = array();
		if ( '' === $stem ) {
			return $levels;
		}

		$flows = get_option( 'flosc_flows', array() );
		if ( is_array( $flows ) ) {
			foreach ( $flows as $flow ) {
				if ( ! is_array( $flow ) ) {
					continue;
				}
				$id        = sanitize_key( (string) ( $flow['id'] ?? '' ) );
				$ivr       = (string) ( $flow['ivr_file'] ?? $flow['ivr'] ?? '' );
				$flow_stem = sanitize_key( pathinfo( basename( $ivr ), PATHINFO_FILENAME ) );
				if ( '' === $flow_stem ) {
					$flow_stem = $id;
				}
				if ( $flow_stem !== $stem && $id !== $stem ) {
					continue;
				}
				$default = sanitize_key( (string) ( $flow['default_member_level'] ?? '' ) );
				if ( '' !== $default ) {
					$levels[] = $default;
				}
				$ml = $flow['member_levels'] ?? array();
				if ( is_array( $ml ) ) {
					foreach ( array_keys( $ml ) as $k ) {
						$k = sanitize_key( (string) $k );
						if ( '' !== $k ) {
							$levels[] = $k;
						}
					}
				}
			}
		}

		$settings = get_option( 'flosc_flow_' . $stem, array() );
		if ( is_array( $settings ) ) {
			$default = sanitize_key( (string) ( $settings['default_member_level'] ?? '' ) );
			if ( '' !== $default ) {
				$levels[] = $default;
			}
			if ( ! empty( $settings['member_level'] ) ) {
				$levels[] = sanitize_key( (string) $settings['member_level'] );
			}
		}

		// Do NOT call flosc_get_setting() here: without a real flow row it falls back
		// to global flosc_default_member_level (often pronunciation_learners) and
		// incorrectly treats every flow as member-eligible.

		$levels = array_values( array_unique( array_filter( $levels ) ) );
		// Paid levels only — guest roles are not membership.
		return array_values(
			array_filter(
				$levels,
				static function ( $level ) {
					return '' !== $level && false === strpos( $level, 'guest' );
				}
			)
		);
	}

	/**
	 * Check if user is a member for a flow (or any flow when $flow_id is null and no current flow).
	 *
	 * Per-flow rules (when a stem is known):
	 * - Explicit _flosc_member_access_{stem}
	 * - Holds a paid level declared by that flow
	 * - Active offer / purchase history for that flow
	 * - Does NOT treat global _flosc_member_access or any other-flow roles as membership on other flows
	 *
	 * @param int         $user_id User ID.
	 * @param string|null $flow_id Flow id / ivr / stem. Null = resolve current flow when possible.
	 * @return bool
	 */
	public function is_member( $user_id, $flow_id = null ) {
		if ( ! $user_id ) {
			return false;
		}

		// WordPress admins: member for content testing on every surface.
		if ( user_can( $user_id, 'manage_options' ) ) {
			return true;
		}

		$stem = $this->normalize_flow_stem( $flow_id );
		if ( '' !== $stem ) {
			return $this->is_member_of_flow( (int) $user_id, $stem );
		}

		// No flow context (admin tools, non-app requests): any paid entitlement.
		return $this->is_member_any_flow( (int) $user_id );
	}

	/**
	 * Membership on one flow only (FLOSC framework rule).
	 *
	 * Product brands (categories, lesson libraries, instance role names) are
	 * per-flow configuration — not FLOSC core. Membership is:
	 * 1) per-flow grant meta, 2) offers/purchases for this flow, 3) member
	 * levels declared on this flow only (never a global product brand branch).
	 *
	 * @param int    $user_id User ID.
	 * @param string $stem Stem.
	 * @return bool
	 */
	public function is_member_of_flow( $user_id, $stem ) {
		$user_id = (int) $user_id;
		$stem    = sanitize_key( (string) $stem );
		if ( $user_id <= 0 || '' === $stem ) {
			return false;
		}

		// 1) Explicit per-flow grant (purchase / access code / sandbox for this flow).
		$flag = get_user_meta( $user_id, '_flosc_member_access_' . $stem, true );
		if ( 'true' === $flag || true === $flag || '1' === $flag || 'yes' === $flag ) {
			return true;
		}

		// 2) Offers / purchase ledger tagged to this flow only.
		if ( $this->has_active_offer_for_flow( $user_id, $stem ) ) {
			return true;
		}
		if ( $this->has_purchase_history_for_flow( $user_id, $stem ) ) {
			return true;
		}

		// 3) Levels listed on THIS flow only — prevents cross-flow bleed when
		// several flows share a similar default level name in config.
		if ( class_exists( 'FLOSC_Member_Access' ) ) {
			require_once FLOSC_PLUGIN_DIR . 'includes/class-flosc-member-access.php';
			$ma = FLOSC_Member_Access::instance();
			foreach ( $this->get_flow_member_levels( $stem ) as $level ) {
				if ( $ma->has_level( $user_id, $level ) ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Has purchase history for flow.
	 *
	 * @param int    $user_id User ID.
	 * @param string $stem Stem.
	 * @return bool
	 */
	private function has_purchase_history_for_flow( $user_id, $stem ) {
		$history = get_user_meta( $user_id, '_flosc_purchase_history', true );
		if ( ! is_array( $history ) ) {
			return false;
		}
		$stem = sanitize_key( (string) $stem );
		foreach ( $history as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$row_raw  = (string) ( $row['flow_id'] ?? '' );
			$row_stem = sanitize_key( pathinfo( basename( $row_raw ), PATHINFO_FILENAME ) );
			if ( '' === $row_stem ) {
				$row_stem = sanitize_key( $row_raw );
			}
			if ( '' !== $row_stem && $row_stem === $stem ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * True when the user holds paid access on at least one flow (legacy / no-context).
	 *
	 * @param int $user_id User ID.
	 * @return bool
	 */
	public function is_member_any_flow( $user_id ) {
		$user_id = (int) $user_id;
		if ( $user_id <= 0 ) {
			return false;
		}

		$access = $this->get_user_access( $user_id );
		if ( ! empty( $access['offers'] ) ) {
			foreach ( $access['offers'] as $offer_data ) {
				if ( $this->is_offer_active( $offer_data ) ) {
					return true;
				}
			}
		}
		if ( ! empty( $access['subscription'] ) && $this->is_subscription_active( $access['subscription'] ) ) {
			return true;
		}

		// Any explicit per-flow member flag (core usermeta API).
		$all_meta = get_user_meta( (int) $user_id );
		if ( is_array( $all_meta ) ) {
			foreach ( $all_meta as $meta_key => $vals ) {
				$meta_key = (string) $meta_key;
				if ( 0 !== strpos( $meta_key, '_flosc_member_access_' ) ) {
					continue;
				}
				$raw = is_array( $vals ) ? ( $vals[0] ?? '' ) : $vals;
				$raw = is_string( $raw ) || is_numeric( $raw ) || is_bool( $raw ) ? (string) $raw : '';
				if ( in_array( $raw, array( 'true', '1', 'yes' ), true ) ) {
					return true;
				}
			}
		}

		// Legacy global flag or any non-guest member level meta.
		$global = get_user_meta( $user_id, '_flosc_member_access', true );
		if ( 'true' === $global || true === $global || '1' === $global ) {
			return true;
		}

		if ( class_exists( 'FLOSC_Member_Access' ) ) {
			require_once FLOSC_PLUGIN_DIR . 'includes/class-flosc-member-access.php';
			$ma = FLOSC_Member_Access::instance();
			foreach ( (array) $ma->get_user_levels( $user_id ) as $level ) {
				$level = sanitize_key( (string) $level );
				if ( '' !== $level && false === strpos( $level, 'guest' ) ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Whether an active _flosc_access offer belongs to this flow.
	 *
	 * @param int    $user_id User ID.
	 * @param string $stem Stem.
	 * @return bool
	 */
	private function has_active_offer_for_flow( $user_id, $stem ) {
		$access = $this->get_user_access( $user_id );
		if ( empty( $access['offers'] ) || ! is_array( $access['offers'] ) ) {
			return false;
		}

		$offer_manager = null;
		if ( function_exists( 'flosc_sale' ) && flosc_sale() && method_exists( flosc_sale(), 'offers' ) ) {
			$offer_manager = flosc_sale()->offers();
		}

		foreach ( $access['offers'] as $offer_id => $offer_data ) {
			if ( ! $this->is_offer_active( $offer_data ) ) {
				continue;
			}
			// Require explicit flow_id on the grant — do not treat "offer id exists
			// in this flow's catalog" as purchase of this flow (cross-flow bleed).
			$offer_flow = sanitize_key( (string) ( $offer_data['flow_id'] ?? '' ) );
			if ( '' === $offer_flow ) {
				continue;
			}
			$offer_stem = sanitize_key( pathinfo( basename( $offer_flow ), PATHINFO_FILENAME ) );
			if ( '' === $offer_stem ) {
				$offer_stem = $offer_flow;
			}
			if ( $offer_stem === $stem || $offer_flow === $stem ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Check if user has a specific feature
	 *
	 * @param mixed $user_id User ID.
	 * @param mixed $feature Feature.
	 */
	public function has_feature( $user_id, $feature ) {
		$access  = $this->get_user_access( $user_id );
		$feature = (string) $feature;

		// Check explicit feature flags.
		if ( in_array( $feature, $access['features'], true ) ) {
			return true;
		}

		// Check offers for feature grants.
		foreach ( $access['offers'] as $offer_id => $offer_data ) {
			if ( isset( $offer_data['grants']['features'] ) &&
				in_array( $feature, $offer_data['grants']['features'], true ) ) {

				// Check if offer has expired.
				if ( $this->is_offer_active( $offer_data ) ) {
					return true;
				}
			}
		}

		// Content features for members with flow-scoped membership but empty _flosc_access.
		$member_content_features = array(
			'all_lessons',
			'full_access',
			'pronunciation_exercises',
			'audio_recordings',
			'ipa_training',
			'ai_coach',
		);
		/**
		 * Extra feature slugs that count as full-member content for a flow instance.
		 *
		 * @param string[] $features
		 * @param int      $user_id
		 */
		$member_content_features = apply_filters( 'flosc_member_content_features', $member_content_features, $user_id );
		if ( ! is_array( $member_content_features ) ) {
			$member_content_features = array( 'all_lessons', 'full_access' );
		}
		if ( in_array( $feature, $member_content_features, true ) && $this->is_member( $user_id ) ) {
			return true;
		}

		return false;
	}

	/**
	 * Check if user can access something (feature or custom check).
	 *
	 * String aliases:
	 * - 'full' / 'member' → any full member (offer, subscription, or FLOSC_Member_Access)
	 * - other strings → feature flag via has_feature()
	 *
	 * @param mixed $user_id     User ID.
	 * @param mixed $requirement Requirement.
	 */
	public function can_access( $user_id, $requirement ) {
		// If requirement is a feature name.
		if ( is_string( $requirement ) ) {
			$requirement = strtolower( trim( $requirement ) );
			// Full membership (not a narrow feature id) — keep userState consistent for AI/IVR.
			if ( 'full' === $requirement || 'member' === $requirement ) {
				return $this->is_member( $user_id );
			}
			return $this->has_feature( $user_id, $requirement );
		}

		// If requirement is an array with conditions.
		if ( is_array( $requirement ) ) {
			// Check feature requirement.
			if ( isset( $requirement['feature'] ) ) {
				if ( ! $this->has_feature( $user_id, $requirement['feature'] ) ) {
					return false;
				}
			}

			// Check offer requirement.
			if ( isset( $requirement['offer'] ) ) {
				if ( ! $this->has_offer( $user_id, $requirement['offer'] ) ) {
					return false;
				}
			}

			return true;
		}

		return false;
	}

	/**
	 * Grant access from an offer purchase
	 *
	 * @param mixed $user_id     User ID.
	 * @param mixed $offer       Offer.
	 * @param mixed $transaction Transaction.
	 */
	public function grant_from_offer( $user_id, $offer, $transaction = array() ) {
		$access = $this->get_user_access( $user_id );

		// Record the offer purchase.
		$offer_flow_id = (string) ( $transaction['flow_id'] ?? $offer['flow_id'] ?? '' );
		if ( '' === $offer_flow_id ) {
			$offer_flow_id = $this->normalize_flow_stem( null );
		}
		$access['offers'][ $offer['id'] ] = array(
			'purchased_at' => current_time( 'mysql' ),
			'transaction'  => $transaction,
			'grants'       => $offer['grants'],
			'expires_at'   => $this->calculate_expiration( $offer ),
			'flow_id'      => $offer_flow_id,
		);

		// Apply grants.
		$grants = $offer['grants'];

		// Merge features.
		if ( ! empty( $grants['features'] ) ) {
			$access['features'] = array_unique(
				array_merge(
					$access['features'],
					$grants['features']
				)
			);
		}

		// Set/extend expiration.
		if ( ! empty( $grants['duration_days'] ) && $grants['duration_days'] > 0 ) {
			$new_expiration = gmdate( 'Y-m-d H:i:s', strtotime( '+' . $grants['duration_days'] . ' days' ) );

			// Extend if already has access.
			if ( $access['expires_at'] ) {
				$current              = strtotime( $access['expires_at'] );
				$new                  = strtotime( $new_expiration );
				$access['expires_at'] = gmdate( 'Y-m-d H:i:s', max( $current, time() ) + ( $new - time() ) );
			} else {
				$access['expires_at'] = $new_expiration;
			}
		} elseif ( empty( $grants['duration_days'] ) ) {
			// Lifetime access.
			$access['expires_at'] = null;
		}

		// Handle subscription.
		if ( 'subscription' === $offer['type'] && isset( $transaction['subscription_id'] ) ) {
			$access['subscription'] = array(
				'id'         => $transaction['subscription_id'],
				'provider'   => $transaction['provider'] ?? 'stripe',
				'status'     => 'active',
				'started_at' => current_time( 'mysql' ),
			);
		}

		// Handle token grants.
		if ( 'tokens' === $offer['type'] && ! empty( $offer['tokens']['amount'] ) ) {
			$token_provider = flosc_sale()->get_provider( 'tokens' );
			if ( $token_provider ) {
				$total = ( $offer['tokens']['amount'] ?? 0 ) + ( $offer['tokens']['bonus'] ?? 0 );
				$token_provider->credit( $user_id, $total, 'Purchase: ' . $offer['name'] );
			}
		}

		// Apply usage limits from offer.
		if ( ! empty( $grants['usage_limits'] ) ) {
			$usage_tracker  = flosc_sale()->usage();
			$current_limits = $usage_tracker->get_limits( $user_id );

			foreach ( $grants['usage_limits'] as $event => $limit ) {
				// -1 means unlimited
				if ( -1 === $limit || ! isset( $current_limits[ $event ] ) || $limit > $current_limits[ $event ] ) {
					$current_limits[ $event ] = $limit;
				}
			}

			$usage_tracker->set_limits( $user_id, $current_limits );
		}

		$access['granted_at'] = $access['granted_at'] ?? current_time( 'mysql' );
		$access['updated_at'] = current_time( 'mysql' );

		update_user_meta( $user_id, $this->meta_key, $access );

		// v9.5.5: Store member level for IVR conditions
		// v8.0.1: Fixed — offer schema stores level at grants.level, not member_level.
		$member_level = $offer['grants']['level'] ?? $offer['member_level'] ?? $offer['id'] ?? 'member';
		update_user_meta( $user_id, '_flosc_member_level', $member_level );
		update_user_meta( $user_id, '_flosc_purchased', true );
		update_user_meta( $user_id, '_flosc_purchased_at', current_time( 'mysql' ) );

		// v8.0.1: Atomic purchase counter + immutable purchase history ledger.
		// Counter: quick integer read for admin display.
		// History: append-only log of every transaction — never delete, never overwrite.
		$count = (int) get_user_meta( $user_id, '_flosc_purchase_count', true );
		update_user_meta( $user_id, '_flosc_purchase_count', $count + 1 );

		$history = get_user_meta( $user_id, '_flosc_purchase_history', true );
		if ( ! $history ) {
			$history = array();
		}
		$history_flow = (string) ( $transaction['flow_id'] ?? $offer['flow_id'] ?? '' );
		if ( '' === $history_flow ) {
			$history_flow = $this->normalize_flow_stem( null );
		}
		$history[] = array(
			'offer_id'        => $offer['id'] ?? 'unknown',
			'offer_name'      => $offer['name'] ?? '',
			'member_level'    => $member_level,
			'flow_id'         => $history_flow,
			'transaction_id'  => $transaction['transaction_id'] ?? null,
			'provider'        => $transaction['provider'] ?? 'unknown',
			'amount'          => $transaction['amount'] ?? 0,
			'currency'        => $transaction['currency'] ?? '',
			'timestamp'       => current_time( 'mysql' ),
			'purchase_number' => $count + 1,
		);
		update_user_meta( $user_id, '_flosc_purchase_history', $history );

		do_action( 'flosc_access_granted', $user_id, $offer, $access );

		return $access;
	}

	/**
	 * Grant feature directly
	 *
	 * @param mixed $user_id User ID.
	 * @param mixed $feature Feature.
	 */
	public function grant_feature( $user_id, $feature ) {
		$access = $this->get_user_access( $user_id );

		if ( ! in_array( (string) $feature, array_map( 'strval', (array) $access['features'] ), true ) ) {
			$access['features'][] = $feature;
			$access['updated_at'] = current_time( 'mysql' );
			update_user_meta( $user_id, $this->meta_key, $access );
		}

		return true;
	}

	/**
	 * Revoke feature
	 *
	 * @param mixed $user_id User ID.
	 * @param mixed $feature Feature.
	 */
	public function revoke_feature( $user_id, $feature ) {
		$access = $this->get_user_access( $user_id );

		$access['features'] = array_filter(
			$access['features'],
			function ( $f ) use ( $feature ) {
				return $f !== $feature;
			}
		);

		$access['updated_at'] = current_time( 'mysql' );
		update_user_meta( $user_id, $this->meta_key, $access );

		return true;
	}

	/**
	 * Check if user has purchased a specific offer
	 *
	 * @param mixed $user_id  User ID.
	 * @param mixed $offer_id Offer ID.
	 */
	public function has_offer( $user_id, $offer_id ) {
		$access = $this->get_user_access( $user_id );

		if ( ! isset( $access['offers'][ $offer_id ] ) ) {
			return false;
		}

		return $this->is_offer_active( $access['offers'][ $offer_id ] );
	}

	/**
	 * Revoke all access (reset to guest)
	 *
	 * @param mixed $user_id User ID.
	 */
	public function revoke_all( $user_id ) {
		$access = array(
			'features'     => array(),
			'offers'       => array(),
			'subscription' => null,
			'expires_at'   => null,
			'granted_at'   => null,
			'updated_at'   => current_time( 'mysql' ),
		);

		update_user_meta( $user_id, $this->meta_key, $access );

		do_action( 'flosc_access_revoked', $user_id );

		return true;
	}

	/**
	 * Update subscription status
	 *
	 * @param mixed $user_id           User ID.
	 * @param mixed $subscription_data Subscription data.
	 */
	public function update_subscription( $user_id, $subscription_data ) {
		$access = $this->get_user_access( $user_id );

		if ( $access['subscription'] ) {
			$access['subscription'] = array_merge( $access['subscription'], $subscription_data );
		} else {
			$access['subscription'] = $subscription_data;
		}

		$access['updated_at'] = current_time( 'mysql' );
		update_user_meta( $user_id, $this->meta_key, $access );

		return $access;
	}

	/**
	 * Cancel subscription access
	 *
	 * @param mixed $user_id User ID.
	 */
	public function cancel_subscription( $user_id ) {
		$access = $this->get_user_access( $user_id );

		if ( $access['subscription'] ) {
			$access['subscription']['status']      = 'canceled';
			$access['subscription']['canceled_at'] = current_time( 'mysql' );
		}

		$access['updated_at'] = current_time( 'mysql' );
		update_user_meta( $user_id, $this->meta_key, $access );

		do_action( 'flosc_subscription_canceled', $user_id );

		return true;
	}

	// =========================================================================
	// HELPERS
	// =========================================================================

	/**
	 * Calculate expiration date from offer
	 *
	 * @param mixed $offer Offer.
	 */
	private function calculate_expiration( $offer ) {
		$duration = $offer['grants']['duration_days'] ?? 0;

		if ( $duration <= 0 ) {
			return null; // Lifetime.
		}

		return gmdate( 'Y-m-d H:i:s', strtotime( '+' . $duration . ' days' ) );
	}

	/**
	 * Check if an offer is still active (not expired)
	 *
	 * @param mixed $offer_data Offer data.
	 */
	private function is_offer_active( $offer_data ) {
		if ( empty( $offer_data['expires_at'] ) ) {
			return true; // Lifetime.
		}

		return strtotime( $offer_data['expires_at'] ) > time();
	}

	/**
	 * Check if subscription is active
	 *
	 * @param mixed $subscription Subscription.
	 */
	private function is_subscription_active( $subscription ) {
		if ( ! $subscription ) {
			return false;
		}

		return in_array( $subscription['status'], array( 'active', 'trialing' ), true );
	}

	/**
	 * Resolve the only three real-world app states.
	 *
	 * Real-world (one browser host, one session):
	 * - No authenticated user  → visitor
	 * - Authenticated, unpaid  → guest   (tokens/wallet from user profile for this flow)
	 * - Authenticated + paid   → member  (for this flow only)
	 *
	 * A non-zero $user_id MUST NEVER return visitor. Multi-host same-user testing
	 * is rare; do not invent visitor UI for a known WP user.
	 *
	 * @param int         $user_id 0 = anonymous.
	 * @param string|null $flow_id Flow id / ivr / stem for paid-tier check.
	 * @return string visitor|guest|member
	 */
	public function get_simple_state( $user_id, $flow_id = null ) {
		$user_id = absint( $user_id );
		if ( $user_id <= 0 ) {
			return 'visitor';
		}

		if ( $this->is_member( $user_id, $flow_id ) ) {
			return 'member';
		}

		return 'guest';
	}
}
