<?php
/**
 * FLOSC Quiz Registry
 *
 * The single place that maps quiz IDs to their quiz classes.
 * To add a new quiz: require its class file below and add it to the map in init().
 *
 * @package FLOSC
 * @version 4.0.7
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once FLOSC_PLUGIN_DIR . 'includes/quiz-types/class-flosc-abstract-quiz-type.php';
require_once FLOSC_PLUGIN_DIR . 'includes/quiz-types/class-flosc-sample-assessment-quiz.php';
require_once FLOSC_PLUGIN_DIR . 'includes/quiz-types/class-flosc-sample-text-based-quiz.php';

/**
 * Quiz registry.
 */
class FLOSC_Quiz_Registry {

	/**
	 * Init.
	 *
	 * @var FLOSC_Abstract_Quiz_Type[]|null
	 */
	private static $quizzes = null;

	/**
	 * Init.
	 */
	private static function init() {
		if ( null !== self::$quizzes ) {
			return;
		}
		self::$quizzes = array(
			'sample_assessment_quiz'         => new FLOSC_Sample_Assessment_Quiz(),
			'flosc_sample_data_numbers_quiz' => new FLOSC_Sample_Text_Based_Quiz(),
		);
	}

	/**
	 * Normalize a quiz id for lookup (sanitize only — no rename table).
	 *
	 * @param string $quiz_id Quiz ID.
	 * @return string
	 */
	private static function normalize_quiz_id( $quiz_id ) {
		return sanitize_key( (string) $quiz_id );
	}

	/**
	 * Public helper: same normalize as get_quiz / quiz_exists.
	 *
	 * @param string $quiz_id Quiz ID.
	 * @return string
	 */
	public static function resolve_id( $quiz_id ) {
		return self::normalize_quiz_id( $quiz_id );
	}

	/**
	 * Get a quiz by its ID.
	 *
	 * @param  string $quiz_id Quiz ID.
	 * @return FLOSC_Abstract_Quiz_Type|null  Null if the ID is not registered.
	 */
	public static function get_quiz( $quiz_id ) {
		self::init();
		$quiz_id = self::normalize_quiz_id( $quiz_id );
		return self::$quizzes[ $quiz_id ] ?? null;
	}

	/**
	 * Return all registered quizzes as [ quiz_id => quiz_instance ].
	 *
	 * @return FLOSC_Abstract_Quiz_Type[]
	 */
	public static function get_all_quizzes() {
		self::init();
		return self::$quizzes;
	}

	/**
	 * Check whether a quiz with the given ID is registered.
	 *
	 * @param  string $quiz_id Quiz ID.
	 * @return bool
	 */
	public static function quiz_exists( $quiz_id ) {
		self::init();
		$quiz_id = self::normalize_quiz_id( $quiz_id );
		return isset( self::$quizzes[ $quiz_id ] );
	}
}
