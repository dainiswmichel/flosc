<?php
/**
 * FLOSC uninstall routine.
 *
 * Runs only when the plugin is deleted from WordPress admin.
 * Keep this fast and dependency-free so Delete can finish removing plugins/flosc/.
 * Do not load the main plugin, loop all users/posts, or call optional helpers.
 *
 * @package FLOSC
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.DirectDatabaseQuery.SchemaChange -- uninstall purge

/**
 * Uninstall delete options by prefix.
 *
 * @param string $prefix Option name prefix.
 * @return void
 */
function flosc_uninstall_delete_options_by_prefix( $prefix ) {
	global $wpdb;
	$prefix = (string) $prefix;
	if ( '' === $prefix ) {
		return;
	}
	$wpdb->query(
		$wpdb->prepare(
			"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
			$wpdb->esc_like( $prefix ) . '%'
		)
	);
	wp_cache_delete( 'alloptions', 'options' );
	wp_cache_delete( 'notoptions', 'options' );
}

/**
 * Uninstall delete sitemeta by prefix.
 *
 * @param string $prefix Meta key prefix.
 * @return void
 */
function flosc_uninstall_delete_sitemeta_by_prefix( $prefix ) {
	if ( ! is_multisite() ) {
		return;
	}
	global $wpdb;
	$prefix = (string) $prefix;
	if ( '' === $prefix ) {
		return;
	}
	$wpdb->query(
		$wpdb->prepare(
			"DELETE FROM {$wpdb->sitemeta} WHERE meta_key LIKE %s",
			$wpdb->esc_like( $prefix ) . '%'
		)
	);
}

/**
 * Bulk-delete object meta by key prefix (no per-object PHP loops).
 *
 * @param string $table Full table name (usermeta, postmeta, termmeta).
 * @param string $prefix Meta key prefix.
 * @return void
 */
function flosc_uninstall_delete_meta_table_prefix( $table, $prefix ) {
	global $wpdb;
	$table  = (string) $table;
	$prefix = (string) $prefix;
	if ( '' === $table || '' === $prefix ) {
		return;
	}
	$wpdb->query(
		$wpdb->prepare(
			'DELETE FROM %i WHERE meta_key LIKE %s',
			$table,
			$wpdb->esc_like( $prefix ) . '%'
		)
	);
}

// Options + transients.
flosc_uninstall_delete_options_by_prefix( 'flosc_' );
flosc_uninstall_delete_options_by_prefix( '_flosc_' );
flosc_uninstall_delete_options_by_prefix( '_transient_flosc_' );
flosc_uninstall_delete_options_by_prefix( '_transient_timeout_flosc_' );

if ( is_multisite() ) {
	flosc_uninstall_delete_sitemeta_by_prefix( 'flosc_' );
	flosc_uninstall_delete_sitemeta_by_prefix( '_flosc_' );
	flosc_uninstall_delete_sitemeta_by_prefix( '_transient_flosc_' );
	flosc_uninstall_delete_sitemeta_by_prefix( '_transient_timeout_flosc_' );
}

// Meta (SQL bulk — safe on large user/post counts).
global $wpdb;
foreach ( array( '_flosc_', 'flosc_' ) as $flosc_meta_prefix ) {
	flosc_uninstall_delete_meta_table_prefix( $wpdb->usermeta, $flosc_meta_prefix );
	flosc_uninstall_delete_meta_table_prefix( $wpdb->postmeta, $flosc_meta_prefix );
	if ( ! empty( $wpdb->termmeta ) ) {
		flosc_uninstall_delete_meta_table_prefix( $wpdb->termmeta, $flosc_meta_prefix );
	}
}

// Custom tables.
$flosc_tables = array(
	$wpdb->prefix . 'flosc_chat_logs',
	$wpdb->prefix . 'flosc_lessons',
);
foreach ( $flosc_tables as $flosc_table ) {
	$wpdb->query( $wpdb->prepare( 'DROP TABLE IF EXISTS %i', $flosc_table ) );
}

if ( function_exists( 'wp_clear_scheduled_hook' ) ) {
	wp_clear_scheduled_hook( 'flosc_cleanup_visitor_audio' );
	wp_clear_scheduled_hook( 'flosc_guest_followup_cron' );
}

/**
 * The WordPress filesystem abstraction, or null when it cannot be had.
 *
 * Uninstall runs without form credentials, so the direct transport is the
 * only one that can apply. Bootstrapping is done once and the result reused.
 *
 * @return WP_Filesystem_Base|null The filesystem object, or null.
 */
function flosc_uninstall_filesystem() {
	if ( ! function_exists( 'WP_Filesystem' ) ) {
		require_once ABSPATH . 'wp-admin/includes/file.php';
	}

	global $wp_filesystem;
	if ( ! is_object( $wp_filesystem ) ) {
		// Direct method: uninstall has no form credentials for FTP.
		WP_Filesystem();
	}

	return is_object( $wp_filesystem ) ? $wp_filesystem : null;
}

/**
 * Recursively remove a directory under uploads.
 *
 * Everything here goes through WP_Filesystem and wp_delete_file(). There is
 * deliberately no raw scandir/unlink/rmdir fallback: WordPress.org promotes
 * WordPress.WP.AlternativeFunctions to an error, and those three calls were
 * the only genuine Plugin Check errors this plugin had. When the filesystem
 * abstraction cannot be had at all, the tree is left in place. Files left
 * under uploads after an uninstall are recoverable by hand; a release that
 * bypasses the filesystem API is not shippable.
 *
 * @param string $dir Absolute path.
 * @return void
 */
function flosc_uninstall_rm_rf( $dir ) {
	$dir = untrailingslashit( (string) $dir );
	if ( '' === $dir || ! is_dir( $dir ) ) {
		return;
	}

	$flosc_fs = flosc_uninstall_filesystem();
	if ( null === $flosc_fs || ! method_exists( $flosc_fs, 'rmdir' ) ) {
		return;
	}

	// The recursive form handles the whole tree wherever the transport
	// supports it, which is the common case.
	if ( $flosc_fs->rmdir( $dir, true ) ) {
		return;
	}

	// It declined. Walk the tree through the same abstraction instead.
	$flosc_entries = method_exists( $flosc_fs, 'dirlist' )
		? $flosc_fs->dirlist( $dir, true, false )
		: false;

	if ( is_array( $flosc_entries ) ) {
		foreach ( $flosc_entries as $flosc_entry ) {
			$flosc_name = isset( $flosc_entry['name'] ) ? (string) $flosc_entry['name'] : '';
			if ( '' === $flosc_name || '.' === $flosc_name || '..' === $flosc_name ) {
				continue;
			}

			$flosc_path = $dir . '/' . $flosc_name;
			if ( isset( $flosc_entry['type'] ) && 'd' === $flosc_entry['type'] ) {
				flosc_uninstall_rm_rf( $flosc_path );
			} else {
				wp_delete_file( $flosc_path );
			}
		}
	}

	// The directory is empty now, so the non-recursive form can take it.
	$flosc_fs->rmdir( $dir, false );
}

// FLOSC data under uploads only (never touch plugins/flosc — core removes that).
// Includes flosc-catalogs (DA1 TSV files) with other FLOSC-managed upload trees.
$flosc_uploads = wp_upload_dir( null, false );
if ( empty( $flosc_uploads['error'] ) && ! empty( $flosc_uploads['basedir'] ) ) {
	$flosc_base = trailingslashit( $flosc_uploads['basedir'] );
	foreach ( array( 'flosc', 'flosc-users', 'flosc-temp', 'flosc-catalogs' ) as $flosc_subdir ) {
		$flosc_dir = $flosc_base . $flosc_subdir;
		if ( is_dir( $flosc_dir ) ) {
			flosc_uninstall_rm_rf( $flosc_dir );
		}
	}
}
