<?php
/**
 * FLOSC Session Manager.
 * Handles chat session storage and retrieval — scoped per flow.
 *
 * Real-world: a guest on one flow must not see another flow's chats.
 * Sessions live in user meta `_flosc_sessions` with an optional `flow_id` stem.
 *
 * @package FLOSC
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Coordinate FLOSC Session Manager behavior and the WordPress services used by its methods.
 */
class FLOSC_Session_Manager {

	private $flosc_session_meta_key = '_flosc_sessions';

	/**
	 * Normalize a flow id / ivr path to a stable stem.
	 *
	 * @param string $flow_id Value consumed by this operation.
	 * @return String.
	 */
	public function normalize_flow_stem( $flow_id = '' ) {
		$raw  = (string) $flow_id;
		$stem = sanitize_key( pathinfo( basename( $raw ), PATHINFO_FILENAME ) );
		if ( '' === $stem && '' !== $raw ) {
			$stem = sanitize_key( $raw );
		}
		return $stem;
	}

	/**
	 * Resolve current request flow stem when not passed explicitly.
	 *
	 * @param string $flow_id Value consumed by this operation.
	 * @return String.
	 */
	public function resolve_flow_stem( $flow_id = '' ) {
		$stem = $this->normalize_flow_stem( $flow_id );
		if ( '' !== $stem && 'default' !== $stem ) {
			return $stem;
		}
		if ( function_exists( 'flosc' ) && is_object( flosc() ) && method_exists( flosc(), 'get_current_flow' ) ) {
			$flow = flosc()->get_current_flow();
			if ( is_array( $flow ) ) {
				$stem = $this->normalize_flow_stem(
					(string) ( $flow['ivr_file'] ?? $flow['ivr'] ?? $flow['id'] ?? '' )
				);
			}
		}
		return ( '' !== $stem && 'default' !== $stem ) ? $stem : '';
	}

	/**
	 * Whether a session belongs to the requested flow.
	 *
	 * @param array $session Value consumed by this operation.
	 * @param mixed $stem    Input consumed by the Coordinate the session belongs to flow behavior implemented by this code path. operation.
	 * @param int   $user_id For legacy untagged sessions.
	 * @return Bool.
	 */
	public function session_belongs_to_flow( array $session, $stem, $user_id = 0 ) {
		$stem = $this->normalize_flow_stem( $stem );
		// Fail closed: unscoped stem never matches (prevents cross-flow history bleed).
		if ( '' === $stem ) {
			return false;
		}

		$session_stem = $this->normalize_flow_stem( (string) ( $session['flow_id'] ?? '' ) );
		if ( '' !== $session_stem && 'default' !== $session_stem ) {
			return $session_stem === $stem;
		}

		// Legacy sessions (no flow_id): only show on the user's registration flow.
		$reg = $this->normalize_flow_stem(
			(string) get_user_meta( (int) $user_id, '_flosc_registration_flow', true )
		);
		if ( '' !== $reg && 'default' !== $reg ) {
			return $reg === $stem;
		}

		// No registration flow means untagged sessions are not attributed to any flow.
		return false;
	}

	/**
	 * Get sessions for a user, optionally filtered to one flow (grouped by date).
	 *
	 * @param int   $user_id Value consumed by this operation.
	 * @param mixed $flow_id Flow identifier used to resolve flow-scoped configuration and state.
	 * @return Array.
	 */
	public function get_flosc_user_sessions( $user_id, $flow_id = '' ) {
		$empty = array(
			'today'       => array(),
			'yesterday'   => array(),
			'last_7_days' => array(),
			'older'       => array(),
		);

		$sessions = get_user_meta( $user_id, $this->flosc_session_meta_key, true );
		if ( ! is_array( $sessions ) ) {
			return $empty;
		}

		$stem = $this->resolve_flow_stem( $flow_id );
		// No stem = no sessions for normal runtime (fail closed). Admin tools must pass a stem or use a dedicated API.
		if ( '' === $stem ) {
			return $empty;
		}
		$sessions = array_values(
			array_filter(
				$sessions,
				function ( $session ) use ( $stem, $user_id ) {
					return is_array( $session ) && $this->session_belongs_to_flow( $session, $stem, $user_id );
				}
			)
		);

		usort(
			$sessions,
			function ( $a, $b ) {
				return strtotime( $b['updated_at'] ?? '0' ) - strtotime( $a['updated_at'] ?? '0' );
			}
		);

		$grouped   = $empty;
		$today     = strtotime( 'today' );
		$yesterday = strtotime( 'yesterday' );
		$week_ago  = strtotime( '-7 days' );

		foreach ( $sessions as $session ) {
			$updated = strtotime( $session['updated_at'] ?? '0' );
			if ( $updated >= $today ) {
				$grouped['today'][] = $session;
			} elseif ( $updated >= $yesterday ) {
				$grouped['yesterday'][] = $session;
			} elseif ( $updated >= $week_ago ) {
				$grouped['last_7_days'][] = $session;
			} else {
				$grouped['older'][] = $session;
			}
		}

		return $grouped;
	}

	/**
	 * Create a new session on a flow.
	 *
	 * @param int    $user_id       Value consumed by this operation.
	 * @param mixed  $title         Input consumed by the Persist the session state in Word Press storage. operation.
	 * @param string $flow_id       Flow stem for isolation.
	 * @param mixed  $seed_messages Input consumed by the Persist the session state in Word Press storage. operation.
	 * @return Array.
	 */
	public function flosc_create_session( $user_id, $title = 'New Chat', $flow_id = '', $seed_messages = array() ) {

		$stem = $this->resolve_flow_stem( $flow_id );
		if ( '' === $stem ) {
			return null;
		}

		$sessions = get_user_meta( $user_id, $this->flosc_session_meta_key, true );
		if ( ! is_array( $sessions ) ) {
			$sessions = array();
		}

		$ids        = array_column( $sessions, 'id' );
		$session_id = empty( $ids ) ? 1 : (int) max( $ids ) + 1;
		$now        = current_time( 'mysql' );

		$session = array(
			'id'         => $session_id,
			'title'      => $title,
			'messages'   => $this->normalize_seed_messages( $seed_messages ),
			'created_at' => $now,
			'updated_at' => $now,
			'flow_id'    => $stem,
		);

		$sessions[] = $session;
		update_user_meta( $user_id, $this->flosc_session_meta_key, $sessions );

		return $session;
	}

	/**
	 * Normalize client-supplied seed messages for a newly created session.
	 *
	 * Used when a visitor authenticates mid-conversation: the turns they already.
	 * Had are written into the session created for their account, so the thread.
	 * Is not stranded on the device. Anything malformed is dropped, never stored.
	 *
	 * @param mixed $seed_messages Raw messages from the request.
	 * @return Array Normalized message rows (most recent 50).
	 */
	private function normalize_seed_messages( $seed_messages ) {
		if ( ! is_array( $seed_messages ) || empty( $seed_messages ) ) {
			return array();
		}

		$now = current_time( 'mysql' );
		$out = array();

		foreach ( array_slice( $seed_messages, -50 ) as $raw ) {
			if ( ! is_array( $raw ) ) {
				continue;
			}

			$role = sanitize_key( (string) ( $raw['role'] ?? '' ) );
			if ( 'user' !== $role && 'assistant' !== $role ) {
				continue;
			}

			$content = wp_kses_post( (string) ( $raw['content'] ?? '' ) );
			$content = trim( $content );
			if ( '' === $content ) {
				continue;
			}
			if ( function_exists( 'mb_substr' ) ) {
				$content = mb_substr( $content, 0, 4000 );
			} else {
				$content = substr( $content, 0, 4000 );
			}

			$out[] = array(
				'role'      => $role,
				'content'   => $content,
				'timestamp' => $now,
			);
		}

		return $out;
	}

	/**
	 * Get a specific session (must belong to user; optional flow match).
	 *
	 * @param int         $session_id Value consumed by this operation.
	 * @param mixed       $user_id    WordPress user ID whose Resolve the current session value from the available Word Press and flow state. state is being processed.
	 * @param string|null $flow_id    When set, reject sessions from other flows.
	 * @return Array|null.
	 */
	public function get_flosc_session( $session_id, $user_id = null, $flow_id = null ) {
		if ( ! $user_id ) {
			$user_id = get_current_user_id();
		}

		$stem = $this->resolve_flow_stem( (string) ( $flow_id ?? '' ) );
		if ( '' === $stem ) {
			return null;
		}

		$sessions = get_user_meta( $user_id, $this->flosc_session_meta_key, true );
		if ( ! is_array( $sessions ) ) {
			return null;
		}

		foreach ( $sessions as $session ) {
			if ( (int) ( $session['id'] ?? 0 ) !== (int) $session_id ) {
				continue;
			}
			if ( ! $this->session_belongs_to_flow( $session, $stem, $user_id ) ) {
				return null;
			}
			return $session;
		}

		return null;
	}

	/**
	 * Load a session by id for the current user, regardless of destination flow.
	 * Replacement security boundary: the session must belong to this WordPress user.
	 * Sidebar listing stays flow-filtered; history/handoff restore may cross floscDomains.
	 *
	 * @param int   $session_id Value consumed by this operation.
	 * @param mixed $user_id    WordPress user ID whose Resolve the current session by id value from the available Word Press and flow state. state is being processed.
	 * @return Array|null.
	 */
	public function get_flosc_session_by_id( $session_id, $user_id = null ) {
		$session_id = absint( $session_id );
		if ( ! $user_id ) {
			$user_id = get_current_user_id();
		}
		$user_id = absint( $user_id );
		if ( $session_id <= 0 || $user_id <= 0 ) {
			return null;
		}

		$sessions = get_user_meta( $user_id, $this->flosc_session_meta_key, true );
		if ( ! is_array( $sessions ) ) {
			return null;
		}

		foreach ( $sessions as $session ) {
			if ( (int) ( $session['id'] ?? 0 ) === $session_id ) {
				return $session;
			}
		}

		return null;
	}

	/**
	 * Add message to session.
	 *
	 * @param int        $session_id Value consumed by this operation.
	 * @param mixed      $role       Input consumed by the Persist the add flosc message state in Word Press storage. operation.
	 * @param string     $content    Value consumed by this operation.
	 * @param mixed      $user_id    WordPress user ID whose Persist the add flosc message state in Word Press storage. state is being processed.
	 * @param array|null $meta       Value consumed by this operation.
	 * @param mixed      $flow_id    Flow identifier used to resolve flow-scoped configuration and state.
	 * @return Bool.
	 */
	public function add_flosc_message( $session_id, $role, $content, $user_id = null, $meta = null, $flow_id = null ) {
		if ( ! $user_id ) {
			$user_id = get_current_user_id();
		}

		$sessions = get_user_meta( $user_id, $this->flosc_session_meta_key, true );
		if ( ! is_array( $sessions ) ) {
			return false;
		}

		$stem = $this->resolve_flow_stem( (string) ( $flow_id ?? '' ) );
		if ( '' === $stem ) {
			return false;
		}

		foreach ( $sessions as &$session ) {
			if ( (int) ( $session['id'] ?? 0 ) !== (int) $session_id ) {
				continue;
			}
			// Keep the existing session even when the destination floscDomain/flow.
			// differs. Sidebar listing stays flow-filtered; this append is the live journey.
			if ( empty( $session['flow_id'] ) && '' !== $stem ) {
				$session['flow_id'] = $stem;
			}

			$message = array(
				'role'      => $role,
				'content'   => $content,
				'timestamp' => current_time( 'mysql' ),
			);

			if ( is_array( $meta ) ) {
				$source = sanitize_text_field( (string) ( $meta['source'] ?? '' ) );
				$name   = sanitize_text_field( (string) ( $meta['name'] ?? '' ) );
				if ( '' !== $source || '' !== $name ) {
					$message['meta'] = array(
						'source' => $source,
						'name'   => $name,
					);
				}
			}

			$session['messages'][] = $message;
			$session['updated_at'] = current_time( 'mysql' );

			$current_title = trim( (string) ( $session['title'] ?? '' ) );
			if ( 'user' === $role && ( '' === $current_title || 'New Chat' === $current_title ) ) {
				$session['title'] = $this->generate_flosc_session_title( $content );
			}

			update_user_meta( $user_id, $this->flosc_session_meta_key, $sessions );
			return true;
		}

		return false;
	}

	/**
	 * Delete a session (optional flow guard).
	 *
	 * @param int         $session_id Value consumed by this operation.
	 * @param mixed       $user_id    WordPress user ID whose Persist the session state in Word Press storage. state is being processed.
	 * @param string|null $flow_id    Value consumed by this operation.
	 * @return Bool.
	 */
	public function flosc_delete_session( $session_id, $user_id = null, $flow_id = null ) {
		if ( ! $user_id ) {
			$user_id = get_current_user_id();
		}

		$sessions = get_user_meta( $user_id, $this->flosc_session_meta_key, true );
		if ( ! is_array( $sessions ) ) {
			return false;
		}

		$stem = $this->resolve_flow_stem( (string) ( $flow_id ?? '' ) );
		if ( '' === $stem ) {
			return false;
		}

		$before   = count( $sessions );
		$sessions = array_values(
			array_filter(
				$sessions,
				function ( $s ) use ( $session_id, $stem, $user_id ) {
					if ( (int) ( $s['id'] ?? 0 ) !== (int) $session_id ) {
						return true;
					}
					if ( ! $this->session_belongs_to_flow( $s, $stem, $user_id ) ) {
						return true; // wrong flow — do not delete.
					}
					return false; // drop matching session.
				}
			)
		);

		if ( count( $sessions ) === $before ) {
			return false;
		}

		update_user_meta( $user_id, $this->flosc_session_meta_key, $sessions );
		return true;
	}

	/**
	 * Generate session title from first message.
	 *
	 * @param string $content Value consumed by this operation.
	 * @return String.
	 */
	private function generate_flosc_session_title( $content ) {
		$plain = wp_strip_all_tags( (string) $content );
		$plain = trim( preg_replace( '/\s+/u', ' ', $plain ) ?? '' );
		if ( '' === $plain ) {
			return 'New Chat';
		}
		if ( function_exists( 'mb_substr' ) ) {
			$title  = mb_substr( $plain, 0, 40, 'UTF-8' );
			$longer = mb_strlen( $plain, 'UTF-8' ) > 40;
		} else {
			$title  = substr( $plain, 0, 40 );
			$longer = strlen( $plain ) > 40;
		}
		if ( $longer ) {
			$title .= '...';
		}
		return '' !== $title ? $title : 'New Chat';
	}

	/**
	 * Session count for user (optional per-flow).
	 *
	 * @param int   $user_id Value consumed by this operation.
	 * @param mixed $flow_id Flow identifier used to resolve flow-scoped configuration and state.
	 * @return Int.
	 */
	public function get_flosc_session_count( $user_id, $flow_id = '' ) {
		$sessions = get_user_meta( $user_id, $this->flosc_session_meta_key, true );
		if ( ! is_array( $sessions ) ) {
			return 0;
		}
		$stem = $this->resolve_flow_stem( $flow_id );
		if ( '' === $stem ) {
			return count( $sessions );
		}
		$n = 0;
		foreach ( $sessions as $session ) {
			if ( is_array( $session ) && $this->session_belongs_to_flow( $session, $stem, $user_id ) ) {
				++$n;
			}
		}
		return $n;
	}
}
