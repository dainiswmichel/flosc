<?php
/**
 * FLOSC Flow Manager.
 *
 * Handles CRUD operations for FLOSC Flows.
 * Enables multiple independent chatbots from a single WordPress installation.
 *
 * @package FLOSC
 * @since 1.2.2
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Coordinate FLOSC Flow Manager behavior and the WordPress services used by its methods.
 */
class FLOSC_Flow_Manager {

	private static $instance = null;

	const OPTION_KEY = 'flosc_flows';

/**
 * Coordinate the instance behavior implemented by this code path.
 *
 * @return Mixed Result produced by the instance operation.
 */
public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

/**
 * Coordinate the construct behavior implemented by this code path.
 */
private function __construct() {
		// Constructor.
	}

	/**
	 * Get all flows.
	 *
	 * @return Mixed Result produced by the all flows operation.
	 */
	public function get_all_flows() {
		return get_option( self::OPTION_KEY, array() );
	}

	/**
	 * Get flows accessible by a user.
	 *
	 * @param mixed $user_id WordPress user ID whose Resolve the current user flows value from the available Word Press and flow state. state is being processed.
	 * @return Mixed Result produced by the user flows operation.
	 */
	public function get_user_flows( $user_id = null ) {
		$user_id   = $user_id ? $user_id : get_current_user_id();
		$all_flows = $this->get_all_flows();

		// Administrators see all flows.
		if ( user_can( $user_id, 'manage_options' ) ) {
			return $all_flows;
		}

		// Others see only assigned flows.
		$allowed = get_user_meta( $user_id, '_flosc_flow_access', true );
		if ( ! $allowed ) {
			$allowed = array();
		}

		if ( ! is_array( $allowed ) ) {
			$allowed = array();
		}

		$allowed_ids = array_map( 'strval', $allowed );

		return array_filter(
			$all_flows,
			function ( $flow ) use ( $allowed_ids ) {
				return in_array( (string) $flow['id'], $allowed_ids, true );
			}
		);
	}

	/**
	 * Get a single flow by ID.
	 *
	 * @param mixed $flow_id Flow identifier used to resolve flow-scoped configuration and state.
	 * @return Mixed Result produced by the flow operation.
	 */
	public function get_flow( $flow_id ) {
		$flows = $this->get_all_flows();
		return $flows[ $flow_id ] ?? null;
	}

	/**
	 * Get flow by slug.
	 *
	 * @param mixed $slug Input consumed by the Resolve the current flow by slug value from the available Word Press and flow state. operation.
	 * @return Mixed Result produced by the flow by slug operation.
	 */
	public function get_flow_by_slug( $slug ) {
		$flows = $this->get_all_flows();
		foreach ( $flows as $flow ) {
			if ( $flow['slug'] === $slug ) {
				return $flow;
			}
		}
		return null;
	}

	/**
	 * Get flow by custom domain.
	 *
	 * @param mixed $domain Input consumed by the Resolve the current flow by domain value from the available Word Press and flow state. operation.
	 * @return Mixed Result produced by the flow by domain operation.
	 */
	public function get_flow_by_domain( $domain ) {
		$domain = strtolower( preg_replace( '#^https?://#', '', trim( $domain ) ) );
		$domain = rtrim( $domain, '/' );

		$flows = $this->get_all_flows();
		foreach ( $flows as $flow ) {
			if ( empty( $flow['custom_domain'] ) ) {
				continue;
			}

			$flow_domain = strtolower( preg_replace( '#^https?://#', '', trim( $flow['custom_domain'] ) ) );
			$flow_domain = rtrim( $flow_domain, '/' );

			if ( $flow_domain === $domain || 'www.' . $flow_domain === $domain ) {
				return $flow;
			}
		}
		return null;
	}

	/**
	 * Create a new flow.
	 *
	 * @param mixed $data Structured data consumed by the Persist the flow state in Word Press storage. operation.
	 * @return Mixed Result of the flow operation, or a WP_Error when it cannot complete.
	 */
	public function create_flow( $data ) {
		$flows = $this->get_all_flows();

		// Generate ID if not provided.
		if ( empty( $data['id'] ) ) {
			$data['id'] = sanitize_key( $data['slug'] ?? 'flow_' . wp_generate_password( 6, false, false ) );
		}

		// Validate unique ID.
		if ( isset( $flows[ $data['id'] ] ) ) {
			return new WP_Error( 'duplicate_id', 'Flow ID already exists' );
		}

		// Validate unique slug.
		if ( ! empty( $data['slug'] ) ) {
			foreach ( $flows as $flow ) {
				if ( $flow['slug'] === $data['slug'] ) {
					return new WP_Error( 'duplicate_slug', 'Slug already in use' );
				}
			}
		}

		// Normalize data.
		$flow               = $this->normalize_flow_data( $data );
		$flow['created_at'] = current_time( 'mysql' );
		$flow['updated_at'] = current_time( 'mysql' );

		// Save.
		$flows[ $flow['id'] ] = $flow;
		update_option( self::OPTION_KEY, $flows );

		// Flush rewrite rules for new slug.
		flush_rewrite_rules();

		return $flow;
	}

	/**
	 * Update an existing flow.
	 *
	 * @param mixed $flow_id Flow identifier used to resolve flow-scoped configuration and state.
	 * @param mixed $data    Structured data consumed by the Persist the flow state in Word Press storage. operation.
	 * @return Mixed Result of the flow operation, or a WP_Error when it cannot complete.
	 */
	public function update_flow( $flow_id, $data ) {
		$flows = $this->get_all_flows();

		if ( ! isset( $flows[ $flow_id ] ) ) {
			return new WP_Error( 'not_found', 'Flow not found' );
		}

		// Check slug uniqueness if changed.
		if ( ! empty( $data['slug'] ) && $data['slug'] !== $flows[ $flow_id ]['slug'] ) {
			foreach ( $flows as $id => $flow ) {
				if ( $id !== $flow_id && $flow['slug'] === $data['slug'] ) {
					return new WP_Error( 'duplicate_slug', 'Slug already in use' );
				}
			}
		}

		// Merge with existing data.
		$flow               = array_merge( $flows[ $flow_id ], $data );
		$flow               = $this->normalize_flow_data( $flow );
		$flow['id']         = $flow_id; // Preserve ID.
		$flow['updated_at'] = current_time( 'mysql' );

		// Save.
		$flows[ $flow_id ] = $flow;
		update_option( self::OPTION_KEY, $flows );

		// Flush rewrite rules in case slug changed.
		flush_rewrite_rules();

		return $flow;
	}

	/**
	 * Delete a flow.
	 *
	 * @param mixed $flow_id Flow identifier used to resolve flow-scoped configuration and state.
	 * @return Bool Whether flow applies to the current state.
	 */
	public function delete_flow( $flow_id ) {
		$flows = $this->get_all_flows();

		if ( ! isset( $flows[ $flow_id ] ) ) {
			return new WP_Error( 'not_found', 'Flow not found' );
		}

		// Don't allow deleting the last flow.
		if ( count( $flows ) <= 1 ) {
			return new WP_Error( 'last_flow', 'Cannot delete the last flow' );
		}

		unset( $flows[ $flow_id ] );
		update_option( self::OPTION_KEY, $flows );

		// v1.2.3: Properly remove flow access from users (handles serialized arrays correctly).
		$users_with_access = $this->get_flow_users( $flow_id );
		foreach ( $users_with_access as $user ) {
			$this->revoke_flow_access( $user->ID, $flow_id );
		}

		flush_rewrite_rules();

		return true;
	}

	/**
	 * Normalize flow data with defaults.
	 * Added 'overrides' for per-flow settings.
	 *
	 * @since 1.2.3
	 * @param mixed $data Structured data consumed by the Normalize the input into the canonical form required for normalize flow data. operation.
	 * @return Mixed Result produced by the normalize flow data operation.
	 */
	private function normalize_flow_data( $data ) {
		$defaults = array(
			'id'              => '',
			'slug'            => '',
			'custom_domain'   => '',
			'status'          => 'active',
			'identity'        => array(
				'name'          => 'FLOSC App',
				'tagline'       => '',
				'chatlogo_url'  => '',
				'favicon_url'   => '',
				'primary_color' => '#4f46e5',
				'share_text'    => '',
			),
			'ivr_file'        => 'flosc_default_technical_ivr.md',
			'wp_category_id'  => 0,
			// Empty = no quiz until admin enables one on the Quiz tab.
			'quiz_type'       => '',
			'enabled_quizzes' => array(),
			'created_at'      => '',
			'updated_at'      => '',
			// v1.2.3: Per-flow settings overrides.
			'overrides'       => array(
				'style'        => array( 'use_global' => true ),
				'ai'           => array( 'use_global' => true ),
				'email'        => array( 'use_global' => true ),
				'ai_knowledge' => array( 'use_global' => true ),
				'offers'       => array( 'use_global' => true ),
				'payments'     => array( 'use_global' => true ),
				'lessons'      => array( 'use_global' => true ),
			),
		);

		$flow = wp_parse_args( $data, $defaults );

		// Normalize identity sub-array.
		$flow['identity'] = wp_parse_args(
			$data['identity'] ?? array(),
			$defaults['identity']
		);

		// v1.2.3: Normalize overrides sub-array.
		$flow['overrides'] = wp_parse_args(
			$data['overrides'] ?? array(),
			$defaults['overrides']
		);
		// Ensure each override group has use_global flag.
		foreach ( $defaults['overrides'] as $key => $default_override ) {
			if ( ! isset( $flow['overrides'][ $key ] ) ) {
				$flow['overrides'][ $key ] = $default_override;
			} elseif ( ! isset( $flow['overrides'][ $key ]['use_global'] ) ) {
				$flow['overrides'][ $key ]['use_global'] = true;
			}
		}

		// Sanitize.
		$flow['id']            = sanitize_key( $flow['id'] );
		$flow['slug']          = sanitize_title( $flow['slug'] );
		$flow['custom_domain'] = sanitize_text_field( $flow['custom_domain'] );
		$flow['status']        = in_array( $flow['status'], array( 'active', 'draft' ), true ) ? $flow['status'] : 'draft';
		// v1.2.3: Allow subdirectory paths for IVR files (e.g., '{flowname}/ivr.md').
		$flow['ivr_file']       = preg_replace( '#[^a-zA-Z0-9/_.-]#', '', $flow['ivr_file'] );
		$flow['wp_category_id'] = intval( $flow['wp_category_id'] );
		$flow['quiz_type']      = sanitize_key( $flow['quiz_type'] );

		// Sanitize identity.
		$flow['identity']['name']         = sanitize_text_field( $flow['identity']['name'] );
		$flow['identity']['tagline']      = sanitize_text_field( $flow['identity']['tagline'] );
		$flow['identity']['chatlogo_url'] = esc_url_raw( $flow['identity']['chatlogo_url'] );
		$flow['identity']['favicon_url']  = esc_url_raw( $flow['identity']['favicon_url'] ?? '' );
		// sanitize_hex_color() returns null for anything that is not a hex.
		// colour, so a malformed value falls back rather than reaching the page.
		$flosc_primary_color               = sanitize_hex_color( $flow['identity']['primary_color'] );
		$flow['identity']['primary_color'] = $flosc_primary_color ? $flosc_primary_color : '#4f46e5';
		$flow['identity']['share_text']    = sanitize_text_field( $flow['identity']['share_text'] );

		return $flow;
	}

	/**
	 * Check if user can access flow admin.
	 *
	 * @param mixed $flow_id Flow identifier used to resolve flow-scoped configuration and state.
	 * @param mixed $user_id WordPress user ID whose Determine whether the current state satisfies access flow admin. state is being processed.
	 * @return Bool Whether access flow admin applies to the current state.
	 */
	public function can_access_flow_admin( $flow_id, $user_id = null ) {
		$user_id = $user_id ? $user_id : get_current_user_id();

		// Administrators see all flows.
		if ( user_can( $user_id, 'manage_options' ) ) {
			return true;
		}

		// Must be at least Editor.
		if ( ! user_can( $user_id, 'edit_others_posts' ) ) {
			return false;
		}

		// Check flow assignment.
		$allowed = get_user_meta( $user_id, '_flosc_flow_access', true );
		return is_array( $allowed ) && in_array( (string) $flow_id, array_map( 'strval', $allowed ), true );
	}

	/**
	 * Grant user access to a flow.
	 *
	 * @param mixed $user_id WordPress user ID whose Persist the grant flow access state in Word Press storage. state is being processed.
	 * @param mixed $flow_id Flow identifier used to resolve flow-scoped configuration and state.
	 * @return Bool Whether grant flow access applies to the current state.
	 */
	public function grant_flow_access( $user_id, $flow_id ) {
		$allowed = get_user_meta( $user_id, '_flosc_flow_access', true );
		if ( ! $allowed ) {
			$allowed = array();
		}

		if ( ! is_array( $allowed ) ) {
			$allowed = array();
		}

		if ( ! in_array( (string) $flow_id, array_map( 'strval', $allowed ), true ) ) {
			$allowed[] = (string) $flow_id;
			update_user_meta( $user_id, '_flosc_flow_access', $allowed );
		}

		return true;
	}

	/**
	 * Revoke user access to a flow.
	 *
	 * @param mixed $user_id WordPress user ID whose Persist the revoke flow access state in Word Press storage. state is being processed.
	 * @param mixed $flow_id Flow identifier used to resolve flow-scoped configuration and state.
	 * @return Bool Whether revoke flow access applies to the current state.
	 */
	public function revoke_flow_access( $user_id, $flow_id ) {
		$allowed = get_user_meta( $user_id, '_flosc_flow_access', true );
		if ( ! $allowed ) {
			$allowed = array();
		}

		if ( ! is_array( $allowed ) ) {
			return true;
		}

		$allowed = array_filter(
			$allowed,
			function ( $id ) use ( $flow_id ) {
				return (string) $id !== (string) $flow_id;
			}
		);

		update_user_meta( $user_id, '_flosc_flow_access', array_values( $allowed ) );

		return true;
	}

	/**
	 * Get users with access to a flow.
	 * More robust serialized array handling.
	 *
	 * @since 1.2.3
	 * @param mixed $flow_id Flow identifier used to resolve flow-scoped configuration and state.
	 * @return Array Structured flow users data.
	 */
	public function get_flow_users( $flow_id ) {
		$candidate_ids = function_exists( 'flosc_get_user_ids_for_meta' )
			? flosc_get_user_ids_for_meta( '_flosc_flow_access' )
			: array();

		if ( empty( $candidate_ids ) ) {
			return array();
		}

		$matching_users = array();
		foreach ( $candidate_ids as $user_id ) {
			$user_id = (int) $user_id;
			$allowed = get_user_meta( $user_id, '_flosc_flow_access', true );
			if ( is_array( $allowed ) && in_array( $flow_id, $allowed, true ) ) {
				$matching_users[] = $user_id;
			}
		}

		if ( empty( $matching_users ) ) {
			return array();
		}

		return get_users(
			array(
				'include' => $matching_users,
				'fields'  => array( 'ID', 'display_name', 'user_email' ),
			)
		);
	}

	/**
	 * Get available IVR files.
	 * Looks for *_ivr.md files in ai_configuration_files/.
	 * Per WordPress.org policy, files are resolved uploads-first via flosc_config_glob().
	 *
	 * @since 1.2.3
	 * @return Mixed Result produced by the available ivr files operation.
	 */
	public function get_available_ivr_files() {
		$files = array();

		// Get all *_ivr.md files — §2: union shipped defaults with uploaded/edited files (uploads wins).
		// flosc_config_glob() handles the search and returns paths in uploads-first order.
		$ivr_files = flosc_config_glob( '*_ivr.md' );
		foreach ( $ivr_files as $file ) {
			$files[] = basename( $file );
		}

		// Also check for legacy ivr.md (backward compatibility).
		if ( file_exists( flosc_config_file( 'ivr.md' ) ) ) {
			$files[] = 'ivr.md';
		}

		// Sort alphabetically.
		sort( $files );

		return $files;
	}

	/**
	 * Get available quiz types.
	 *
	 * @return Array Structured available quiz types data.
	 */
	public function get_available_quiz_types() {
		return array(
			'flosc_sample_data_numbers_quiz' => 'Text-Based Quiz',
			'flosc_sample_audio_quiz'        => 'Audio Quiz (Pronunciation)',
			'multiplechoice_quiz'            => 'Multiple Choice',
			'truefalse_quiz'                 => 'True/False',
			'wordmatching_quiz'              => 'Word Matching',
		);
	}

	/**
	 * Migrate from legacy settings (v1.2.1) to flows (v1.2.2)
	 *
	 * @return Bool Whether migrate from legacy applies to the current state.
	 */
	public function maybe_migrate_from_legacy() {
		// If flows already exist, don't migrate.
		if ( false !== get_option( self::OPTION_KEY ) ) {
			return false;
		}

		// Generic WordPress.org / fresh-install model: ONE active example flow.
		// with an IVR that ships in the package. Specialty product flows (admin imports,.
		// Solfeggio, assistant, etc.) are admin imports — not auto-activated.
		$ivr_file = 'flosc_default_technical_ivr.md';
		$shipped  = FLOSC_PLUGIN_DIR . 'ai_configuration_files/' . $ivr_file;
		if ( ! file_exists( $shipped ) ) {
			$ivr_file = 'flosc_default_ivr.md';
		}

		$default_flows = array(
			'default' => array(
				'id'             => 'default',
				'slug'           => get_option( 'flosc_app_slug', 'flosc' ),
				'custom_domain'  => get_option( 'flosc_custom_domain', '' ),
				'status'         => 'active',
				'identity'       => array(
					'name'          => get_option( 'flosc_product_name', 'FLOSC' ),
					'title'         => get_option( 'flosc_product_title', '' ),
					'tagline'       => get_option( 'flosc_product_tagline', '' ),
					'chatlogo_url'  => get_option( 'flosc_product_logo', '' ),
					'primary_color' => get_option( 'flosc_primary_color', '#4f46e5' ),
					'share_text'    => get_option( 'flosc_share_text', '' ),
				),
				'ivr_file'       => $ivr_file,
				'wp_category_id' => intval( get_option( 'flosc_content_item_category', 0 ) ),
				'created_at'     => current_time( 'mysql' ),
				'updated_at'     => current_time( 'mysql' ),
			),
		);

		update_option( self::OPTION_KEY, $default_flows );

		if ( defined( 'FLOSC_DEBUG' ) && FLOSC_DEBUG ) {
			flosc_log( 'FLOSC: Created single generic default flow (ivr=' . $ivr_file . ')' );
		}

		return true;
	}

	/**
	 * Get setting value with flow override support.
	 * Checks flow override first, falls back to global option.
	 *
	 * @param string      $option_name    The wp_options key.
	 * @param string      $override_group Which override group (style, ai, email, etc.).
	 * @param string      $override_key   Key within the override group (optional, defaults to option_name).
	 * @param mixed       $fallback       Default value if neither found.
	 * @param string|null $flow_id        Flow ID (null = use current flow).
	 * @return Mixed The setting value.
	 * @since 1.2.3
	 */
	public function get_setting( $option_name, $override_group, $override_key = null, $fallback = null, $flow_id = null ) {
		// Determine flow.
		if ( null === $flow_id ) {
			$flow = $this->get_current_flow();
		} else {
			$flow = $this->get_flow( $flow_id );
		}

		// If no flow found, use global.
		if ( ! $flow ) {
			return get_option( $option_name, $fallback );
		}

		// Check if flow uses global settings for this group.
		$use_global = $flow['overrides'][ $override_group ]['use_global'] ?? true;

		if ( $use_global ) {
			return get_option( $option_name, $fallback );
		}

		// Use flow override.
		$key = $override_key ? $override_key : $option_name;
		return $flow['overrides'][ $override_group ][ $key ] ?? get_option( $option_name, $fallback );
	}

	/**
	 * Get current flow from context.
	 * Wrapper around global get_current_flow() function.
	 *
	 * @return Mixed Result produced by the current flow operation.
	 */
	public function get_current_flow() {
		if ( function_exists( 'get_current_flow' ) ) {
			$flow_data = get_current_flow();
			return $flow_data ? $flow_data : null;
		}
		return null;
	}

	/**
	 * Update flow override settings.
	 * Sets override values for a specific group.
	 *
	 * @param string $flow_id        The flow ID.
	 * @param string $override_group Which override group (style, ai, email, etc.).
	 * @param array  $values         The settings values.
	 * @param bool   $use_global     Whether to use global settings.
	 * @return Bool|WP_Error.
	 * @since 1.2.3
	 */
	public function update_override( $flow_id, $override_group, $values, $use_global = false ) {
		$flows = $this->get_all_flows();

		if ( ! isset( $flows[ $flow_id ] ) ) {
			return new WP_Error( 'not_found', 'Flow not found' );
		}

		// Initialize overrides if needed.
		if ( ! isset( $flows[ $flow_id ]['overrides'] ) ) {
			$flows[ $flow_id ]['overrides'] = array();
		}

		// Set the override.
		$flows[ $flow_id ]['overrides'][ $override_group ] = array_merge(
			array( 'use_global' => $use_global ),
			$values
		);

		$flows[ $flow_id ]['updated_at'] = current_time( 'mysql' );

		return update_option( self::OPTION_KEY, $flows );
	}
}
