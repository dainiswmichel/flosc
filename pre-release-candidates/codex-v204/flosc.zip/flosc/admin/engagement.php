<?php
/**
 * FLOSC Engagement Tab
 *
 * Purpose: trigger floscFlow responses when profiles behave a certain way.
 * Structure: accordion by audience (Visitor / Guest / Member), each with
 * when → condition → then (chat and/or email). Freeform conditions use the same
 * language as Offers (FLOSC_Condition_Evaluator).
 *
 * Not: offer builder (→ Offers). Not: letter body editor (→ Email). Not: F→L→O→S→C map (→ Flow).
 *
 * @package FLOSC
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

flosc_tab_header( '📊', 'Engagement' );

$flosc_flow_settings = $GLOBALS['flosc_current_settings'] ?? array();
$flosc_current_ivr   = $GLOBALS['flosc_current_ivr'] ?? '';
$flosc_flow_id       = '' !== $flosc_current_ivr ? pathinfo( $flosc_current_ivr, PATHINFO_FILENAME ) : '';

$flosc_base_q                        = array(
	'page' => 'flosc-settings',
	'ivr'  => $flosc_current_ivr,
);
$flosc_tab_url                       = static function ( $tab ) use ( $flosc_base_q ) {
	return add_query_arg( array_merge( $flosc_base_q, array( 'tab' => $tab ) ), admin_url( 'admin.php' ) );
};
$flosc_engagement_docs_url           = add_query_arg(
	array_merge(
		$flosc_base_q,
		array(
			'tab' => 'documentation',
			'doc' => 'ref-admin',
		)
	),
	admin_url( 'admin.php' )
) . '#tab-engagement';
$flosc_engagement_docs_inventory_url = add_query_arg(
	array_merge(
		$flosc_base_q,
		array(
			'tab' => 'documentation',
			'doc' => 'ref-admin',
		)
	),
	admin_url( 'admin.php' )
) . '#inventory-communication-family';

// ── Default rule parameters (starter values only — floscAdmin edits these) ────
$flosc_default_rules = array(
	array(
		'id'             => 'visitor_chat_open',
		'title'          => 'Visitor · chat open',
		'audience'       => 'visitor',
		'enabled'        => '',
		'trigger'        => 'chat_open',
		'trigger_days'   => '0',
		'condition'      => 'is_visitor',
		'action_chat'    => '1',
		'action_email'   => '',
		'email_template' => '',
		'chat_message'   => 'Hi — ask me anything.',
	),
	array(
		'id'             => 'guest_return_chat',
		'title'          => 'Guest · welcome back',
		'audience'       => 'guest',
		'enabled'        => '1',
		'trigger'        => 'return_login',
		'trigger_days'   => '0',
		'condition'      => 'is_guest && login_count >= 2',
		'action_chat'    => '1',
		'action_email'   => '',
		'email_template' => '',
		'chat_message'   => 'Welcome back!',
	),
	array(
		'id'             => 'guest_inactive_email',
		'title'          => 'Guest · inactive email',
		'audience'       => 'guest',
		'enabled'        => '',
		'trigger'        => 'inactive_days',
		'trigger_days'   => '7',
		'condition'      => 'is_guest && !purchased',
		'action_chat'    => '',
		'action_email'   => '1',
		'email_template' => 'reengagement',
		'chat_message'   => '',
	),
	array(
		'id'             => 'member_inactive_email',
		'title'          => 'Member · inactive email',
		'audience'       => 'member',
		'enabled'        => '1',
		'trigger'        => 'inactive_days',
		'trigger_days'   => '10',
		'condition'      => 'is_member',
		'action_chat'    => '',
		'action_email'   => '1',
		'email_template' => 'reengagement',
		'chat_message'   => '',
	),
	array(
		'id'             => 'member_return_chat',
		'title'          => 'Member · welcome back',
		'audience'       => 'member',
		'enabled'        => '',
		'trigger'        => 'return_login',
		'trigger_days'   => '0',
		'condition'      => 'is_member && login_count >= 2',
		'action_chat'    => '1',
		'action_email'   => '',
		'email_template' => '',
		'chat_message'   => 'Welcome back.',
	),
);

$flosc_rules = $flosc_flow_settings['engagement_rules'] ?? null;
if ( ! is_array( $flosc_rules ) || empty( $flosc_rules ) ) {
	$flosc_rules = $flosc_default_rules;
}

$flosc_guest_access_days = isset( $flosc_flow_settings['guest_access_days'] )
	? max( 0, min( 365, intval( $flosc_flow_settings['guest_access_days'] ) ) )
	: 0;

// Labels describe WHEN the user sees the response (not just the condition name).
$flosc_triggers        = array(
	'chat_open'               => 'Chat opens — once per browser session',
	'return_login'            => 'Return login — when chat opens (login #2+)',
	'inactive_days'           => 'Inactive for N days — email schedule (chat not auto-shown)',
	'days_since_registration' => 'Days since registration ≥ N — when chat opens',
	'profile_incomplete'      => 'Profile incomplete — when chat opens',
);
$flosc_email_templates = array(
	''                 => '— none —',
	'reengagement'     => 'Re-engagement (Email tab template)',
	'guest_welcome'    => 'Guest welcome',
	'guest_followup_1' => 'Guest follow-up 1 (early window)',
	'guest_followup_2' => 'Guest follow-up 2 (mid window)',
	'guest_followup_3' => 'Guest follow-up 3 (late window)',
	// Legacy template ids (still resolve via dual-read in email senders).
	'guest_day10'      => 'Guest follow-up 1 (legacy id)',
	'guest_day20'      => 'Guest follow-up 2 (legacy id)',
	'guest_day28'      => 'Guest follow-up 3 (legacy id)',
);

/**
 * One rule as a collapsible accordion (title in summary).
 *
 * @param array  $rule
 * @param string $audience visitor|guest|member
 * @param int    $index
 * @param bool   $open
 */
$flosc_render_rule = static function ( $rule, $audience, $index, $open = false ) use ( $flosc_triggers, $flosc_email_templates ) {
	$rid         = sanitize_key( (string) ( $rule['id'] ?? ( 'rule_' . $index ) ) );
	$flosc_title = trim( (string) ( $rule['title'] ?? '' ) );
	if ( '' === $flosc_title ) {
		$flosc_title = '' !== $rid ? $rid : ( 'Rule ' . ( (int) $index + 1 ) );
	}
	$en           = ! empty( $rule['enabled'] );
	$trig         = sanitize_key( (string) ( $rule['trigger'] ?? 'chat_open' ) );
	$days         = max( 0, min( 365, intval( $rule['trigger_days'] ?? 0 ) ) );
	$cond         = (string) ( $rule['condition'] ?? '' );
	$chat_on      = ! empty( $rule['action_chat'] );
	$email_on     = ! empty( $rule['action_email'] );
	$tpl          = sanitize_key( (string) ( $rule['email_template'] ?? '' ) );
	$msg          = (string) ( $rule['chat_message'] ?? '' );
	$trig_lab     = $flosc_triggers[ $trig ] ?? $trig;
	$preview_bits = array();
	if ( $en ) {
		$preview_bits[] = 'active';
	} else {
		$preview_bits[] = 'off';
	}
	if ( $chat_on ) {
		$preview_bits[] = 'chat';
	}
	if ( $email_on ) {
		$preview_bits[] = 'email';
	}
	$preview_bits[] = $trig_lab;
	$flosc_preview  = implode( ' · ', $preview_bits );
	?>
	<details class="flosc-eng-rule" data-audience="<?php echo esc_attr( $audience ); ?>" data-rule-index="<?php echo esc_attr( (string) $index ); ?>"<?php echo $open ? ' open' : ''; ?>>
		<summary class="flosc-eng-rule__summary">
			<span class="flosc-eng-rule__summary-title"><?php echo esc_html( $flosc_title ); ?></span>
			<span class="flosc-eng-rule__summary-preview"><?php echo esc_html( $flosc_preview ); ?></span>
		</summary>
		<div class="flosc-eng-rule__body">
			<input type="hidden" name="engagement_rule_id[]" class="flosc-eng-rule-id" value="<?php echo esc_attr( $rid ); ?>">
			<input type="hidden" name="engagement_rule_audience[]" class="flosc-eng-rule-audience" value="<?php echo esc_attr( $audience ); ?>">
			<p class="flosc-eng-toolbar">
				<label>
					<input type="checkbox" class="flosc-eng-rule-enabled" name="engagement_rule_enabled[<?php echo esc_attr( (string) $index ); ?>]" value="1" <?php checked( $en ); ?>>
					<strong>Rule active</strong>
				</label>
				<button type="button" class="button-link-delete flosc-eng-rule-remove">Remove rule</button>
			</p>
			<table class="form-table flosc-eng-form-table">
				<tr>
					<th scope="row"><label>Title</label></th>
					<td>
						<input type="text" name="engagement_rule_title[]" class="regular-text flosc-eng-rule-title"
								value="<?php echo esc_attr( $flosc_title ); ?>" placeholder="e.g. Welcome back chat">
						<p class="description">Shown in the rule accordion header. Id: <code class="flosc-eng-rule-id-label"><?php echo esc_html( $rid ); ?></code></p>
					</td>
				</tr>
				<tr>
					<th scope="row">When</th>
					<td>
						<select name="engagement_rule_trigger[]" class="regular-text flosc-eng-rule-trigger">
							<?php foreach ( $flosc_triggers as $k => $lab ) : ?>
								<option value="<?php echo esc_attr( $k ); ?>" <?php selected( $trig, $k ); ?>><?php echo esc_html( $lab ); ?></option>
							<?php endforeach; ?>
						</select>
						<label class="flosc-email-inline-label-right">N =
							<input type="number" name="engagement_rule_days[]" value="<?php echo esc_attr( (string) $days ); ?>"
									min="0" max="365" class="small-text"> days
						</label>
						<p class="description">
							In-chat: once per browser session when chat finishes loading — not mid-conversation.
							Return login = login count ≥ 2. Inactive is primarily for email.
						</p>
					</td>
				</tr>
				<tr>
					<th scope="row">Condition</th>
					<td>
						<input type="text" name="engagement_rule_condition[]" value="<?php echo esc_attr( $cond ); ?>"
								class="large-text flosc-eng-condition-input" placeholder="is_guest && login_count >= 2">
						<p class="description">
							Freeform condition (same language as Offers / IVR). Focus this field, then use
							<strong>Available conditions</strong> above to insert chips.
						</p>
					</td>
				</tr>
				<tr>
					<th scope="row">Then · floscResponse</th>
					<td>
						<label class="flosc-eng-label">
							<input type="checkbox" class="flosc-eng-rule-action-chat" name="engagement_rule_action_chat[<?php echo esc_attr( (string) $index ); ?>]" value="1" <?php checked( $chat_on ); ?>>
							In-chat message
						</label>
						<textarea name="engagement_rule_chat_message[]" rows="2" class="large-text flosc-eng-rule-chat-message"
									placeholder="Welcome back!"><?php echo esc_textarea( $msg ); ?></textarea>
						<p class="description flosc-eng-desc-spacious">
							Parameter you edit. AI is told this was an <strong>admin engagement</strong> insert.
						</p>
						<label class="flosc-eng-label flosc-eng-label-spaced">
							<input type="checkbox" class="flosc-eng-rule-action-email" name="engagement_rule_action_email[<?php echo esc_attr( (string) $index ); ?>]" value="1" <?php checked( $email_on ); ?>>
							Send email when this fires
						</label>
						<select name="engagement_rule_email_template[]" class="regular-text">
							<?php foreach ( $flosc_email_templates as $ek => $elab ) : ?>
								<option value="<?php echo esc_attr( $ek ); ?>" <?php selected( $tpl, $ek ); ?>><?php echo esc_html( $elab ); ?></option>
							<?php endforeach; ?>
						</select>
						<p class="description">
							Letter copy on
							<a href="
							<?php
							echo esc_url(
								add_query_arg(
									array(
										'page' => 'flosc-settings',
										'ivr'  => $GLOBALS['flosc_current_ivr'] ?? '',
										'tab'  => 'email',
									),
									admin_url( 'admin.php' )
								)
							);
							?>
										">Email</a>.
							Offers:
							<a href="
							<?php
							echo esc_url(
								add_query_arg(
									array(
										'page' => 'flosc-settings',
										'ivr'  => $GLOBALS['flosc_current_ivr'] ?? '',
										'tab'  => 'offers',
									),
									admin_url( 'admin.php' )
								)
							);
							?>
										">Offers</a>.
						</p>
					</td>
				</tr>
			</table>
		</div>
	</details>
	<?php
};

// Split rules by audience (form index assigned when rendering so arrays stay aligned).
$flosc_visitor_rules = array();
$flosc_guest_rules   = array();
$flosc_member_rules  = array();
foreach ( $flosc_rules as $flosc_rule ) {
	if ( ! is_array( $flosc_rule ) ) {
		continue;
	}
	$flosc_aud = sanitize_key( (string) ( $flosc_rule['audience'] ?? 'guest' ) );
	if ( 'visitor' === $flosc_aud ) {
		$flosc_visitor_rules[] = $flosc_rule;
	} elseif ( 'member' === $flosc_aud ) {
		$flosc_member_rules[] = $flosc_rule;
	} else {
		$flosc_guest_rules[] = $flosc_rule;
	}
}
if ( empty( $flosc_visitor_rules ) ) {
	$flosc_visitor_rules[] = $flosc_default_rules[0];
}
if ( empty( $flosc_guest_rules ) ) {
	$flosc_guest_rules[] = $flosc_default_rules[1];
}
if ( empty( $flosc_member_rules ) ) {
	$flosc_member_rules[] = $flosc_default_rules[3];
}
$flosc_form_index = 0;

$flosc_count_active = static function ( $rules ) {
	$n = 0;
	foreach ( $rules as $r ) {
		if ( is_array( $r ) && ! empty( $r['enabled'] ) ) {
			++$n;
		}
	}
	return $n;
};

// Profile activity (this flow only).
// Match registration_flow / last_flow against stem variants — writers sometimes
// sanitize_key() a full "file.md" (becomes filmd) while the admin stem is pathinfo().
$flosc_summary_users = array();
if ( '' !== $flosc_flow_id || '' !== $flosc_current_ivr ) {
	$flosc_ivr_base = basename( (string) $flosc_current_ivr );
	$flosc_stem     = sanitize_key( pathinfo( $flosc_ivr_base, PATHINFO_FILENAME ) );
	if ( '' === $flosc_stem && '' !== $flosc_flow_id ) {
		$flosc_stem = sanitize_key( (string) $flosc_flow_id );
	}
	$flosc_flow_match_vals = array_values(
		array_unique(
			array_filter(
				array(
					$flosc_stem,
					$flosc_flow_id,
					$flosc_ivr_base,
					pathinfo( $flosc_ivr_base, PATHINFO_FILENAME ),
					sanitize_key( $flosc_ivr_base ), // For example flow_ivrmd when the source was …ivr.md.
					sanitize_key( (string) $flosc_current_ivr ),
				),
				static function ( $v ) {
					return is_string( $v ) && '' !== $v;
				}
			)
		)
	);

	$flosc_by_id = array();
	if ( ! empty( $flosc_flow_match_vals ) && function_exists( 'flosc_get_user_ids_for_meta_in' ) ) {
		$flosc_merged_ids = array();
		foreach ( array( '_flosc_registration_flow', '_flosc_last_flow', '_flosc_first_flow' ) as $flosc_mk ) {
			$flosc_merged_ids = array_merge(
				$flosc_merged_ids,
				flosc_get_user_ids_for_meta_in( $flosc_mk, $flosc_flow_match_vals, 80 )
			);
		}
		$flosc_merged_ids = array_values( array_unique( array_map( 'intval', $flosc_merged_ids ) ) );
		if ( ! empty( $flosc_merged_ids ) ) {
			$flosc_found = get_users(
				array(
					'include' => $flosc_merged_ids,
					'orderby' => 'registered',
					'order'   => 'DESC',
					'fields'  => array( 'ID', 'user_email', 'display_name', 'user_registered' ),
				)
			);
			foreach ( $flosc_found as $flosc_u_row ) {
				$flosc_by_id[ (int) $flosc_u_row->ID ] = $flosc_u_row;
			}
		}
	}
	// Also surface users who used this flow (counts array) even if registration_flow missing.
	if ( '' !== $flosc_stem ) {
		$flosc_count_ids   = function_exists( 'flosc_get_user_ids_for_meta' )
			? flosc_get_user_ids_for_meta( '_flosc_flow_use_counts', null, '=', 100 )
			: array();
		$flosc_count_users = ! empty( $flosc_count_ids )
			? get_users(
				array(
					'include' => $flosc_count_ids,
					'orderby' => 'registered',
					'order'   => 'DESC',
					'fields'  => array( 'ID', 'user_email', 'display_name', 'user_registered' ),
				)
			)
			: array();
		foreach ( $flosc_count_users as $flosc_cu ) {
			$flosc_counts = get_user_meta( (int) $flosc_cu->ID, '_flosc_flow_use_counts', true );
			if ( ! is_array( $flosc_counts ) ) {
				continue;
			}
			foreach ( $flosc_flow_match_vals as $flosc_mv ) {
				if ( isset( $flosc_counts[ $flosc_mv ] ) || isset( $flosc_counts[ $flosc_stem ] ) ) {
					$flosc_by_id[ (int) $flosc_cu->ID ] = $flosc_cu;
					break;
				}
			}
		}
	}
	$flosc_summary_users = array_values( $flosc_by_id );
	usort(
		$flosc_summary_users,
		static function ( $a, $b ) {
			return strcmp( (string) ( $b->user_registered ?? '' ), (string) ( $a->user_registered ?? '' ) );
		}
	);
	$flosc_summary_users = array_slice( $flosc_summary_users, 0, 50 );
}
$flosc_framework = class_exists( 'FLOSC_Framework' ) ? FLOSC_Framework::instance() : null;
?>

<div class="flosc-flow-overview">
	<div class="flosc-flow-overview-header">
		<h2 class="flosc-flow-overview-title">
			<span>Engagement — when profiles behave, FLOSC responds</span>
			<a href="<?php echo esc_url( $flosc_engagement_docs_url ); ?>" class="flosc-docs-link">Docs</a>
			<a href="<?php echo esc_url( $flosc_engagement_docs_inventory_url ); ?>" class="flosc-docs-link">Parameter Docs</a>
		</h2>
		<p class="flosc-flow-overview-summary">
			<strong>This tab:</strong> parameters for <em>when</em> floscResponses fire (including <em>when</em> to send email)
			and which conditions can trigger them.
			<strong>In-chat timing:</strong> once per browser session when chat finishes loading — not randomly mid-chat.
			Related surfaces (not reconfigured here): Flow, Quiz, Concierge, Trajectories, Offers, Email.
		</p>
		<p class="flosc-eng-related-links">
			<a class="button button-small" href="<?php echo esc_url( $flosc_tab_url( 'flow' ) ); ?>">Flow →</a>
			<a class="button button-small" href="<?php echo esc_url( $flosc_tab_url( 'quiz' ) ); ?>">Quiz →</a>
			<a class="button button-small" href="<?php echo esc_url( $flosc_tab_url( 'concierge' ) ); ?>">Concierge →</a>
			<a class="button button-small" href="<?php echo esc_url( $flosc_tab_url( 'trajectories' ) ); ?>">Trajectories →</a>
			<a class="button button-small" href="<?php echo esc_url( $flosc_tab_url( 'offers' ) ); ?>">Offers →</a>
			<a class="button button-small" href="<?php echo esc_url( $flosc_tab_url( 'email' ) ); ?>">Email →</a>
		</p>
	</div>

	<!-- Conditions catalog (collapsed by default — same pattern as audience accordions) -->
	<details class="flosc-condition-reference flosc-eng-accordion" id="flosc-eng-conditions-catalog">
		<summary>Available conditions that trigger floscResponses</summary>
		<div class="flosc-condition-ref-body">
			<p class="description">
				Click a chip to <strong>copy</strong> it. Focus a rule’s Condition field first, then click a chip to
				<strong>insert</strong> into that field. Combine with <code>&&</code> <code>||</code> <code>!</code> <code>()</code>.
				Same evaluator language as Offers and IVR.
			</p>
			<div class="flosc-condition-ref-grid">
				<div class="flosc-condition-ref-section">
					<h4>Audience &amp; access</h4>
					<button type="button" class="flosc-condition-copy" data-condition="is_visitor"><code>is_visitor</code></button>
					<span class="flosc-cond-desc">Not logged in</span>
					<button type="button" class="flosc-condition-copy" data-condition="is_guest"><code>is_guest</code></button>
					<span class="flosc-cond-desc">Logged in, not purchased</span>
					<button type="button" class="flosc-condition-copy" data-condition="is_member"><code>is_member</code></button>
					<span class="flosc-cond-desc">Member / full access on this flow</span>
					<button type="button" class="flosc-condition-copy" data-condition="logged_in"><code>logged_in</code></button>
					<button type="button" class="flosc-condition-copy" data-condition="!logged_in"><code>!logged_in</code></button>
					<button type="button" class="flosc-condition-copy" data-condition="purchased"><code>purchased</code></button>
					<button type="button" class="flosc-condition-copy" data-condition="!purchased"><code>!purchased</code></button>
					<button type="button" class="flosc-condition-copy" data-condition="has_sso"><code>has_sso</code></button>
					<button type="button" class="flosc-condition-copy" data-condition="has_profile"><code>has_profile</code></button>
				</div>
				<div class="flosc-condition-ref-section">
					<h4>Quiz &amp; score</h4>
					<button type="button" class="flosc-condition-copy" data-condition="quiz_taken"><code>quiz_taken</code></button>
					<button type="button" class="flosc-condition-copy" data-condition="!quiz_taken"><code>!quiz_taken</code></button>
					<button type="button" class="flosc-condition-copy" data-condition="score >= 70"><code>score >= 70</code></button>
					<button type="button" class="flosc-condition-copy" data-condition="score < 50"><code>score < 50</code></button>
					<button type="button" class="flosc-condition-copy" data-condition="initial_score >= 80"><code>initial_score >= 80</code></button>
				</div>
				<div class="flosc-condition-ref-section">
					<h4>Login &amp; time</h4>
					<button type="button" class="flosc-condition-copy" data-condition="login_count >= 2"><code>login_count >= 2</code></button>
					<button type="button" class="flosc-condition-copy" data-condition="login_count >= 3"><code>login_count >= 3</code></button>
					<button type="button" class="flosc-condition-copy" data-condition="days_since_registration >= 10"><code>days_since_registration >= 10</code></button>
					<button type="button" class="flosc-condition-copy" data-condition="returning_user"><code>returning_user</code></button>
					<button type="button" class="flosc-condition-copy" data-condition="message_count > 3"><code>message_count > 3</code></button>
					<button type="button" class="flosc-condition-copy" data-condition="session_minutes >= 5"><code>session_minutes >= 5</code></button>
				</div>
				<div class="flosc-condition-ref-section">
					<h4>Lessons &amp; content</h4>
					<button type="button" class="flosc-condition-copy" data-condition="lesson_viewed"><code>lesson_viewed</code></button>
					<button type="button" class="flosc-condition-copy" data-condition="lessons_completed >= 1"><code>lessons_completed >= 1</code></button>
					<button type="button" class="flosc-condition-copy" data-condition="onboarded"><code>onboarded</code></button>
					<button type="button" class="flosc-condition-copy" data-condition="has_incomplete_lesson"><code>has_incomplete_lesson</code></button>
				</div>
				<div class="flosc-condition-ref-section">
					<h4>Offer tracking <span class="description">(configure offers on Offers tab)</span></h4>
					<button type="button" class="flosc-condition-copy" data-condition="offer_shown_full_access"><code>offer_shown_{id}</code></button>
					<span class="flosc-cond-desc">Replace with real offer id — used when Offers auto-show</span>
					<button type="button" class="flosc-condition-copy" data-condition="!offer_purchased_full_access"><code>!offer_purchased_{id}</code></button>
					<p class="description flosc-eng-desc-mt">
						<a class="button button-small" href="<?php echo esc_url( $flosc_tab_url( 'offers' ) ); ?>">Open Offers to configure →</a>
					</p>
				</div>
				<div class="flosc-condition-ref-section">
					<h4>Always / never</h4>
					<button type="button" class="flosc-condition-copy" data-condition="always"><code>always</code></button>
					<button type="button" class="flosc-condition-copy" data-condition="never"><code>never</code></button>
					<button type="button" class="flosc-condition-copy" data-condition="is_guest && login_count >= 2"><code>is_guest && login_count >= 2</code></button>
					<span class="flosc-cond-desc">Example: returning guest</span>
					<button type="button" class="flosc-condition-copy" data-condition="is_member"><code>is_member</code></button>
					<button type="button" class="flosc-condition-copy" data-condition="quiz_taken && !purchased"><code>quiz_taken && !purchased</code></button>
					<span class="flosc-cond-desc">Classic post-quiz, not yet member</span>
				</div>
			</div>
		</div>
	</details>

	<div class="flosc-eng-audience-accordions">

		<?php
		// ── Visitor ──────────────────────────────────────────────────────────
		$flosc_v_active = $flosc_count_active( $flosc_visitor_rules );
		?>
		<details class="flosc-eng-accordion flosc-eng-accordion--visitor">
			<summary>
				<span class="flosc-eng-accordion__title">Visitor</span>
				<span class="flosc-eng-accordion__sub">Not logged in · <?php echo esc_html( (string) $flosc_v_active ); ?> active rule(s)</span>
			</summary>
			<div class="flosc-eng-accordion__body">
				<p class="description">Anonymous chat users. In-chat when chat opens (once per browser session). Email is rarely useful here (no address yet).</p>
				<div class="flosc-eng-rule-list" data-audience="visitor">
					<?php
					foreach ( $flosc_visitor_rules as $flosc_rule_row ) {
						$flosc_render_rule( $flosc_rule_row, 'visitor', $flosc_form_index, false );
						++$flosc_form_index;
					}
					?>
				</div>
				<p class="flosc-eng-actions">
					<button type="button" class="button flosc-eng-add-rule" data-audience="visitor">+ Add visitor rule</button>
				</p>
			</div>
		</details>

		<?php
		// ── Guest ────────────────────────────────────────────────────────────
		$flosc_g_active = $flosc_count_active( $flosc_guest_rules );
		?>
		<details class="flosc-eng-accordion flosc-eng-accordion--guest" open>
			<summary>
				<span class="flosc-eng-accordion__title">Guest</span>
				<span class="flosc-eng-accordion__sub">Logged in, not purchased · <?php echo esc_html( (string) $flosc_g_active ); ?> active rule(s)</span>
			</summary>
			<div class="flosc-eng-accordion__body">
				<p class="description">Free / non-member profiles. Example: welcome-back chat, inactive email.</p>
				<table class="form-table flosc-eng-form-table-mb">
					<tr>
						<th scope="row"><label for="flow_guest_access_days">Guest access duration</label></th>
						<td>
							<input type="number" id="flow_guest_access_days" name="flow_guest_access_days"
									value="<?php echo esc_attr( (string) $flosc_guest_access_days ); ?>"
									min="0" max="365" class="small-text"> days
							<p class="description flosc-eng-desc-tight">
								Journey length / remaining-day math. <code>0</code> = no countdown.
								Same key may appear under Content.
								<a href="<?php echo esc_url( $flosc_tab_url( 'email' ) ); ?>">Write email letters →</a>
							</p>
						</td>
					</tr>
				</table>
				<div class="flosc-eng-rule-list" data-audience="guest">
					<?php
					foreach ( $flosc_guest_rules as $flosc_rule_row ) {
						$flosc_render_rule( $flosc_rule_row, 'guest', $flosc_form_index, false );
						++$flosc_form_index;
					}
					?>
				</div>
				<p class="flosc-eng-actions">
					<button type="button" class="button flosc-eng-add-rule" data-audience="guest">+ Add guest rule</button>
				</p>
			</div>
		</details>

		<?php
		// ── Member ───────────────────────────────────────────────────────────
		$flosc_m_active = $flosc_count_active( $flosc_member_rules );
		?>
		<details class="flosc-eng-accordion flosc-eng-accordion--member">
			<summary>
				<span class="flosc-eng-accordion__title">Member</span>
				<span class="flosc-eng-accordion__sub">Purchased / full access · <?php echo esc_html( (string) $flosc_m_active ); ?> active rule(s)</span>
			</summary>
			<div class="flosc-eng-accordion__body">
				<p class="description">Members: full access on this flow. Example: inactive → email; return login → chat.</p>
				<div class="flosc-eng-rule-list" data-audience="member">
					<?php
					foreach ( $flosc_member_rules as $flosc_rule_row ) {
						$flosc_render_rule( $flosc_rule_row, 'member', $flosc_form_index, false );
						++$flosc_form_index;
					}
					?>
				</div>
				<p class="flosc-eng-actions">
					<button type="button" class="button flosc-eng-add-rule" data-audience="member">+ Add member rule</button>
				</p>
			</div>
		</details>
	</div>

	<?php
	// Blank rule template for JS clone (not submitted until added to a list).
	$flosc_blank_rule = array(
		'id'             => '',
		'title'          => 'New rule',
		'enabled'        => '1',
		'trigger'        => 'chat_open',
		'trigger_days'   => '0',
		'condition'      => '',
		'action_chat'    => '1',
		'action_email'   => '',
		'email_template' => '',
		'chat_message'   => '',
	);
	?>
	<template id="flosc-eng-rule-template">
		<?php $flosc_render_rule( $flosc_blank_rule, 'guest', 9999, true ); ?>
	</template>

	<hr>

	<h2>Profile activity <a href="<?php echo esc_url( $flosc_engagement_docs_url ); ?>" class="flosc-docs-link">Docs</a></h2>
	<p class="description">
		Who is on this floscFlow — people who registered here, last used it, or have activity on it.
		Monitor progress toward gated content.
	</p>
	<div class="flosc-engagement-summary-scroll">
		<table class="widefat striped flosc-login-activity-table flosc-eng-table-flush">
			<thead>
				<tr>
					<th>User</th>
					<th>Registered</th>
					<th>State</th>
					<th>Purchased</th>
					<th>Logins</th>
					<th>Profile</th>
					<th>Chat</th>
				</tr>
			</thead>
			<tbody>
			<?php if ( empty( $flosc_summary_users ) ) : ?>
				<tr><td colspan="7">No users registered to this flow yet.</td></tr>
			<?php else : ?>
				<?php
				foreach ( $flosc_summary_users as $flosc_u ) :
					$flosc_uid       = (int) $flosc_u->ID;
					$flosc_purchased = (bool) get_user_meta( $flosc_uid, '_flosc_purchased', true );
					$flosc_logins    = (int) get_user_meta( $flosc_uid, '_flosc_login_count', true );
					$flosc_creds     = (bool) get_user_meta( $flosc_uid, '_flosc_magic_link_user_credentials_set', true )
						|| ! empty( get_user_meta( $flosc_uid, '_flosc_sso_linked_providers', true ) );
					$flosc_state     = '—';
					if ( $flosc_framework && method_exists( $flosc_framework, 'sale' ) ) {
						$flosc_sale = $flosc_framework->sale();
						if ( $flosc_sale && method_exists( $flosc_sale, 'access' ) ) {
							$flosc_state = (string) $flosc_sale->access()->get_simple_state( $flosc_uid, $flosc_flow_id );
						}
					}
					if ( '—' === $flosc_state && $flosc_purchased ) {
						$flosc_state = 'member';
					}
					$flosc_edit     = get_edit_user_link( $flosc_uid );
					$flosc_label    = '' !== $flosc_u->display_name ? $flosc_u->display_name : $flosc_u->user_email;
					$flosc_chat_url = add_query_arg(
						array(
							'page'          => 'flosc-settings',
							'ivr'           => $flosc_current_ivr,
							'tab'           => 'chat-logs',
							'flosc_user_id' => $flosc_uid,
						),
						admin_url( 'admin.php' )
					);
					?>
					<tr>
						<td>
							<?php if ( $flosc_edit ) : ?>
								<a href="<?php echo esc_url( $flosc_edit ); ?>"><?php echo esc_html( $flosc_label ); ?></a>
								<br><span class="description"><?php echo esc_html( $flosc_u->user_email ); ?></span>
							<?php else : ?>
								<?php echo esc_html( $flosc_label ); ?>
							<?php endif; ?>
						</td>
						<td><?php echo esc_html( mysql2date( 'Y-m-d', $flosc_u->user_registered ) ); ?></td>
						<td><?php echo esc_html( '' !== $flosc_state ? $flosc_state : '—' ); ?></td>
						<td><?php echo esc_html( $flosc_purchased ? 'yes' : 'no' ); ?></td>
						<td><?php echo $flosc_logins > 0 ? esc_html( (string) $flosc_logins ) : '—'; ?></td>
						<td><?php echo esc_html( $flosc_creds ? 'complete' : 'pending' ); ?></td>
						<td><a href="<?php echo esc_url( $flosc_chat_url ); ?>">logs</a></td>
					</tr>
				<?php endforeach; ?>
			<?php endif; ?>
			</tbody>
		</table>
	</div>
	<p class="description flosc-eng-desc-mt">
		<?php echo esc_html( (string) count( $flosc_summary_users ) ); ?> row(s).
		<a href="<?php echo esc_url( $flosc_tab_url( 'chat-logs' ) ); ?>">Chat Logs</a>
	</p>
</div>

<?php
// Condition chips + add/remove rules + reindex form fields.
wp_enqueue_script( 'flosc-admin-engagement', FLOSC_PLUGIN_URL . 'assets/js/admin/flosc-admin-engagement.js', array( 'flosc-admin' ), FLOSC_VERSION, true );
