<?php
/**
 * Admin menu, submenu pages and the request helpers the admin screens share.
 *
 * @package FLOSC
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

trait FLOSC_Admin_Trait {
	/**
	 * Admin Menu
	 * v05_02: Menu shortcuts to Settings tabs in logical order
	 */
	public function add_admin_menu() {
		// v1.2.8: Simplified - Settings page IS the main page
		// IVR file dropdown selects which flow to edit.

		// Main FLOSC menu - goes directly to Settings.
		add_menu_page(
			'FLOSC',
			'FLOSC',
			'edit_others_posts',
			'flosc-settings',
			array( $this, 'render_admin_page' ),
			'dashicons-format-chat',
			30
		);

		// 1. Settings (main page - all tabs, flow selector at top)
		add_submenu_page(
			'flosc-settings',
			'Settings',
			'Settings',
			'edit_others_posts',
			'flosc-settings',
			array( $this, 'render_admin_page' )
		);

		// 1a. Flow (shortcut to Flow tab)
		add_submenu_page(
			'flosc-settings',
			'Flow',
			'🗺 Flow',
			'manage_options',
			'flosc-flow',
			array( $this, 'redirect_to_flow_tab' )
		);

		// Identity.
		add_submenu_page(
			'flosc-settings',
			'Identity',
			'Identity',
			'manage_options',
			'flosc-identity',
			array( $this, 'redirect_to_identity_tab' )
		);

		// 2. IVR Messages (redirect to Settings > IVR tab)
		add_submenu_page(
			'flosc-settings',
			'IVR Management',
			'IVR Management',
			'manage_options',
			'flosc-ivr-messages',
			array( $this, 'redirect_to_ivr_tab' )
		);

		// AutoPrompt Panel.
		add_submenu_page(
			'flosc-settings',
			'AutoPrompt Panel',
			'AutoPrompt Panel',
			'manage_options',
			'flosc-autoprompts',
			array( $this, 'redirect_to_autoprompts_tab' )
		);

		// Content (levels + groups + pool; replaces Member Levels + Lessons).
		add_submenu_page(
			'flosc-settings',
			'Content',
			'Content',
			'manage_options',
			'flosc-content',
			array( $this, 'redirect_to_content_tab' )
		);
		// Legacy submenu slugs → Content.
		add_submenu_page(
			null,
			'Member Levels',
			'Member Levels',
			'manage_options',
			'flosc-member-levels',
			array( $this, 'redirect_to_content_tab' )
		);

		add_submenu_page(
			'flosc-settings',
			'Knowledge Base',
			'Knowledge Base',
			'manage_options',
			'flosc-knowledge-base',
			array( $this, 'redirect_to_knowledge_base_tab' )
		);

		// Trajectories.
		add_submenu_page(
			'flosc-settings',
			'Trajectories',
			'Trajectories',
			'manage_options',
			'flosc-trajectories',
			array( $this, 'redirect_to_trajectories_tab' )
		);

		// Offers.
		add_submenu_page(
			'flosc-settings',
			'Offers',
			'Offers',
			'manage_options',
			'flosc-offers',
			array( $this, 'redirect_to_offers_tab' )
		);

		// Register & Login.
		add_submenu_page(
			'flosc-settings',
			'Register & Login',
			'Register & Login',
			'manage_options',
			'flosc-login',
			array( $this, 'redirect_to_login_tab' )
		);

		// 3. Chat Styling
		add_submenu_page(
			'flosc-settings',
			'Style',
			'Style',
			'manage_options',
			'flosc-chat-style',
			array( $this, 'redirect_to_style_tab' )
		);

		// v1.8.0: UI & Navigation.
		add_submenu_page(
			'flosc-settings',
			'UI & Nav',
			'UI & Nav',
			'manage_options',
			'flosc-ui-navigation',
			array( $this, 'render_ui_navigation_page' )
		);

		// 4. AI Configuration
		add_submenu_page(
			'flosc-settings',
			'AI',
			'AI',
			'manage_options',
			'flosc-ai-config',
			array( $this, 'redirect_to_ai_tab' )
		);

		// Token Management.
		add_submenu_page(
			'flosc-settings',
			'Token Management',
			'Token Management',
			'manage_options',
			'flosc-token-management',
			array( $this, 'redirect_to_token_management_tab' )
		);

		// Concierge.
		add_submenu_page(
			'flosc-settings',
			'Concierge',
			'Concierge',
			'manage_options',
			'flosc-concierge',
			array( $this, 'redirect_to_concierge_tab' )
		);

		// Quiz.
		add_submenu_page(
			'flosc-settings',
			'Quiz Settings',
			'Quiz',
			'manage_options',
			'flosc-quiz',
			array( $this, 'redirect_to_quiz_tab' )
		);

		// Email.
		add_submenu_page(
			'flosc-settings',
			'Email Settings',
			'Email',
			'manage_options',
			'flosc-email',
			array( $this, 'redirect_to_email_tab' )
		);

		// Contact Form.
		add_submenu_page(
			'flosc-settings',
			'Contact Form',
			'Contact Form',
			'manage_options',
			'flosc-contact-form',
			array( $this, 'redirect_to_contact_form_tab' )
		);

		// Payments.
		add_submenu_page(
			'flosc-settings',
			'Payments',
			'Payments',
			'manage_options',
			'flosc-payments',
			array( $this, 'redirect_to_payments_tab' )
		);

		// Legacy Lessons slug → Content (hidden from menu).
		add_submenu_page(
			null,
			'Lessons',
			'Lessons',
			'manage_options',
			'flosc-lessons',
			array( $this, 'redirect_to_content_tab' )
		);

		// SSO / Social Login (v1.4.0).
		add_submenu_page(
			'flosc-settings',
			'SSO / Social Login',
			'SSO',
			'manage_options',
			'flosc-sso',
			array( $this, 'redirect_to_sso_tab' )
		);

		// Engagement (journey parameters + profile summary; between SSO and Chat Logs).
		add_submenu_page(
			'flosc-settings',
			'Engagement',
			'Engagement',
			'manage_options',
			'flosc-engagement',
			array( $this, 'redirect_to_engagement_tab' )
		);

		// Chat Logs.
		add_submenu_page(
			'flosc-settings',
			'Chat Logs',
			'Chat Logs',
			'manage_options',
			'flosc-chat-logs',
			array( $this, 'redirect_to_chat_logs_tab' )
		);

		// Administration (global account/debug controls).
		add_submenu_page(
			'flosc-settings',
			'Administration',
			'Administration',
			'manage_options',
			'flosc-administration',
			array( $this, 'redirect_to_administration_tab' )
		);

		// Docs.
		add_submenu_page(
			'flosc-settings',
			'Docs',
			'📖 Docs',
			'manage_options',
			'flosc-docs',
			array( $this, 'redirect_to_docs_tab' )
		);

		// DA1 Catalog — standalone page (not flow-specific).
		add_submenu_page(
			'flosc-settings',
			'DA1 Catalog',
			'<b>DA1</b>',
			'manage_options',
			'flosc-da1',
			array( $this, 'redirect_to_da1_tab' )
		);

		// Starter Packs — global screen directly beneath DA1.
		add_submenu_page(
			'flosc-settings',
			'Starter Packs',
			'Starter Packs',
			'manage_options',
			'flosc-starter-packs',
			array( $this, 'redirect_to_starter_packs_tab' )
		);
	}

	/**
	 * Register Settings
	 */
	public function register_settings() {
		// Pass 2: every option has an explicit sanitizer type (no bare-name → implicit text).
		$this->register_settings_group(
			array(
				'flosc_app_slug'                     => 'text',
				'flosc_custom_domain'                => 'text',
				'flosc_product_name'                 => 'text',
				'flosc_product_title'                => 'text',
				'flosc_product_tagline'              => 'text',
				'flosc_share_text'                   => 'text',
				'flosc_email_subject'                => 'text',
				'flosc_email_body'                   => 'textarea',
				'flosc_ai_provider'                  => 'text',
				'flosc_openai_api_key'               => 'secret',
				'flosc_anthropic_api_key'            => 'secret',
				'flosc_xai_api_key'                  => 'secret',
				'flosc_gemini_api_key'               => 'secret',
				'flosc_ai_openai_model'              => 'text',
				'flosc_ai_anthropic_model'           => 'text',
				'flosc_ai_xai_model'                 => 'text',
				'flosc_ai_gemini_model'              => 'text',
				'flosc_ai_temperature'               => 'text',
				'flosc_ai_max_tokens'                => 'text',
				'flosc_stt_provider'                 => 'text',
				'flosc_assemblyai_api_key'           => 'secret',
				'flosc_custom_stt_endpoint'          => 'url',
				'flosc_buddyboss_group_id'           => 'text',
				'flosc_content_item_category'        => 'text',
				'flosc_oto_offer_id'                 => 'text',
				'flosc_free_content_item_mode'       => 'text',
				'flosc_free_content_item_count'      => 'text',
				'flosc_free_content_item_proportion' => 'text',
				'flosc_guest_access_days'            => 'text',
				'flosc_stripe_enabled'               => 'bool',
				'flosc_stripe_mode'                  => 'text',
				'flosc_stripe_test_pk'               => 'text',
				'flosc_stripe_test_sk'               => 'secret',
				'flosc_stripe_live_pk'               => 'text',
				'flosc_stripe_live_sk'               => 'secret',
				'flosc_clickbank_enabled'            => 'bool',
				'flosc_clickbank_mode'               => 'text',
				'flosc_clickbank_vendor'             => 'text',
				'flosc_clickbank_secret'             => 'secret',
				'flosc_clickbank_product'            => 'text',
				'flosc_clickbank_offer_id'           => 'text',
				'flosc_clickbank_access_level'       => 'text',
				'flosc_paypal_mode'                  => 'text',
				'flosc_paypal_client_id'             => 'text',
				'flosc_paypal_secret'                => 'secret',
				'flosc_paypal_webhook_id'            => 'text',
				'flosc_chat_style_preset'            => 'text',
				'flosc_chat_style_bubble'            => 'text',
				'flosc_chat_style_font'              => 'text',
			)
		);

		$this->register_settings_group(
			array(
				'flosc_product_logo'                => 'url',
				'flosc_primary_color'               => 'hex',
				'flosc_login_destination'           => 'url',
				'flosc_profile_bar'                 => 'array',
				'flosc_visitor_menu_items'          => 'array',
				'flosc_guest_menu_items'            => 'array',
				'flosc_member_menu_items'           => 'array',
				'flosc_debug_mode'                  => 'bool',
				'flosc_enabled_quizzes'             => 'array',
				'flosc_wpq_integration'             => 'bool',
				'flosc_ld_integration'              => 'bool',
				'flosc_qsm_integration'             => 'bool',
				'flosc_chat_style_scale'            => 'text',
				'flosc_chat_style_accent'           => 'hex',
				'flosc_sso_google_enabled'          => 'bool',
				'flosc_sso_google_client_id'        => 'text',
				'flosc_sso_google_client_secret'    => 'secret',
				'flosc_sso_apple_enabled'           => 'bool',
				'flosc_sso_apple_client_id'         => 'text',
				'flosc_sso_apple_client_secret'     => 'secret',
				'flosc_sso_facebook_enabled'        => 'bool',
				'flosc_sso_facebook_client_id'      => 'text',
				'flosc_sso_facebook_client_secret'  => 'secret',
				'flosc_sso_microsoft_enabled'       => 'bool',
				'flosc_sso_microsoft_client_id'     => 'text',
				'flosc_sso_microsoft_client_secret' => 'secret',
				'flosc_sso_linkedin_enabled'        => 'bool',
				'flosc_sso_linkedin_client_id'      => 'text',
				'flosc_sso_linkedin_client_secret'  => 'secret',
				'flosc_sso_apple_team_id'           => 'text',
				'flosc_sso_apple_key_id'            => 'text',
				// PEM: pass-through secret sanitizer (not sanitize_textarea_field — Jul email / Pass 2).
				'flosc_sso_apple_private_key'       => 'secret',
				'flosc_ai_base_prompt'              => 'textarea',
				'flosc_ai_personality_name'         => 'textarea',
				'flosc_ai_personality_role'         => 'textarea',
				'flosc_ai_personality_traits'       => 'textarea',
				'flosc_ai_mission'                  => 'textarea',
				'flosc_ai_boundaries'               => 'textarea',
				'flosc_ai_context_awareness'        => 'textarea',
				'flosc_ai_freeline_restrictions'    => 'textarea',
				'flosc_ai_member_access'            => 'textarea',
				// Global communication-token economics (integer/rational, saved by Payments tab).
				'flosc_tokens_communication_tokens_per_message' => 'text',
				'flosc_tokens_nominal_millicents_per_token_numerator' => 'text',
				'flosc_tokens_nominal_millicents_per_token_denominator' => 'text',
				'flosc_tokens_real_millicents_per_token_numerator' => 'text',
				'flosc_tokens_real_millicents_per_token_denominator' => 'text',
			)
		);

		// User Profile Bar (v1.8.0: unified 3-state bar replaces v1.7.8 visitor-only settings).

		// v1.8.0: UI & Navigation.

		// v1.7.7: Removed duplicate AI settings registration (was under both flosc_settings and flosc_ai_settings)
		// All settings now live under flosc_settings only.

		// STT Provider.

		// Quiz Type System.

		// Third-party quiz plugin integrations (v9.3.4).

		// Register quiz content settings for each quiz type dynamically.
		$quiz_types = FLOSC_Quiz_Registry::get_all_quizzes();
		foreach ( $quiz_types as $quiz_id => $quiz_type ) {
			$this->register_setting_value( 'flosc_quiz_content_' . $quiz_id, 'textarea' );

			$settings_fields = $quiz_type->get_settings_fields();
			foreach ( $settings_fields as $field_key => $field_config ) {
				$option_name = 'flosc_quiz_' . $quiz_id . '_' . $field_key;
				$field_type  = $field_config['type'] ?? 'text';

				if ( 'select' === $field_type ) {
					$this->register_select_setting_value(
						$option_name,
						array_keys( $field_config['options'] ?? array() )
					);
					continue;
				}

				if ( 'checkbox' === $field_type ) {
					$field_type = 'bool';
				}
				// Pass 2: map password/secret field types to secret pass-through sanitizer.
				if ( 'password' === $field_type || 'secret' === $field_type ) {
					$field_type = 'secret';
				}

				$this->register_setting_value( $option_name, $field_type );
			}

			$templates = $quiz_type->get_default_response_templates();
			foreach ( array_keys( $templates ) as $template_key ) {
				$this->register_setting_value( 'flosc_quiz_' . $quiz_id . '_template_' . $template_key, 'textarea' );
			}
		}

		// v1.7.7: Removed auto-seeded PayPal sandbox credentials (security)
		// PayPal credentials must be configured via Settings > FLOSC > PayPal.
	}

	/**
	 * Register one or more settings with a shared sanitizer.
	 *
	 * @param array $settings List of setting names or name => sanitizer type pairs.
	 */
	private function register_settings_group( $settings ) {
		foreach ( $settings as $key => $value ) {
			if ( is_int( $key ) ) {
				$this->register_setting_value( $value, 'text' );
			} else {
				$this->register_setting_value( $key, $value );
			}
		}
	}

	/**
	 * Register a single setting with the appropriate sanitizer.
	 *
	 * @param string $option_name Setting name.
	 * @param string $sanitize_type text, textarea, url, hex, bool, checkbox (alias), or array.
	 *                              Select fields should use register_select_setting_value().
	 */
	private function register_setting_value( $option_name, $sanitize_type = 'text' ) {
		switch ( $sanitize_type ) {
			case 'textarea':
				$sanitize_callback = array( $this, 'sanitize_textarea_setting' );
				break;
			case 'url':
				$sanitize_callback = array( $this, 'sanitize_url_setting' );
				break;
			case 'hex':
				$sanitize_callback = array( $this, 'sanitize_hex_setting' );
				break;
			case 'bool':
			case 'checkbox':
				$sanitize_callback = array( $this, 'sanitize_bool_setting' );
				break;
			case 'array':
				$sanitize_callback = array( $this, 'sanitize_array_setting' );
				break;
			case 'secret':
				// Named public callback (Pass 3): empty-preserve via current_filter option name.
				$sanitize_callback = array( $this, 'sanitize_secret_setting' );
				break;
			default:
				$sanitize_callback = array( $this, 'sanitize_text_setting' );
				break;
		}

		register_setting(
			'flosc_settings',
			$option_name,
			array(
				'type'              => $this->get_setting_registration_type( $sanitize_type ),
				'sanitize_callback' => $sanitize_callback,
				'default'           => $this->get_setting_default_value( $sanitize_type ),
			)
		);
	}

	/**
	 * Register a select setting with whitelist validation.
	 *
	 * @param string $option_name Setting name.
	 * @param array  $allowed_keys Allowed option keys from get_settings_fields()['options'].
	 */
	private function register_select_setting_value( $option_name, $allowed_keys ) {
		$allowed_keys  = array_values( array_filter( array_map( 'sanitize_key', (array) $allowed_keys ) ) );
		$default_value = $allowed_keys[0] ?? '';

		register_setting(
			'flosc_settings',
			$option_name,
			array(
				'type'              => 'string',
				'sanitize_callback' => function ( $value ) use ( $allowed_keys, $default_value ) {
					if ( empty( $allowed_keys ) ) {
						return '';
					}

					$sanitized = sanitize_key( wp_unslash( (string) $value ) );
					if ( '' !== $sanitized && in_array( $sanitized, $allowed_keys, true ) ) {
						return $sanitized;
					}

					return $default_value;
				},
				'default'           => $default_value,
			)
		);
	}

	/**
	 * Map sanitizer type to register_setting type metadata.
	 *
	 * @param string $sanitize_type Sanitizer category.
	 * @return string
	 */
	private function get_setting_registration_type( $sanitize_type ) {
		if ( 'array' === $sanitize_type ) {
			return 'array';
		}

		if ( 'bool' === $sanitize_type ) {
			return 'integer';
		}

		return 'string';
	}

	/**
	 * Default values aligned to sanitizer type.
	 *
	 * @param string $sanitize_type Sanitizer category.
	 * @return mixed
	 */
	private function get_setting_default_value( $sanitize_type ) {
		if ( 'array' === $sanitize_type ) {
			return array();
		}

		if ( 'bool' === $sanitize_type ) {
			return 0;
		}

		return '';
	}

	/**
	 * Sanitize a text setting.
	 *
	 * MUST stay public: registered as a register_setting() sanitize_callback,
	 * which WordPress core invokes from outside this class via the
	 * sanitize_option_{$option} filter. A private method here fatals
	 * ("Call to private method") on every settings save. The same applies to
	 * the five sibling sanitizers below — do not narrow their visibility.
	 *
	 * @param mixed $value Raw value.
	 * @return string|array
	 */
	public function sanitize_text_setting( $value ) {
		if ( is_array( $value ) ) {
			return array_map( array( $this, 'sanitize_text_setting' ), $value );
		}

		return sanitize_text_field( wp_unslash( (string) $value ) );
	}

	/**
	 * Pass-through for API keys and payment secrets (do not use sanitize_text_field).
	 *
	 * Empty string on save keeps the stored option (password fields submit empty when
	 * unchanged). To clear a secret deliberately, operators must use a dedicated clear
	 * action or overwrite with a new non-empty value — blank resave is not a wipe.
	 *
	 * Resolves the option name from sanitize_option_{$option} when registered as a
	 * named register_setting sanitize_callback (Pass 3).
	 *
	 * @param mixed $value Raw value.
	 * @return string
	 */
	public function sanitize_secret_setting( $value ) {
		$option_name = '';
		$filter      = current_filter();
		if ( is_string( $filter ) && 0 === strpos( $filter, 'sanitize_option_' ) ) {
			$option_name = substr( $filter, strlen( 'sanitize_option_' ) );
		}

		if ( ! is_string( $value ) ) {
			return '' !== $option_name ? (string) get_option( $option_name, '' ) : '';
		}

		if ( '' === $value ) {
			return '' !== $option_name ? (string) get_option( $option_name, '' ) : '';
		}

		return $value;
	}

	/**
	 * Sanitize a textarea setting.
	 *
	 * @param mixed $value Raw value.
	 * @return string|array
	 */
	public function sanitize_textarea_setting( $value ) {
		if ( is_array( $value ) ) {
			return array_map( array( $this, 'sanitize_textarea_setting' ), $value );
		}

		return sanitize_textarea_field( wp_unslash( (string) $value ) );
	}

	/**
	 * Sanitize a URL setting.
	 *
	 * @param mixed $value Raw value.
	 * @return string|array
	 */
	public function sanitize_url_setting( $value ) {
		if ( is_array( $value ) ) {
			return array_map( array( $this, 'sanitize_url_setting' ), $value );
		}

		return esc_url_raw( wp_unslash( (string) $value ) );
	}

	/**
	 * Sanitize a hex color setting.
	 *
	 * @param mixed $value Raw value.
	 * @return string
	 */
	public function sanitize_hex_setting( $value ) {
		$sanitized = sanitize_hex_color( wp_unslash( (string) $value ) );
		return $sanitized ? $sanitized : '';
	}

	/**
	 * Sanitize a boolean setting.
	 *
	 * @param mixed $value Raw value.
	 * @return int
	 */
	public function sanitize_bool_setting( $value ) {
		return ! empty( $value ) ? 1 : 0;
	}

	/**
	 * Sanitize nested array settings.
	 *
	 * @param mixed $value Raw value.
	 * @return array|string
	 */
	public function sanitize_array_setting( $value ) {
		if ( ! is_array( $value ) ) {
			return sanitize_text_field( wp_unslash( (string) $value ) );
		}

		$sanitized = array();
		foreach ( $value as $key => $item ) {
			$sanitized_key               = is_string( $key ) ? sanitize_key( $key ) : $key;
			$sanitized[ $sanitized_key ] = is_array( $item )
				? $this->sanitize_array_setting( $item )
				: sanitize_text_field( wp_unslash( (string) $item ) );
		}

		return $sanitized;
	}

	/**
	 * Render Admin Pages
	 */
	public function render_admin_page() {
		// Site admins always have FLOSC settings access.
		if ( ! current_user_can( 'manage_options' ) ) {
			// Delegated floscEditors must be Editor+ and assigned to at least one flow.
			if ( ! current_user_can( 'edit_others_posts' ) ) {
				wp_die( esc_html__( 'You do not have permission to access FLOSC settings.', 'flosc' ) );
			}

			$flosc_user_flows = flosc_flows()->get_user_flows( get_current_user_id() );
			if ( empty( $flosc_user_flows ) ) {
				wp_die( esc_html__( 'You do not have FLOSC flow assignments yet. Ask a site admin to assign you in Administration for a flow.', 'flosc' ) );
			}
		}

		include FLOSC_PLUGIN_DIR . 'admin/settings.php';
	}

	/**
	 * Check whether current user can manage chat logs for a specific flow.
	 * Site admins are always allowed; delegated floscEditors require flow assignment.
	 *
	 * @param string $flow_id Flow stem (for example flow_ivr).
	 * @return bool
	 */
	private function can_manage_flow_chat_logs( $flow_id ) {
		if ( current_user_can( 'manage_options' ) ) {
			return true;
		}

		if ( ! current_user_can( 'edit_others_posts' ) ) {
			return false;
		}

		$flow_id = sanitize_key( (string) $flow_id );
		if ( '' === $flow_id ) {
			return false;
		}

		return flosc_flows()->can_access_flow_admin( $flow_id, get_current_user_id() );
	}

	/**
	 * Render Flows list page
	 *
	 * @since 1.2.2
	 */
	public function render_flows_page() {
		include FLOSC_PLUGIN_DIR . 'admin/flows.php';
	}

	/**
	 * Render Flow edit page
	 *
	 * @since 1.2.2
	 */
	public function render_flow_edit_page() {
		include FLOSC_PLUGIN_DIR . 'admin/flow-edit.php';
	}

	/**
	 * Enqueue admin assets (TASK-006)
	 * Loads flosc-admin.css on FLOSC admin pages
	 *
	 * @since 1.0.4
	 *
	 * @param mixed $hook Hook.
	 */
	public function enqueue_admin_assets( $hook ) {
		// §12: Post-visibility metabox styles render on the post editor (post.php / post-new.php),
		// which is a different screen than the FLOSC settings pages. Enqueue them there via an
		// inline-only style handle. The metabox markup does not echo a style element.
		if ( 'post.php' === $hook || 'post-new.php' === $hook ) {
			wp_register_style( 'flosc-metabox', false, array(), FLOSC_VERSION );
			wp_enqueue_style( 'flosc-metabox' );
			wp_add_inline_style(
				'flosc-metabox',
				'.flosc-post-visibility-meta-box .flosc-description { color: #666; font-size: 12px; margin-top: 4px; }' .
				'.flosc-post-visibility-meta-box .flosc-protected-notice { background: #fff3cd; padding: 8px; border-radius: 4px; margin-bottom: 10px; font-size: 12px; }' .
				'.flosc-post-visibility-meta-box .flosc-protection-options label { display: block; margin: 6px 0; padding: 6px 8px; border-radius: 4px; cursor: pointer; }' .
				'.flosc-post-visibility-meta-box .flosc-protection-options label:hover { background: #f0f0f1; }' .
				'.flosc-post-visibility-meta-box .flosc-protection-options .option-desc { color: #666; font-size: 11px; display: block; margin-left: 22px; }'
			);
			// Concierge metabox rules ride the same handle. They must be added
			// HERE (admin_enqueue_scripts) and not inside render_meta_box():
			// by metabox render time the head styles have already printed, and
			// inline data attached to a printed handle is silently discarded.
			wp_add_inline_style(
				'flosc-metabox',
				'.flosc-cncrg-row { margin: 0 0 12px; }' .
				'.flosc-cncrg-row label { display: block; font-weight: 600; margin: 0 0 4px; }' .
				'.flosc-cncrg-row input, .flosc-cncrg-row textarea { width: 100%; font-family: ui-monospace, Menlo, Consolas, monospace; }' .
				'.flosc-cncrg-max-tries { width: 80px !important; }'
			);
			return;
		}

		// Only load on FLOSC admin pages
		// v1.2.8: Simplified - just check for 'flosc'.
		if ( false === strpos( $hook, 'flosc' ) &&
			'toplevel_page_flosc-settings' !== $hook ) {
			return;
		}

		$css_path = FLOSC_PLUGIN_DIR . 'assets/css/flosc-admin.css';
		if ( file_exists( $css_path ) ) {
			wp_enqueue_style(
				'flosc-admin',
				FLOSC_PLUGIN_URL . 'assets/css/flosc-admin.css',
				array(),
				filemtime( $css_path )
			);
		}

		// §12: Footer-printed script handle (no src) that FLOSC admin page templates
		// attach their page JS to via wp_add_inline_script('flosc-admin', ...).
		// Registering it here (on admin_enqueue_scripts)
		// means the handle is enqueued before render, so inline JS added during the page
		// body still prints in the admin footer. jQuery dep covers the existing jQuery use.
		wp_register_script( 'flosc-admin', false, array( 'jquery' ), FLOSC_VERSION, true );
		wp_enqueue_script( 'flosc-admin' );

		$flosc_admin_events_js_path = FLOSC_PLUGIN_DIR . 'assets/js/flosc-admin-events.js';
		if ( file_exists( $flosc_admin_events_js_path ) ) {
			wp_enqueue_script(
				'flosc-admin-events',
				FLOSC_PLUGIN_URL . 'assets/js/flosc-admin-events.js',
				array( 'flosc-admin' ),
				filemtime( $flosc_admin_events_js_path ),
				true
			);
		}

		// Which screen is being painted. Selection only -- nothing here writes.
		// 'view' is a closed set now; it used to accept any string the URL carried.
		$flosc_tab  = flosc_nav_param( 'tab' );
		$flosc_page = flosc_nav_param( 'page' );
		$flosc_view = flosc_nav_param( 'view', array( 'single', 'all' ) );
		if ( 'flosc-settings' === $flosc_page && 'ai' === $flosc_tab && 'all' !== $flosc_view ) {
			if ( function_exists( 'flosc_enqueue_personality_builder_assets' ) ) {
				flosc_enqueue_personality_builder_assets();
			}
		}

		// Dedicated AutoPrompts admin runtime (externalized from inline tab template JS).
		if ( 'autoprompts' === $flosc_tab ) {
			$flosc_autoprompts_js_path = FLOSC_PLUGIN_DIR . 'assets/js/flosc-autoprompts-admin.js';
			if ( file_exists( $flosc_autoprompts_js_path ) ) {
				wp_enqueue_script(
					'flosc-autoprompts-admin',
					FLOSC_PLUGIN_URL . 'assets/js/flosc-autoprompts-admin.js',
					array( 'flosc-admin' ),
					filemtime( $flosc_autoprompts_js_path ),
					true
				);
			}
		}

		/*
		 * Flow Portability kit drop zone: dedicated stylesheet (the whole zone,
		 * staged-file panel and action row) plus its vanilla-JS staging script.
		 * These two files are the only owners of that UI, and this enqueue is the
		 * only place they are delivered — admin/flow.php prints no asset tags.
		 *
		 * The zone markup only renders on the "all" view of the Flow tab, so the
		 * view is read here and the assets are skipped on the single-flow view.
		 */
		$flosc_view = flosc_nav_param( 'view', array( 'single', 'all' ) );

		if ( 'flow' === $flosc_tab && 'all' === $flosc_view ) {
			$flosc_port_css = FLOSC_PLUGIN_DIR . 'assets/css/flosc-portability-admin.css';
			$flosc_port_js  = FLOSC_PLUGIN_DIR . 'assets/js/flosc-portability-admin.js';
			if ( file_exists( $flosc_port_css ) ) {
				wp_enqueue_style(
					'flosc-portability-admin',
					FLOSC_PLUGIN_URL . 'assets/css/flosc-portability-admin.css',
					array( 'flosc-admin' ),
					(string) filemtime( $flosc_port_css )
				);
			}
			if ( file_exists( $flosc_port_js ) ) {
				wp_enqueue_script(
					'flosc-portability-admin',
					FLOSC_PLUGIN_URL . 'assets/js/flosc-portability-admin.js',
					array(),
					(string) filemtime( $flosc_port_js ),
					true
				);
			}
		}

		if ( 'email' === $flosc_tab ) {
			$flosc_email_css_path = FLOSC_PLUGIN_DIR . 'assets/css/flosc-email.css';
			if ( file_exists( $flosc_email_css_path ) ) {
				wp_enqueue_style(
					'flosc-email',
					FLOSC_PLUGIN_URL . 'assets/css/flosc-email.css',
					array( 'flosc-admin' ),
					filemtime( $flosc_email_css_path )
				);
			}
		}

		// Debug mode badge.
		if ( defined( 'FLOSC_DEBUG' ) && FLOSC_DEBUG ) {
			wp_add_inline_style(
				'flosc-admin',
				'
                body.wp-admin:after {
                    content: "FLOSC DEBUG";
                    position: fixed;
                    bottom: 10px;
                    right: 10px;
                    background: #dc3545;
                    color: #fff;
                    padding: 5px 10px;
                    border-radius: 4px;
                    font-size: 11px;
                    font-weight: bold;
                    z-index: 9999;
                    opacity: 0.8;
                }
            '
			);
		}

		// Tame WordPress admin footer (#wpfooter) on FLOSC pages.
		// WP core uses position:fixed/absolute which causes the "Version X.X.X" text
		// to float over FLOSC admin content at various zoom levels.
		// Fix: make it flow normally in the document, properly positioned at the bottom.
		wp_add_inline_style(
			'flosc-admin',
			'
            #wpfooter { position: static; padding: 15px 20px; text-align: right; }
        '
		);
	}

	/**
	 * Relabel right side of WP admin footer on FLOSC pages.
	 * WordPress shows "Version 6.9.3" — we relabel to "WordPress 6.9.3 | FLOSC v8.0.0"
	 * so it's clear what each version number refers to.
	 * Only applies on FLOSC admin pages (checked via current screen).
	 *
	 * @since 8.0.0
	 *
	 * @param mixed $text Text.
	 */
	public function relabel_admin_footer( $text ) {
		$screen = get_current_screen();
		if ( $screen && false !== strpos( $screen->id, 'flosc' ) ) {
			global $wp_version;
			return 'WordPress ' . esc_html( $wp_version ) . ' | FLOSC v' . esc_html( FLOSC_VERSION );
		}
		return $text;
	}

	/**
	 * Replace left-side "Thank you for creating with WordPress" with FLOSC branding
	 * on FLOSC admin pages only.
	 *
	 * @since 8.0.0
	 *
	 * @param mixed $text Text.
	 */
	public function relabel_admin_footer_left( $text ) {
		$screen = get_current_screen();
		if ( $screen && false !== strpos( $screen->id, 'flosc' ) ) {
			return '<span id="footer-thankyou">FLOSC &mdash; Flow-Oriented Sales Companion</span>';
		}
		return $text;
	}

	// Offers now integrated into main settings page.

	// Payments now integrated into main settings page.

	// AI Config now integrated into main settings page.

	// AI Knowledge now integrated into main settings page.

	// Chat Style now integrated into main settings page.

	/**
	 * Early admin_init redirects for FLOSC sidebar shortcuts.
	 * Menu callbacks run after admin chrome starts; if headers are already sent,
	 * wp_safe_redirect is a no-op and exit leaves a blank content pane
	 * (seen on UI & Nav → page=flosc-ui-navigation).
	 */
	public function maybe_redirect_flosc_admin_shortcuts() {
		if ( ! is_admin() || wp_doing_ajax() || ( defined( 'DOING_CRON' ) && DOING_CRON ) ) {
			return;
		}

		// Read-only admin menu routing, capability-checked below. The comment that
		// stood here claimed filter_input was used to avoid PHPCS noise; the code
		// read $_GET directly and the warning was reported anyway.
		$page = flosc_nav_param( 'page' );
		if ( '' === $page || 'flosc-settings' === $page ) {
			return;
		}

		$map = array(
			'flosc-flow'             => 'flow',
			'flosc-identity'         => 'identity',
			'flosc-ivr-messages'     => 'ivr-messages',
			'flosc-autoprompts'      => 'autoprompts',
			'flosc-content'          => 'content',
			'flosc-member-levels'    => 'content',
			'flosc-lessons'          => 'content',
			'flosc-knowledge-base'   => 'knowledge-base',
			'flosc-trajectories'     => 'trajectories',
			'flosc-offers'           => 'offers',
			'flosc-login'            => 'login',
			'flosc-chat-style'       => 'style',
			'flosc-ui-navigation'    => 'ui',
			'flosc-ai-config'        => 'ai',
			'flosc-token-management' => 'token-management',
			'flosc-concierge'        => 'concierge',
			'flosc-quiz'             => 'quiz',
			'flosc-email'            => 'email',
			'flosc-contact-form'     => 'contact-form',
			'flosc-payments'         => 'payments',
			'flosc-sso'              => 'sso',
			'flosc-engagement'       => 'engagement',
			'flosc-chat-logs'        => 'chat-logs',
			'flosc-administration'   => 'administration',
			'flosc-documentation'    => 'documentation',
			'flosc-docs'             => 'documentation',
			'flosc-da1'              => 'da1',
			'flosc-starter-packs'    => 'starter-packs',
		);

		if ( ! isset( $map[ $page ] ) ) {
			return;
		}

		// Same gate as Settings shell (site admin or delegated editor).
		if ( ! current_user_can( 'manage_options' ) && ! current_user_can( 'edit_others_posts' ) ) {
			return;
		}

		$tab  = $map[ $page ];
		$args = array(
			'page' => 'flosc-settings',
			'tab'  => $tab,
		);
		$ivr  = flosc_nav_param( 'ivr', array(), '', 'sanitize_file_name' );
		if ( '' !== $ivr ) {
			$args['ivr'] = $ivr;
		}
		$view = flosc_nav_param( 'view', array( 'single', 'all' ) );
		if ( '' !== $view ) {
			$args['view'] = $view;
		}

		wp_safe_redirect( add_query_arg( $args, admin_url( 'admin.php' ) ) );
		exit;
	}

	/**
	 * Process FLOSC Settings form POSTs that redirect (Save, trajectory, concierge).
	 * Must run on admin_init — render_admin_page already has headers sent.
	 */
	public function maybe_process_flosc_settings_post() {
		if ( ! is_admin() || wp_doing_ajax() || ( defined( 'DOING_CRON' ) && DOING_CRON ) ) {
			return;
		}

		// Which admin screen this is. Selection only; the POST body below is what
		// carries intent, and each handler verifies its own nonce before writing.
		if ( 'flosc-settings' !== flosc_nav_param( 'page' ) ) {
			return;
		}

		/*
		 * Capability first, then the body.
		 *
		 * Every individual handler below verifies its own nonce, and that is
		 * still true -- but nothing established WHO was asking before the POST
		 * body was unslashed and dispatched on. On a page that stores
		 * administrative settings, the identity check belongs before the parse,
		 * not distributed among the things the parse leads to. This is the same
		 * capability the FLOSC menu itself requires.
		 */
		if ( ! current_user_can( 'edit_others_posts' ) ) {
			return;
		}

		/*
		 * Origin, at dispatch, before the body is read.
		 *
		 * Every handler this function routes to verifies its own nonce, and that
		 * was the whole defence: nothing in here proved the request came from
		 * this site until control had already reached a handler. On a screen
		 * that stores administrative settings that is the wrong place for it.
		 *
		 * Each route is now declared with the nonce action and field its own
		 * form prints, and the match is verified here. The handlers still verify
		 * again -- check_admin_referer() is idempotent and defence in depth on a
		 * settings writer is worth the microsecond.
		 */
		$flosc_routes = array(
			// POST key                      => array( nonce action, nonce field ).
			'flosc_upload_ivr_file'         => array( 'flosc_upload_ivr_file', '_wpnonce' ),
			'flosc_portability_submit'      => array( 'flosc_portability_kit', '_wpnonce' ),
			'flosc_portability_pack_action' => array( 'flosc_portability_pack', '_wpnonce' ),
			'flosc_save'                    => array( 'flosc_save_settings', '_wpnonce' ),
			'flosc_toggle_trajectory_post'  => array( 'flosc_toggle_trajectory_post', 'flosc_toggle_trajectory_nonce' ),
			'flosc_create_concierge_post'   => array( 'flosc_create_concierge_post', 'flosc_concierge_create_nonce' ),
			'flosc_create_trajectory_post'  => array( 'flosc_create_trajectory_post', 'flosc_trajectory_create_nonce' ),
		);

		$flosc_route = '';
		foreach ( $flosc_routes as $flosc_key => $flosc_spec ) {
			if ( ! empty( $_POST[ $flosc_key ] ) ) {
				$flosc_route = $flosc_key;
				break;
			}
		}
		if ( '' === $flosc_route ) {
			return;
		}

		// Ends the request on a bad or missing nonce. Nothing below runs unless
		// this passes, so every $_POST read after it is verified input.
		check_admin_referer( $flosc_routes[ $flosc_route ][0], $flosc_routes[ $flosc_route ][1] );

		// IVR new-flow upload: must redirect before admin chrome (Set-as-default class of bug).
		if ( 'flosc_upload_ivr_file' === $flosc_route && ! empty( $_FILES['ivr_file_upload'] ) ) {
			if ( ! function_exists( 'flosc_admin_handle_ivr_file_upload' ) ) {
				require_once FLOSC_PLUGIN_DIR . 'admin/ivr-upload-handler.php';
			}
			flosc_admin_handle_ivr_file_upload();
			// Success exits inside handler. Failure: continue so the settings page can show errors.
			return;
		}

		/*
		 * Flow Portability kit drop zone (Create new flow / Apply to current flow).
		 * Same reason as the upload above: the handler ends a successful run with
		 * wp_safe_redirect(), so it has to run here rather than from the Flow
		 * template, where headers are already sent.
		 *
		 * The clicked button carries the intent, so the button value alone decides
		 * the route. Also requiring $_FILES would let a drop that arrived without
		 * its files -- an oversized post, or a submission with nothing staged --
		 * fall straight through to a silent page reload, instead of reaching the
		 * handler and being named.
		 */
		if ( 'flosc_portability_submit' === $flosc_route ) {
			$kit_action = '';
			if ( isset( $_POST['flosc_portability_submit'] ) && is_string( $_POST['flosc_portability_submit'] ) ) {
				$kit_action = sanitize_key( wp_unslash( $_POST['flosc_portability_submit'] ) );
			}
			if ( in_array( $kit_action, array( 'create', 'apply' ), true ) ) {
				if ( ! function_exists( 'flosc_admin_handle_ivr_file_upload' ) ) {
					require_once FLOSC_PLUGIN_DIR . 'admin/ivr-upload-handler.php';
				}
				flosc_admin_handle_ivr_file_upload();
				// Success exits inside handler. Failure: continue so the settings page can show errors.
				return;
			}
			return;
		}

		// Pack list actions (import staged WXR, remove WXR, unlink media).
		if ( 'flosc_portability_pack_action' === $flosc_route ) {
			if ( ! function_exists( 'flosc_admin_handle_portability_pack_actions' ) ) {
				require_once FLOSC_PLUGIN_DIR . 'admin/ivr-upload-handler.php';
			}
			flosc_admin_handle_portability_pack_actions();
			return;
		}

		if ( ! empty( $GLOBALS['flosc_settings_early_post_running'] ) ) {
			return;
		}
		$GLOBALS['flosc_settings_early_post_running'] = true;

		// settings.php POST handlers call wp_safe_redirect + exit on success.
		// On failure they fall through; we return before any HTML is printed.
		include FLOSC_PLUGIN_DIR . 'admin/settings.php';

		$GLOBALS['flosc_settings_early_post_running'] = false;
	}

	/**
	 * Serve an IVR file as a download, before any admin HTML is printed.
	 *
	 * WHY THIS IS NOT IN THE TAB TEMPLATE ANY MORE
	 *
	 * admin/flow.php used to do this itself. It cannot. That file is a settings
	 * tab, included while the admin page is already streaming, so by the time it
	 * runs the response headers are gone. Content-Type and Content-Disposition
	 * were discarded and the file's bytes were written into the middle of the
	 * page: the browser received the admin screen with an IVR file spliced into
	 * it, at HTTP 200, and no download ever started.
	 *
	 * Nothing reported it. php -l, 44 gates, WPCS and Plugin Check were all
	 * clean, because none of them renders a page. It was found by clicking
	 * Download on a real WordPress install and reading the bytes that came back.
	 *
	 * flow.php already carried the warning that explains it, about the
	 * set-as-default handler: "Do not redirect here -- headers are already sent
	 * during page render". The same constraint applies to any response that
	 * replaces the page, and a download is one of those.
	 *
	 * admin_init runs before output, which is the only place this can work. The
	 * checks are unchanged in kind and order: the nonce is verified against the
	 * action that names this exact file, then the capability, then the path.
	 *
	 * @return void
	 */
	/**
	 * Offer delete, toggle and status-set, before any HTML is printed.
	 *
	 * These three ran at file scope in admin/offers.php, which is included
	 * while the settings page is already streaming. Their refusals called
	 * wp_die() with 'response' => 403, and PHP cannot send a status header
	 * after output has started -- so a request with a bad nonce was correctly
	 * refused, wrote nothing, and answered HTTP 200 with the error spliced
	 * into a half-rendered page. Anything reading that endpoint saw success.
	 *
	 * Running on admin_init, before output, lets those same wp_die() calls
	 * send the 403 they always asked for. A successful action redirects back
	 * to the tab, which also drops the action out of the URL so a refresh
	 * cannot replay it.
	 *
	 * @return void
	 */
	public function maybe_process_offer_actions() {
		if ( ! is_admin() || wp_doing_ajax() || ( defined( 'DOING_CRON' ) && DOING_CRON ) ) {
			return;
		}
		if ( 'flosc-settings' !== flosc_nav_param( 'page' ) || 'offers' !== flosc_nav_param( 'tab' ) ) {
			return;
		}

		/*
		 * Which action this is. Read through flosc_nav_param(), the same
		 * accessor the rest of the admin uses for request values, so the
		 * selection needs no suppression to sit ahead of the nonce check --
		 * and it cannot carry anything but a sanitized string either way.
		 */
		$flosc_action = '';
		$flosc_target = '';
		foreach ( array( 'delete_offer', 'toggle_status', 'set_status' ) as $flosc_candidate ) {
			$flosc_value = flosc_nav_param( $flosc_candidate, array(), '', 'sanitize_text_field' );
			if ( '' !== $flosc_value ) {
				$flosc_action = $flosc_candidate;
				$flosc_target = $flosc_value;
				break;
			}
		}
		if ( '' === $flosc_action ) {
			return;
		}

		// Who, then whether they meant to, before the request body is read.
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized action.', 'flosc' ), esc_html__( 'Insufficient permissions', 'flosc' ), array( 'response' => 403 ) );
		}

		$flosc_nonce = flosc_nav_param( '_wpnonce', array(), '', 'sanitize_text_field' );

		/*
		 * The requested status is read before the nonce because it is part of
		 * the action the nonce has to match. flosc_nav_param() constrains it to
		 * the three literals below, so nothing unvalidated reaches the action.
		 */
		$flosc_requested_status = 'set_status' === $flosc_action
			? flosc_nav_param( 'status', array( 'draft', 'inactive', 'active' ), '' )
			: '';

		$flosc_nonce_action = flosc_offer_action_nonce_action( $flosc_action, $flosc_target, $flosc_requested_status );

		if ( '' === $flosc_nonce_action || ! wp_verify_nonce( $flosc_nonce, $flosc_nonce_action ) ) {
			wp_die( esc_html__( 'Nonce verification failed.', 'flosc' ), esc_html__( 'Invalid token', 'flosc' ), array( 'response' => 403 ) );
		}

		// Verified input from here down.
		$flosc_ivr = flosc_nav_param( 'ivr', array(), '', 'sanitize_file_name' );
		if ( '' === $flosc_ivr || ! function_exists( 'flosc_resolve_flow_option_key_for_ivr' ) ) {
			return;
		}
		$flosc_flow_key = flosc_resolve_flow_option_key_for_ivr( $flosc_ivr );
		if ( '' === $flosc_flow_key ) {
			return;
		}

		$flosc_settings = get_option( $flosc_flow_key, array() );
		if ( ! is_array( $flosc_settings ) ) {
			$flosc_settings = array();
		}
		$flosc_offers = isset( $flosc_settings['offers'] ) && is_array( $flosc_settings['offers'] ) ? $flosc_settings['offers'] : array();
		$flosc_notice = '';

		if ( 'delete_offer' === $flosc_action ) {
			unset( $flosc_offers[ $flosc_target ] );
			$flosc_notice = 'offer_deleted';
		} elseif ( 'toggle_status' === $flosc_action && isset( $flosc_offers[ $flosc_target ] ) ) {
			$flosc_status = strtolower( (string) ( $flosc_offers[ $flosc_target ]['status'] ?? 'active' ) );
			$flosc_on     = ! empty( $flosc_offers[ $flosc_target ]['active'] );
			// A draft becomes active; anything already active goes inactive.
			$flosc_next = ( 'draft' === $flosc_status || ! $flosc_on ) ? 'active' : 'inactive';

			$flosc_offers[ $flosc_target ]['status'] = $flosc_next;
			$flosc_offers[ $flosc_target ]['active'] = ( 'active' === $flosc_next );
		} elseif ( 'set_status' === $flosc_action && isset( $flosc_offers[ $flosc_target ] ) ) {
			$flosc_next = flosc_nav_param( 'status', array( 'draft', 'inactive', 'active' ), '' );
			if ( '' === $flosc_next ) {
				return;
			}
			$flosc_offers[ $flosc_target ]['status'] = $flosc_next;
			$flosc_offers[ $flosc_target ]['active'] = ( 'active' === $flosc_next );
		} else {
			return;
		}

		$flosc_settings['offers'] = $flosc_offers;
		update_option( $flosc_flow_key, $flosc_settings );

		$flosc_args = array(
			'page' => 'flosc-settings',
			'tab'  => 'offers',
			'ivr'  => $flosc_ivr,
		);
		if ( '' !== $flosc_notice ) {
			$flosc_args['flosc_notice'] = $flosc_notice;
		}
		wp_safe_redirect( add_query_arg( $flosc_args, admin_url( 'admin.php' ) ) );
		exit;
	}

	/**
	 * Serve a verified IVR download before the admin page emits output.
	 *
	 * @return void
	 */
	public function maybe_serve_ivr_file_download() {
		if ( ! is_admin() || wp_doing_ajax() || ( defined( 'DOING_CRON' ) && DOING_CRON ) ) {
			return;
		}
		if ( 'flosc-settings' !== flosc_nav_param( 'page' ) ) {
			return;
		}

		// sanitize_file_name, never sanitize_key: the latter eats the .md.
		$flosc_file = flosc_nav_param( 'flosc_download_ivr', array(), '', 'sanitize_file_name' );
		if ( '' === $flosc_file ) {
			return;
		}

		$flosc_nonce = flosc_nav_param( '_wpnonce' );
		if ( ! wp_verify_nonce( $flosc_nonce, 'flosc_download_ivr_' . $flosc_file ) ) {
			return; // flow.php reports "Could not download IVR file." when we decline.
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to download IVR files.', 'flosc' ), 403 );
		}

		$flosc_path = function_exists( 'flosc_resolve_ivr_file_path' )
			? (string) flosc_resolve_ivr_file_path( $flosc_file )
			: '';
		if ( '' === $flosc_path || ! file_exists( $flosc_path ) || ! is_readable( $flosc_path ) ) {
			return;
		}

		if ( ! function_exists( 'WP_Filesystem' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		global $wp_filesystem;
		WP_Filesystem();
		$flosc_body = is_object( $wp_filesystem ) ? $wp_filesystem->get_contents( $flosc_path ) : false;
		if ( false === $flosc_body ) {
			return;
		}

		if ( class_exists( 'FLOSC_Filesystem' ) ) {
			$flosc_fs = new FLOSC_Filesystem();
			$flosc_fs->stream_plain_download_and_exit(
				(string) $flosc_body,
				'text/markdown; charset=UTF-8',
				basename( $flosc_file )
			);
		}
	}

	/**
	 * Admin-post: set current user's default FLOSC flow (Settings chrome).
	 * Runs before any admin HTML so wp_safe_redirect works (not mid-render).
	 */
	public function handle_set_default_flow() {
		if ( ! is_user_logged_in() ) {
			wp_die( esc_html__( 'You must be logged in.', 'flosc' ) );
		}

		check_admin_referer( 'flosc_set_default_flow', 'flosc_default_flow_nonce' );

		// Each field is read on its own and sanitized at the read. A field sent
		// as an array is refused rather than cast to the word "Array".
		foreach ( array( 'ivr', 'tab', 'view' ) as $flosc_field ) {
			if ( isset( $_POST[ $flosc_field ] ) && ! is_string( $_POST[ $flosc_field ] ) ) {
				wp_die( esc_html__( 'Missing flow file.', 'flosc' ) );
			}
		}
		$ivr  = isset( $_POST['ivr'] ) ? sanitize_file_name( wp_unslash( (string) $_POST['ivr'] ) ) : '';
		$tab  = isset( $_POST['tab'] ) ? sanitize_text_field( wp_unslash( $_POST['tab'] ) ) : 'identity';
		$view = isset( $_POST['view'] ) ? sanitize_text_field( wp_unslash( $_POST['view'] ) ) : 'single';
		if ( ! in_array( $view, array( 'single', 'all' ), true ) ) {
			$view = 'single';
		}

		if ( '' === $ivr ) {
			wp_die( esc_html__( 'Missing flow file.', 'flosc' ) );
		}

		$flow_id = sanitize_key( pathinfo( $ivr, PATHINFO_FILENAME ) );
		if ( ! flosc_flows()->can_access_flow_admin( $flow_id ) ) {
			wp_die( esc_html__( 'You do not have permission to set a default FLOSC flow.', 'flosc' ) );
		}

		// Same key as admin/settings.php selector.
		update_user_meta( get_current_user_id(), '_flosc_admin_default_ivr', $ivr );

		$redirect = add_query_arg(
			array(
				'page'        => 'flosc-settings',
				'ivr'         => $ivr,
				'tab'         => $tab,
				'view'        => $view,
				'default_set' => '1',
			),
			admin_url( 'admin.php' )
		);

		wp_safe_redirect( $redirect );
		exit;
	}

	/**
	 * Remember the flow this floscAdmin selected for the current body of work.
	 *
	 * The default flow answers only the first visit. Once an administrator uses
	 * Switch Flow, sidebar shortcuts and global tabs return to this per-user
	 * working flow until another flow is selected.
	 *
	 * @return void
	 */
	public function handle_set_working_flow() {
		if ( ! is_user_logged_in() || ! current_user_can( 'edit_others_posts' ) ) {
			wp_die( esc_html__( 'You do not have permission to select a FLOSC flow.', 'flosc' ) );
		}

		check_admin_referer( 'flosc_set_working_flow', 'flosc_working_flow_nonce' );

		// Each field is read on its own and sanitized at the read. A field sent
		// as an array is refused rather than cast to the word "Array".
		foreach ( array( 'ivr', 'tab', 'view' ) as $flosc_field ) {
			if ( isset( $_POST[ $flosc_field ] ) && ! is_string( $_POST[ $flosc_field ] ) ) {
				wp_die( esc_html__( 'Missing flow selection.', 'flosc' ) );
			}
		}

		$ivr  = isset( $_POST['ivr'] ) ? sanitize_file_name( wp_unslash( (string) $_POST['ivr'] ) ) : '';
		$tab  = isset( $_POST['tab'] ) ? sanitize_key( wp_unslash( $_POST['tab'] ) ) : 'identity';
		$view = isset( $_POST['view'] ) ? sanitize_key( wp_unslash( $_POST['view'] ) ) : 'single';

		if ( '' === $ivr ) {
			wp_die( esc_html__( 'Missing flow selection.', 'flosc' ) );
		}

		$flow_id = sanitize_key( pathinfo( $ivr, PATHINFO_FILENAME ) );
		if ( ! flosc_flows()->can_access_flow_admin( $flow_id ) ) {
			wp_die( esc_html__( 'You do not have permission to select that FLOSC flow.', 'flosc' ) );
		}

		if ( ! in_array( $view, array( 'single', 'all' ), true ) ) {
			$view = 'single';
		}

		update_user_meta( get_current_user_id(), '_flosc_admin_working_ivr', $ivr );

		wp_safe_redirect(
			add_query_arg(
				array(
					'page' => 'flosc-settings',
					'ivr'  => $ivr,
					'tab'  => $tab,
					'view' => $view,
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	/**
	 * Redirect to a FLOSC Settings tab. Prefer HTTP redirect; if headers already
	 * sent, render the settings shell so the admin never gets a blank pane.
	 *
	 * @param string $tab Settings tab slug.
	 */
	private function redirect_to_settings_tab( $tab ) {
		$tab = sanitize_key( (string) $tab );
		if ( '' === $tab ) {
			$tab = 'flow';
		}

		$args = array(
			'page' => 'flosc-settings',
			'tab'  => $tab,
		);
		if ( ! empty( $GLOBALS['flosc_current_ivr'] ) ) {
			$args['ivr'] = sanitize_file_name( (string) $GLOBALS['flosc_current_ivr'] );
		}
		if ( ! empty( $GLOBALS['flosc_settings_view'] ) ) {
			$view = sanitize_key( (string) $GLOBALS['flosc_settings_view'] );
			if ( in_array( $view, array( 'single', 'all' ), true ) ) {
				$args['view'] = $view;
			}
		}

		$url = add_query_arg( $args, admin_url( 'admin.php' ) );
		if ( ! headers_sent() ) {
			wp_safe_redirect( $url );
			exit;
		}

		/*
		 * Fallback: paint Settings with the requested tab, no blank exit.
		 *
		 * This used to assign into $_GET to carry the tab down to settings.php.
		 * Mutating a superglobal to pass a parameter is what PHPCS was flagging,
		 * and it is worth flagging: anything reading $_GET after this point sees
		 * a value the browser never sent. settings.php consults this global the
		 * same way it already consults flosc_current_ivr and flosc_settings_view.
		 */
		$GLOBALS['flosc_forced_tab'] = $tab;
		$this->render_admin_page();
	}

	/**
	 * Redirect handlers for tab shortcuts - ALL menu items go to Settings tabs
	 */
	public function redirect_to_product_tab() {
		$this->redirect_to_settings_tab( 'product' );
	}

	/**
	 * Redirect to flow tab.
	 */
	public function redirect_to_flow_tab() {
		$this->redirect_to_settings_tab( 'flow' );
	}

	/**
	 * Redirect to identity tab.
	 */
	public function redirect_to_identity_tab() {
		$this->redirect_to_settings_tab( 'identity' );
	}

	/**
	 * Redirect to IVR tab.
	 */
	public function redirect_to_ivr_tab() {
		$this->redirect_to_settings_tab( 'ivr-messages' );
	}

	/**
	 * Redirect to autoprompts tab.
	 */
	public function redirect_to_autoprompts_tab() {
		$this->redirect_to_settings_tab( 'autoprompts' );
	}

	/**
	 * Redirect to content tab.
	 */
	public function redirect_to_content_tab() {
		$this->redirect_to_settings_tab( 'content' );
	}

	/**
	 * Redirect to knowledge base tab.
	 */
	public function redirect_to_knowledge_base_tab() {
		$this->redirect_to_settings_tab( 'knowledge-base' );
	}

	/**
	 * Redirect to member levels tab.
	 */
	public function redirect_to_member_levels_tab() {
		$this->redirect_to_content_tab();
	}

	/**
	 * Redirect to trajectories tab.
	 */
	public function redirect_to_trajectories_tab() {
		$this->redirect_to_settings_tab( 'trajectories' );
	}

	/**
	 * Redirect to style tab.
	 */
	public function redirect_to_style_tab() {
		$this->redirect_to_settings_tab( 'style' );
	}

	/**
	 * Redirect to AI tab.
	 */
	public function redirect_to_ai_tab() {
		$this->redirect_to_settings_tab( 'ai' );
	}

	/**
	 * Redirect to token management tab.
	 */
	public function redirect_to_token_management_tab() {
		$this->redirect_to_settings_tab( 'token-management' );
	}

	/**
	 * Redirect to concierge tab.
	 */
	public function redirect_to_concierge_tab() {
		$this->redirect_to_settings_tab( 'concierge' );
	}

	/**
	 * Redirect to quiz tab.
	 */
	public function redirect_to_quiz_tab() {
		$this->redirect_to_settings_tab( 'quiz' );
	}

	/**
	 * Redirect to email tab.
	 */
	public function redirect_to_email_tab() {
		$this->redirect_to_settings_tab( 'email' );
	}

	/**
	 * Redirect to contact form tab.
	 */
	public function redirect_to_contact_form_tab() {
		$this->redirect_to_settings_tab( 'contact-form' );
	}

	/**
	 * Redirect to AI knowledge tab.
	 */
	public function redirect_to_ai_knowledge_tab() {
		$this->redirect_to_settings_tab( 'ai' );
	}

	/**
	 * Redirect to login tab.
	 */
	public function redirect_to_login_tab() {
		$this->redirect_to_settings_tab( 'login' );
	}

	/**
	 * Redirect to offers tab.
	 */
	public function redirect_to_offers_tab() {
		$this->redirect_to_settings_tab( 'offers' );
	}

	/**
	 * Redirect to payments tab.
	 */
	public function redirect_to_payments_tab() {
		$this->redirect_to_settings_tab( 'payments' );
	}

	/**
	 * Redirect to lessons tab.
	 */
	public function redirect_to_lessons_tab() {
		$this->redirect_to_content_tab();
	}

	/**
	 * Redirect to SSO tab.
	 */
	public function redirect_to_sso_tab() {
		$this->redirect_to_settings_tab( 'sso' );
	}

	/**
	 * Redirect to engagement tab.
	 */
	public function redirect_to_engagement_tab() {
		$this->redirect_to_settings_tab( 'engagement' );
	}

	/**
	 * Redirect to administration tab.
	 */
	public function redirect_to_administration_tab() {
		$this->redirect_to_settings_tab( 'administration' );
	}

	/**
	 * Redirect to chat logs tab.
	 */
	public function redirect_to_chat_logs_tab() {
		$this->redirect_to_settings_tab( 'chat-logs' );
	}

	/**
	 * Redirect to docs tab.
	 */
	public function redirect_to_docs_tab() {
		$this->redirect_to_settings_tab( 'documentation' );
	}

	/**
	 * Redirect to DA1 tab.
	 */
	public function redirect_to_da1_tab() {
		$this->redirect_to_settings_tab( 'da1' );
	}

	/**
	 * Redirect to Starter Packs tab.
	 */
	public function redirect_to_starter_packs_tab() {
		$this->redirect_to_settings_tab( 'starter-packs' );
	}

	/**
	 * V1.8.0 → v1.8.2: UI & Navigation → Settings tab=ui (Profile Bar + chat menus).
	 * Early admin_init also maps flosc-ui-navigation; this is the menu callback fallback.
	 */
	public function render_ui_navigation_page() {
		$this->redirect_to_settings_tab( 'ui' );
	}

	/**
	 * Render DA1 page.
	 */
	public function render_da1_page() {
		echo '<div class="wrap">';
		include FLOSC_PLUGIN_DIR . 'admin/da1.php';
		echo '</div>';
	}

	/**
	 * Shortcode: [flosc_visitor_only]
	 * Shows content only to non-logged-in visitors
	 *
	 * @param mixed  $atts    Atts.
	 * @param string $content Content.
	 */
	public function shortcode_visitor_only( $atts, $content = '' ) {
		if ( ! is_user_logged_in() ) {
			return wp_kses_post( do_shortcode( $content ) );
		}
		return '';
	}

	/**
	 * Shortcode: [flosc_member_only]
	 * Shows content only to members (users with _flosc_member_access = true)
	 *
	 * Usage: [flosc_member_only fallback="Upgrade to unlock"]Content here[/flosc_member_only]
	 *
	 * @param array  $atts Shortcode attributes (fallback message).
	 * @param string $content Shortcode content.
	 * @return string
	 */
	public function shortcode_member_only( $atts, $content = '' ) {
		// Parse attributes.
		$atts = shortcode_atts(
			array(
				'fallback' => '', // Optional fallback message for non-members.
			),
			$atts
		);

		if ( ! is_user_logged_in() ) {
			return $atts['fallback'] ? wp_kses_post( '<div class="flosc-member-only-fallback">' . esc_html( $atts['fallback'] ) . '</div>' ) : '';
		}

		$user_id   = get_current_user_id();
		$is_member = get_user_meta( $user_id, '_flosc_member_access', true );

		if ( 'true' === $is_member || true === $is_member ) {
			return wp_kses_post( do_shortcode( $content ) );
		}

		// Not a member - show fallback if provided.
		return $atts['fallback'] ? wp_kses_post( '<div class="flosc-member-only-fallback">' . esc_html( $atts['fallback'] ) . '</div>' ) : '';
	}

	/**
	 * Shortcode: [flosc_contact_form_01] and [flosc-contact-form-01]
	 *
	 * @param mixed $atts Atts.
	 */
	public function shortcode_contact_form_01( $atts = array() ) {
		$atts = shortcode_atts(
			array(
				'flow' => '',
			),
			$atts
		);

		$settings = $this->get_contact_form_settings( (string) $atts['flow'] );
		// Which notice to paint after a contact-form round trip. Closed set now.
		$status = flosc_nav_param( 'flosc_contact_status', array( 'sent', 'error' ) );

		wp_enqueue_style(
			'flosc-contact-form',
			FLOSC_PLUGIN_URL . 'assets/css/flosc-contact-form.css',
			array(),
			filemtime( FLOSC_PLUGIN_DIR . 'assets/css/flosc-contact-form.css' )
		);

		// Every value placed in this rule is validated for CSS, not HTML: colors
		// are hex colors (sanitize_contact_color() already enforced that; it is
		// checked again here because this is the output point), and the font
		// stack may contain only the characters a CSS font-family list uses, so
		// no value can close the declaration or the rule.
		$flosc_font_stack = (string) $settings['message_font_family'];
		if ( ! preg_match( '/^[A-Za-z0-9 ,\'"_-]{1,200}$/', $flosc_font_stack ) ) {
			$flosc_font_stack = "'Courier New', Courier, monospace";
		}
		$css_vars = sprintf(
			'.flosc-contact-form-wrap{--flosc-contact-bg:%s;--flosc-contact-accent:%s;--flosc-contact-button-bg:%s;--flosc-contact-button-text:%s;--flosc-contact-msg-font:%s;--flosc-contact-msg-size:%dpx;}',
			sanitize_hex_color( $settings['card_background'] ) ? sanitize_hex_color( $settings['card_background'] ) : '#ffffff',
			sanitize_hex_color( $settings['accent_color'] ) ? sanitize_hex_color( $settings['accent_color'] ) : '#2e8b57',
			sanitize_hex_color( $settings['button_bg_color'] ) ? sanitize_hex_color( $settings['button_bg_color'] ) : '#1f6feb',
			sanitize_hex_color( $settings['button_text_color'] ) ? sanitize_hex_color( $settings['button_text_color'] ) : '#ffffff',
			$flosc_font_stack,
			max( 14, intval( $settings['message_font_size'] ) )
		);
		wp_add_inline_style( 'flosc-contact-form', $css_vars );

		$current_url   = home_url( add_query_arg( array(), $GLOBALS['wp']->request ?? '' ) );
		$rendered_at   = time();
		$honeypot_name = 'flosc_contact_company';
		$show_form     = ( 'success' !== $status );

		return flosc_capture_output(
			static function () use ( $settings, $status, $show_form, $current_url, $rendered_at, $honeypot_name ) {
				?>
		<section class="flosc-contact-form-wrap" aria-label="Contact Form">
			<div class="flosc-contact-form-card">
				<h2 class="flosc-contact-form-title"><?php echo esc_html( $settings['form_title'] ); ?></h2>
				<?php if ( '' !== $settings['form_intro'] ) : ?>
					<p class="flosc-contact-form-intro"><?php echo esc_html( $settings['form_intro'] ); ?></p>
				<?php endif; ?>

				<?php if ( 'success' === $status ) : ?>
					<p class="flosc-contact-notice flosc-contact-notice-success"><?php echo esc_html( $settings['success_message'] ); ?></p>
				<?php elseif ( 'error' === $status ) : ?>
					<p class="flosc-contact-notice flosc-contact-notice-error"><?php esc_html_e( 'Please review the form and try again.', 'flosc' ); ?></p>
				<?php endif; ?>

				<?php if ( $show_form ) : ?>
				<form class="flosc-contact-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" novalidate>
					<input type="hidden" name="action" value="flosc_contact_submit">
					<input type="hidden" name="flosc_contact_return" value="<?php echo esc_url( $current_url ); ?>">
					<input type="hidden" name="flosc_contact_flow" value="<?php echo esc_attr( $settings['flow_id'] ); ?>">
					<input type="hidden" name="flosc_contact_rendered_at" value="<?php echo esc_attr( $rendered_at ); ?>">
					<?php wp_nonce_field( 'flosc_contact_submit', 'flosc_contact_nonce' ); ?>

					<label class="flosc-contact-hp" for="<?php echo esc_attr( $honeypot_name ); ?>">Leave this empty</label>
					<input class="flosc-contact-hp" type="text" id="<?php echo esc_attr( $honeypot_name ); ?>" name="<?php echo esc_attr( $honeypot_name ); ?>" value="" autocomplete="off" tabindex="-1">

					<div class="flosc-contact-grid">
						<div class="flosc-contact-field">
							<label for="flosc_contact_first_name"><?php esc_html_e( 'First Name', 'flosc' ); ?></label>
							<input type="text" id="flosc_contact_first_name" name="flosc_contact_first_name" required maxlength="80" autocomplete="given-name">
						</div>
						<div class="flosc-contact-field">
							<label for="flosc_contact_last_name"><?php esc_html_e( 'Last Name', 'flosc' ); ?></label>
							<input type="text" id="flosc_contact_last_name" name="flosc_contact_last_name" required maxlength="80" autocomplete="family-name">
						</div>
						<div class="flosc-contact-field">
							<label for="flosc_contact_email"><?php esc_html_e( 'Email Address', 'flosc' ); ?></label>
							<input type="text" id="flosc_contact_email" name="flosc_contact_email" required maxlength="190" inputmode="email" autocomplete="off" autocapitalize="off" autocorrect="off" spellcheck="false">
						</div>
						<div class="flosc-contact-field">
							<label for="flosc_contact_phone"><?php esc_html_e( 'Phone Number', 'flosc' ); ?></label>
							<input type="text" id="flosc_contact_phone" name="flosc_contact_phone" required maxlength="40" autocomplete="tel">
						</div>
					</div>

					<div class="flosc-contact-field flosc-contact-field-message">
						<label for="flosc_contact_message"><?php esc_html_e( 'Message', 'flosc' ); ?></label>
						<textarea id="flosc_contact_message" name="flosc_contact_message" required rows="8" maxlength="4000"></textarea>
					</div>

					<button type="submit" class="flosc-contact-submit"><?php echo esc_html( $settings['submit_button_text'] ); ?></button>
				</form>
				<?php endif; ?>
			</div>
		</section>
				<?php
			}
		);
	}

	/**
	 * Handle contact form submit.
	 */
	public function handle_contact_form_submit() {
		// A field sent as an array is refused before anything is read.
		$flosc_fields = array(
			'flosc_contact_return',
			'flosc_contact_nonce',
			'flosc_contact_flow',
			'flosc_contact_first_name',
			'flosc_contact_last_name',
			'flosc_contact_email',
			'flosc_contact_phone',
			'flosc_contact_message',
			'flosc_contact_company',
			'flosc_contact_rendered_at',
		);
		foreach ( $flosc_fields as $flosc_field ) {
			if ( isset( $_POST[ $flosc_field ] ) && ! is_string( $_POST[ $flosc_field ] ) ) {
				$this->redirect_contact_form_result( home_url( '/' ), 'error' );
			}
		}

		// The return address is read first so a refused nonce can still send the
		// visitor back to the page they came from. The nonce is verified before
		// any form content is read.
		$return_url = isset( $_POST['flosc_contact_return'] ) ? esc_url_raw( wp_unslash( $_POST['flosc_contact_return'] ) ) : home_url( '/' );
		$nonce      = isset( $_POST['flosc_contact_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['flosc_contact_nonce'] ) ) : '';
		if ( ! wp_verify_nonce( $nonce, 'flosc_contact_submit' ) ) {
			$this->redirect_contact_form_result( $return_url, 'error' );
		}

		$flow_id = isset( $_POST['flosc_contact_flow'] ) ? sanitize_key( wp_unslash( $_POST['flosc_contact_flow'] ) ) : '';
		$result  = $this->process_contact_form_submission(
			array(
				'first_name'  => isset( $_POST['flosc_contact_first_name'] ) ? sanitize_text_field( wp_unslash( $_POST['flosc_contact_first_name'] ) ) : '',
				'last_name'   => isset( $_POST['flosc_contact_last_name'] ) ? sanitize_text_field( wp_unslash( $_POST['flosc_contact_last_name'] ) ) : '',
				'email'       => isset( $_POST['flosc_contact_email'] ) ? sanitize_text_field( wp_unslash( $_POST['flosc_contact_email'] ) ) : '',
				'phone'       => isset( $_POST['flosc_contact_phone'] ) ? sanitize_text_field( wp_unslash( $_POST['flosc_contact_phone'] ) ) : '',
				'message'     => isset( $_POST['flosc_contact_message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['flosc_contact_message'] ) ) : '',
				'honeypot'    => isset( $_POST['flosc_contact_company'] ) ? sanitize_text_field( wp_unslash( $_POST['flosc_contact_company'] ) ) : '',
				'rendered_at' => isset( $_POST['flosc_contact_rendered_at'] ) ? absint( wp_unslash( $_POST['flosc_contact_rendered_at'] ) ) : 0,
			),
			$flow_id,
			array(
				'source'         => 'page_form',
				'enforce_timing' => true,
			)
		);

		if ( empty( $result['success'] ) ) {
			$this->redirect_contact_form_result( $return_url, 'error' );
		}

		$this->redirect_contact_form_result( $return_url, 'success' );
	}

	/**
	 * Process contact form submission.
	 *
	 * @param mixed  $data    Data.
	 * @param string $flow_id Flow ID.
	 * @param mixed  $options Options.
	 * @return mixed
	 */
	public function process_contact_form_submission( $data, $flow_id = '', $options = array() ) {
		if ( ! is_array( $data ) || ! flosc_submitted_value_is_text( $flow_id ) || ! flosc_submitted_fields_are_text(
			$data,
			array( 'first_name', 'last_name', 'email', 'phone', 'message', 'honeypot', 'rendered_at' )
		) ) {
			return array(
				'success' => false,
				'error'   => 'validation',
			);
		}
		$flow_id  = sanitize_key( (string) $flow_id );
		$settings = $this->get_contact_form_settings( $flow_id );

		$first_name     = sanitize_text_field( (string) ( $data['first_name'] ?? '' ) );
		$last_name      = sanitize_text_field( (string) ( $data['last_name'] ?? '' ) );
		$email          = sanitize_email( (string) ( $data['email'] ?? '' ) );
		$phone          = sanitize_text_field( (string) ( $data['phone'] ?? '' ) );
		$message        = sanitize_textarea_field( (string) ( $data['message'] ?? '' ) );
		$honeypot       = sanitize_text_field( (string) ( $data['honeypot'] ?? '' ) );
		$rendered_at    = intval( $data['rendered_at'] ?? 0 );
		$enforce_timing = ! empty( $options['enforce_timing'] );
		$source         = sanitize_key( (string) ( $options['source'] ?? 'contact_form' ) );

		if ( '' !== $honeypot ) {
			return array(
				'success' => false,
				'error'   => 'spam_honeypot',
			);
		}

		if ( $enforce_timing ) {
			if ( $rendered_at <= 0 || ( time() - $rendered_at ) < intval( $settings['min_submit_seconds'] ) ) {
				return array(
					'success' => false,
					'error'   => 'timing',
				);
			}
		}

		if ( '' === $first_name || '' === $last_name || '' === $email || '' === $phone || '' === $message || ! is_email( $email ) ) {
			return array(
				'success' => false,
				'error'   => 'validation',
			);
		}

		$ip           = sanitize_text_field( (string) wp_unslash( $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0' ) );
		$ip_hash      = md5( $ip );
		$hourly_key   = 'flosc_contact_rate_' . $ip_hash;
		$hourly_count = intval( get_transient( $hourly_key ) );
		if ( $hourly_count >= intval( $settings['max_submissions_per_hour'] ) ) {
			return array(
				'success' => false,
				'error'   => 'rate_limit',
			);
		}
		set_transient( $hourly_key, $hourly_count + 1, HOUR_IN_SECONDS );

		$dedupe_window = max( 1, intval( $settings['duplicate_window_minutes'] ) ) * MINUTE_IN_SECONDS;
		$dedupe_hash   = md5( strtolower( trim( $email ) ) . '|' . preg_replace( '/\s+/', ' ', trim( $message ) ) );
		$dedupe_key    = 'flosc_contact_dupe_' . $dedupe_hash;
		if ( get_transient( $dedupe_key ) ) {
			return array(
				'success' => false,
				'error'   => 'duplicate',
			);
		}
		set_transient( $dedupe_key, 1, $dedupe_window );

		$recipient = sanitize_email( $settings['forward_to_email'] );
		if ( ! is_email( $recipient ) ) {
			$recipient = get_option( 'admin_email' );
		}

		$subject = trim( (string) $settings['email_subject'] );
		if ( '' === $subject ) {
			$subject = 'New Contact Form Message';
		}

		$body = "Contact Form Submission\n\n"
			. "Source: {$source}\n"
			. "First Name: {$first_name}\n"
			. "Last Name: {$last_name}\n"
			. "Email: {$email}\n"
			. "Phone: {$phone}\n"
			. 'Flow: ' . ( '' !== $flow_id ? $flow_id : 'default' ) . "\n"
			. "IP Hash: {$ip_hash}\n"
			. "\nMessage:\n{$message}\n";

		$headers = array(
			'Content-Type: text/plain; charset=UTF-8',
			'Reply-To: ' . $email,
		);

		$sent = wp_mail( $recipient, $subject, $body, $headers );
		if ( ! $sent ) {
			return array(
				'success' => false,
				'error'   => 'mail_failed',
			);
		}

		return array(
			'success' => true,
			'message' => $settings['success_message'],
		);
	}

	/**
	 * Redirect contact form result.
	 *
	 * @param mixed $return_url Return URL.
	 * @param mixed $status     Status.
	 */
	private function redirect_contact_form_result( $return_url, $status ) {
		$target = $return_url ? $return_url : home_url( '/' );
		$target = add_query_arg( 'flosc_contact_status', sanitize_key( $status ), $target );
		wp_safe_redirect( $target );
		exit;
	}

	/**
	 * Get contact form settings.
	 *
	 * @param string $flow_id Flow ID.
	 * @return mixed
	 */
	private function get_contact_form_settings( $flow_id = '' ) {
		$flow_id  = sanitize_key( (string) $flow_id );
		$settings = array();

		if ( '' !== $flow_id ) {
			$flow_settings = get_option( 'flosc_flow_' . $flow_id, array() );
			if ( is_array( $flow_settings ) ) {
				$settings = $flow_settings;
			}
		} elseif ( method_exists( $this, 'get_current_flow' ) ) {
			$flow = $this->get_current_flow();
			if ( ! empty( $flow['ivr_file'] ) ) {
				$resolved_flow = sanitize_key( pathinfo( basename( (string) $flow['ivr_file'] ), PATHINFO_FILENAME ) );
				$flow_settings = get_option( 'flosc_flow_' . $resolved_flow, array() );
				if ( is_array( $flow_settings ) ) {
					$settings = $flow_settings;
					$flow_id  = $resolved_flow;
				}
			}
		}

		return array(
			'flow_id'                  => $flow_id,
			'form_title'               => trim( (string) ( $settings['contact_form_title'] ?? 'Contact the Site Operator' ) ),
			'form_intro'               => trim( (string) ( $settings['contact_form_intro'] ?? 'Please fill out the form below to get in touch with the site operator. If you do not receive a response, please try another contact method.' ) ),
			'submit_button_text'       => trim( (string) ( $settings['contact_form_submit_text'] ?? 'Send Message' ) ),
			'success_message'          => trim( (string) ( $settings['contact_form_success_message'] ?? 'We\'ve forwarded your message to the site operator, thank you!' ) ),
			'forward_to_email'         => trim( (string) ( $settings['contact_form_forward_to_email'] ?? get_option( 'admin_email' ) ) ),
			'email_subject'            => trim( (string) ( $settings['contact_form_email_subject'] ?? 'FLOSC Contact Form Message' ) ),
			'min_submit_seconds'       => max( 2, intval( $settings['contact_form_min_submit_seconds'] ?? 4 ) ),
			'max_submissions_per_hour' => max( 1, intval( $settings['contact_form_max_submissions_per_hour'] ?? 3 ) ),
			'duplicate_window_minutes' => max( 1, intval( $settings['contact_form_duplicate_window_minutes'] ?? 30 ) ),
			'button_bg_color'          => $this->sanitize_contact_color( (string) ( $settings['contact_form_button_bg_color'] ?? '#1f6feb' ), '#1f6feb' ),
			'button_text_color'        => $this->sanitize_contact_color( (string) ( $settings['contact_form_button_text_color'] ?? '#ffffff' ), '#ffffff' ),
			'card_background'          => $this->sanitize_contact_color( (string) ( $settings['contact_form_card_background'] ?? '#ffffff' ), '#ffffff' ),
			'accent_color'             => $this->sanitize_contact_color( (string) ( $settings['contact_form_accent_color'] ?? '#2e8b57' ), '#2e8b57' ),
			'message_font_family'      => trim( (string) ( $settings['contact_form_message_font_family'] ?? "'Courier New', Courier, monospace" ) ),
			'message_font_size'        => max( 16, intval( $settings['contact_form_message_font_size'] ?? 20 ) ),
		);
	}

	/**
	 * Sanitize contact color.
	 *
	 * @param mixed $color    Color.
	 * @param mixed $fallback Fallback.
	 * @return mixed
	 */
	private function sanitize_contact_color( $color, $fallback ) {
		$clean = sanitize_hex_color( $color );
		return $clean ? $clean : $fallback;
	}

	/**
	 * Enqueue companion widget on non-app WordPress pages.
	 * Only loads if companion mode is enabled for the current flow.
	 * v1.6.3: Fixed to read from flat per-flow settings (matching admin save pattern)
	 *
	 * @since 1.6.1
	 */
	public function enqueue_companion() {
		// Production path is FLOSC_Companion_Mode::enqueue_companion (app-route-only iframe).
		// App routes never load outer chrome; non-app iframe targets are invalid there.
		if ( $this->is_flosc_request() ) {
			return;
		}

		// Read from per-flow settings (flat keys, not overrides).
		$enabled = $this->get_setting( 'companion_enabled', false );
		if ( ! $enabled ) {
			return;
		}

		$app_url = $this->get_app_url();
		if ( empty( $app_url ) ) {
			return;
		}

		$accent      = $this->get_setting( 'companion_accent_color', '#2563eb' );
		$title       = $this->get_setting( 'companion_greeting', 'Chat with us' );
		$header_icon = $this->get_setting( 'companion_header_icon_url', '' );
		if ( '' === $header_icon && function_exists( 'flosc_get_chatlogo_url' ) ) {
			$header_icon = flosc_get_chatlogo_url();
		}
		$product_name = function_exists( 'flosc_personality_name' )
			? sanitize_text_field( flosc_personality_name() )
			: '';
		if ( '' === $product_name && function_exists( 'flosc' ) && method_exists( flosc(), 'get_floscflow_identity' ) ) {
			$id           = flosc()->get_floscflow_identity();
			$product_name = sanitize_text_field( (string) ( $id['name'] ?? '' ) );
		}

		wp_enqueue_style(
			'flosc-companion',
			FLOSC_PLUGIN_URL . 'assets/css/flosc-companion.css',
			array(),
			filemtime( FLOSC_PLUGIN_DIR . 'assets/css/flosc-companion.css' )
		);

		wp_enqueue_script(
			'flosc-companion',
			FLOSC_PLUGIN_URL . 'assets/js/flosc-companion.js',
			array(),
			filemtime( FLOSC_PLUGIN_DIR . 'assets/js/flosc-companion.js' ),
			true
		);

		/*
		 * The widget configuration reaches the browser through
		 * wp_localize_script(), which JSON-encodes it. It sits one level down,
		 * under 'config', because wp_localize_script() turns top-level scalars
		 * into strings; nested values keep their types, so showHeaderTokens is
		 * still the boolean false. The inline call that starts the widget is a
		 * fixed string with no PHP value in it.
		 */
		wp_localize_script(
			'flosc-companion',
			'floscCompanionBoot',
			array(
				'config' => array(
					'appUrl'           => esc_url_raw( $app_url ),
					'title'            => sanitize_text_field( (string) $title ),
					'productName'      => $product_name,
					'headerIconUrl'    => esc_url_raw( (string) $header_icon ),
					'assistantTitle'   => $product_name ? $product_name : sanitize_text_field( (string) $title ),
					'showHeaderTokens' => false,
					'headerTokenText'  => '',
					'accentColor'      => sanitize_hex_color( (string) $accent ) ? sanitize_hex_color( (string) $accent ) : '#2563eb',
				),
			)
		);
		wp_add_inline_script( 'flosc-companion', 'FloscCompanion.init( window.floscCompanionBoot.config );' );
	}

	/**
	 * Enqueue chat styling (v9.3.9 - Bulletproof Architecture)
	 *
	 * Architecture:
	 * 1. flosc-frontend.css - Non-chat served content
	 * 2. flosc-chat.css - Chat interface styles
	 * 3. This method - Chat preset variables + dynamic overrides
	 *
	 * Presets: auto (system preference), light, dark
	 * Customization: bubble style, accent color, font, scale
	 */
	private function enqueue_chat_style() {
		// v1.6.1: Per-flow settings via FLOSC_Flow_Manager::get_setting().
		$fm     = FLOSC_Flow_Manager::instance();
		$preset = $fm->get_setting( 'flosc_chat_style_preset', 'style', 'preset', 'light' );
		$bubble = $fm->get_setting( 'flosc_chat_style_bubble', 'style', 'bubble', 'subtle-notch' );
		$accent = $fm->get_setting( 'flosc_chat_style_accent', 'style', 'accent', '' );
		// The accent is written into a CSS rule below, so it is checked as a CSS
		// color at this output point: a hex color, or nothing.
		$accent = sanitize_hex_color( (string) $accent );
		$accent = $accent ? $accent : '';
		$font   = $fm->get_setting( 'flosc_chat_style_font', 'style', 'font', 'system' );
		$scale  = intval( $fm->get_setting( 'flosc_chat_style_scale', 'style', 'scale', 100 ) );

		// Bubble style presets (border-radius values per FLOSC_STYLE_GUIDE.md).
		$bubble_styles = array(
			'subtle-notch' => array(
				'user'      => '18px 18px 4px 18px',
				'assistant' => '4px 18px 18px 18px',
			),
			'classic'      => array(
				'user'      => '18px 18px 0 18px',
				'assistant' => '0 18px 18px 18px',
			),
			'modern'       => array(
				'user'      => '20px 20px 6px 20px',
				'assistant' => '6px 20px 20px 20px',
			),
			'minimal'      => array(
				'user'      => '16px',
				'assistant' => '16px',
			),
			'sharp'        => array(
				'user'      => '12px 12px 2px 12px',
				'assistant' => '2px 12px 12px 12px',
			),
		);

		// Font family map.
		$font_families = array(
			'system'        => '',
			'inter'         => '"Inter", -apple-system, sans-serif',
			'ibm-plex-sans' => '"IBM Plex Sans", -apple-system, sans-serif',
			'ibm-plex-mono' => '"IBM Plex Mono", "SF Mono", Monaco, monospace',
			'roboto'        => '"Roboto", -apple-system, sans-serif',
			'roboto-mono'   => '"Roboto Mono", "SF Mono", Monaco, monospace',
			'fira-code'     => '"Fira Code", "SF Mono", Monaco, monospace',
		);

		// File paths.
		$light_path = FLOSC_PLUGIN_DIR . 'assets/css/chat-style-light.css';
		$dark_path  = FLOSC_PLUGIN_DIR . 'assets/css/chat-style-dark.css';

		$inline_css = '';

		// ===========================================
		// PRESET LOADING
		// ===========================================
		if ( 'auto' === $preset ) {
			// Auto mode: Light by default, dark via prefers-color-scheme.
			if ( file_exists( $light_path ) && file_exists( $dark_path ) ) {
				$light_content = flosc_fs_get_contents( $light_path );
				$dark_content  = flosc_fs_get_contents( $dark_path );

				if ( $light_content ) {
					$light_vars = $this->extract_css_variables( $light_content );
					if ( $light_vars ) {
						$inline_css .= "/* Light Theme (Default) */\n:root {\n{$light_vars}}\n\n";
					}
				}

				if ( $dark_content ) {
					$dark_vars = $this->extract_css_variables( $dark_content );
					if ( $dark_vars ) {
						$inline_css .= "/* Dark Theme (System Preference) */\n@media (prefers-color-scheme: dark) {\n  :root {\n{$dark_vars}  }\n}\n\n";
					}
				}
			}
		} else {
			// Named preset (light, dark, chatgpt, claude, grok): load as external stylesheet.
			$safe_preset = preg_replace( '/[^a-z0-9-]/', '', $preset );
			$preset_path = FLOSC_PLUGIN_DIR . 'assets/css/chat-style-' . $safe_preset . '.css';
			if ( file_exists( $preset_path ) ) {
				wp_enqueue_style(
					'flosc-preset',
					FLOSC_PLUGIN_URL . 'assets/css/chat-style-' . $safe_preset . '.css',
					array( 'flosc-chat' ),
					filemtime( $preset_path )
				);
			}
		}

		// ===========================================
		// DYNAMIC OVERRIDES
		// ===========================================
		$bubble_config = $bubble_styles[ $bubble ] ?? $bubble_styles['subtle-notch'];

		$overrides   = array();
		$overrides[] = "--flosc-user-message-radius: {$bubble_config['user']}";
		$overrides[] = "--flosc-assistant-message-radius: {$bubble_config['assistant']}";

		// v1.6.1: Full accent color cascade (5→15 derived variables).
		if ( ! empty( $accent ) && '#2563eb' !== $accent ) {
			// Compute derived colors from hex accent.
			$hover   = $this->adjust_color_brightness( $accent, -15 );
			$subtle  = $this->hex_to_rgba( $accent, 0.06 );
			$subtle4 = $this->hex_to_rgba( $accent, 0.04 );
			$light   = $this->adjust_color_brightness( $accent, 40 );

			// Core accent.
			$overrides[] = "--flosc-accent: {$accent}";
			$overrides[] = "--flosc-accent-hover: {$hover}";
			$overrides[] = "--flosc-accent-subtle: {$subtle}";

			// Components that derive from accent.
			$overrides[] = "--flosc-user-message-bg: {$accent}";
			$overrides[] = "--flosc-user-avatar-bg: {$accent}";
			$overrides[] = "--flosc-send-btn-bg: {$accent}";
			$overrides[] = "--flosc-pill-hover-text: {$accent}";
			$overrides[] = "--flosc-pill-hover-border: {$light}";
			$overrides[] = "--flosc-card-hover-text: {$accent}";
			$overrides[] = "--flosc-card-hover-border: {$light}";
			$overrides[] = "--flosc-content-link: {$accent}";
			$overrides[] = "--flosc-content-link-hover: {$hover}";
			$overrides[] = "--flosc-content-blockquote-border: {$accent}";
			$overrides[] = "--flosc-content-blockquote-bg: {$subtle4}";
			$overrides[] = "--flosc-quiz-tab-active-bg: {$accent}";
			$overrides[] = "--flosc-quiz-input-focus-border: {$accent}";
		}

		// Scale factor.
		if ( 100 !== $scale && $scale > 0 ) {
			$scale_factor = $scale / 100;
			$overrides[]  = "--flosc-scale: {$scale_factor}";
		}

		// Font family.
		if ( 'system' !== $font && isset( $font_families[ $font ] ) && ! empty( $font_families[ $font ] ) ) {
			$overrides[] = "--flosc-font-family: {$font_families[$font]}";
		}

		if ( ! empty( $overrides ) ) {
			$inline_css .= "/* Dynamic Overrides */\n:root {\n    " . implode( ";\n    ", $overrides ) . ";\n}\n\n";
		}

		// Font application.
		if ( 'system' !== $font && isset( $font_families[ $font ] ) && ! empty( $font_families[ $font ] ) ) {
			$inline_css .= "/* Font Application */\n";
			$inline_css .= ".flosc-app,\n.flosc-app .messages,\n.flosc-app .message-text {\n";
			$inline_css .= "    font-family: var(--flosc-font-family) !important;\n}\n\n";
		}

		// Attach inline styles to flosc-chat handle (always exists on app requests).
		if ( ! empty( trim( $inline_css ) ) ) {
			wp_add_inline_style( 'flosc-chat', $inline_css );
		}
	}

	/**
	 * Extract CSS variables from stylesheet content
	 * Returns the inner content of :root { } block
	 *
	 * @param string $css_content Raw CSS file content.
	 * @return string Variable declarations or empty string
	 */
	private function extract_css_variables( $css_content ) {
		if ( empty( $css_content ) ) {
			return '';
		}

		// Remove CSS comments.
		$css = preg_replace( '/\/\*[\s\S]*?\*\//', '', $css_content );

		// Extract content inside :root { }.
		if ( preg_match( '/:root\s*\{([^}]+)\}/s', $css, $matches ) ) {
			return trim( $matches[1] ) . "\n";
		}

		return '';
	}

	/**
	 * Adjust hex color brightness by a percentage (-100 to +100).
	 * Negative = darker, positive = lighter.
	 * Used for accent color cascade.
	 *
	 * @since 1.6.1
	 *
	 * @param mixed $hex     Hex.
	 * @param mixed $percent Percent.
	 */
	private function adjust_color_brightness( $hex, $percent ) {
		$hex = ltrim( $hex, '#' );
		if ( 3 === strlen( $hex ) ) {
			$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
		}
		$r = hexdec( substr( $hex, 0, 2 ) );
		$g = hexdec( substr( $hex, 2, 2 ) );
		$b = hexdec( substr( $hex, 4, 2 ) );

		$r = max( 0, min( 255, $r + round( $r * $percent / 100 ) ) );
		$g = max( 0, min( 255, $g + round( $g * $percent / 100 ) ) );
		$b = max( 0, min( 255, $b + round( $b * $percent / 100 ) ) );

		return sprintf( '#%02x%02x%02x', $r, $g, $b );
	}

	/**
	 * Convert hex color to rgba string.
	 * Used for accent-subtle generation.
	 *
	 * @since 1.6.1
	 *
	 * @param mixed $hex   Hex.
	 * @param mixed $alpha Alpha.
	 */
	private function hex_to_rgba( $hex, $alpha ) {
		$hex = ltrim( $hex, '#' );
		if ( 3 === strlen( $hex ) ) {
			$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
		}
		$r = hexdec( substr( $hex, 0, 2 ) );
		$g = hexdec( substr( $hex, 2, 2 ) );
		$b = hexdec( substr( $hex, 4, 2 ) );
		return "rgba({$r}, {$g}, {$b}, {$alpha})";
	}

	/**
	 * Redirect back to an admin screen with a Settings API notice.
	 *
	 * @param string $url     Destination.
	 * @param string $message Notice text.
	 * @param string $type    success|error.
	 * @return void
	 */
	private function flosc_redirect_notice( $url, $message, $type = 'success' ) {
		add_settings_error( 'flosc', 'flosc_notice', (string) $message, ( 'error' === $type ) ? 'error' : 'success' );
		set_transient( 'settings_errors', get_settings_errors(), 30 );
		wp_safe_redirect( add_query_arg( 'settings-updated', 'true', $url ) );
		exit;
	}

	/**
	 * IVR filenames an administrator's identity save can address.
	 *
	 * @return string[]
	 */
	private function flosc_admin_ivr_filenames() {
		$files = array();
		$found = function_exists( 'flosc_config_glob' ) ? flosc_config_glob( array( '*_ivr.md', 'ivr*.md' ) ) : array();
		sort( $found );
		foreach ( $found as $file ) {
			$name = basename( (string) $file );
			if ( false === strpos( $name, 'backup' ) ) {
				$files[] = $name;
			}
		}
		return array_values( array_unique( $files ) );
	}

	/**
	 * Settings row for one IVR file, including the empty-option defaults the identity screen uses.
	 *
	 * @param string $ivr_file IVR filename.
	 * @return array
	 */
	private function flosc_identity_flow_row( $ivr_file ) {
		$key      = flosc_resolve_flow_option_key_for_ivr( $ivr_file );
		$settings = get_option( $key, array() );
		if ( empty( $settings ) || ! is_array( $settings ) ) {
			$slug     = strtolower( (string) preg_replace( '/[^a-z0-9_-]/i', '', pathinfo( $ivr_file, PATHINFO_FILENAME ) ) );
			$settings = array(
				'name'          => ucwords( str_replace( array( '_', '-', 'ivr', '.md' ), array( ' ', ' ', '', '' ), $ivr_file ) ),
				'slug'          => $slug,
				'domain'        => '',
				'title'         => '',
				'tagline'       => '',
				'primary_color' => '#4f46e5',
				'status'        => 'active',
			);
		}
		return array(
			'key'      => $key,
			'settings' => $settings,
		);
	}

	/**
	 * Whether every field in this POST request is one piece of text.
	 *
	 * Reads only the field names and the PHP type of each value; no value is
	 * used. A request carrying an array anywhere is refused by the caller,
	 * which is what the identity screens always did.
	 *
	 * The caller has already checked the capability.
	 *
	 * @return bool
	 */
	private function flosc_posted_fields_are_all_text() {
		// Same action the identity form prints. check_admin_referer() is
		// idempotent: the handler already ran it, and running it here keeps the
		// nonce check inside the function that reads the request.
		check_admin_referer( 'flosc_save_settings' );
		foreach ( array_keys( $_POST ) as $flosc_field ) {
			if ( isset( $_POST[ $flosc_field ] ) && ! is_string( $_POST[ $flosc_field ] ) ) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Read one flow's identity fields from the POST request, sanitized at the read.
	 *
	 * The all-flows identity screen names each field '<prefix><setting key>'.
	 * Every matching field is read on its own and passed through the core
	 * WordPress sanitizer for what that setting holds:
	 *
	 * - policy page bodies are HTML the administrator writes: wp_kses_post();
	 * - policy slugs: sanitize_title();
	 * - external policy links: esc_url_raw();
	 * - on/off switches and the status word: sanitize_key();
	 * - everything else is one line of text: sanitize_text_field().
	 *
	 * flosc_apply_posted_identity_fields() then applies the per-key rules it
	 * always applied. Those rules are unchanged; they now receive values that
	 * were already sanitized when they left the request.
	 *
	 * The caller has already checked the capability.
	 *
	 * @param string $prefix Field prefix, including the trailing underscore.
	 * @return array Setting-prefixed field name => sanitized value.
	 */
	private function flosc_read_posted_identity_fields( $prefix ) {
		$prefix    = (string) $prefix;
		$html_keys = array( 'privacy_policy_content', 'terms_of_service_content', 'data_deletion_content', 'platform_compliance_content' );
		$slug_keys = array( 'privacy_policy_slug', 'terms_of_service_slug', 'data_deletion_slug', 'platform_compliance_slug' );
		$url_keys  = array( 'privacy_policy_external_url', 'terms_of_service_external_url', 'data_deletion_external_url', 'platform_compliance_external_url' );
		$key_keys  = array( 'privacy_policy_use_external_link', 'terms_of_service_use_external_link', 'data_deletion_use_external_link', 'platform_compliance_use_external_link', 'policy_content_management_status' );
		$fields    = array();

		check_admin_referer( 'flosc_save_settings' );

		foreach ( array_keys( $_POST ) as $flosc_field ) {
			$flosc_field = (string) $flosc_field;
			if ( '' === $prefix || 0 !== strpos( $flosc_field, $prefix ) || ! isset( $_POST[ $flosc_field ] ) || ! is_string( $_POST[ $flosc_field ] ) ) {
				continue;
			}
			$setting_key = substr( $flosc_field, strlen( $prefix ) );
			if ( in_array( $setting_key, $html_keys, true ) ) {
				$fields[ $flosc_field ] = wp_kses_post( wp_unslash( $_POST[ $flosc_field ] ) );
			} elseif ( in_array( $setting_key, $slug_keys, true ) ) {
				$fields[ $flosc_field ] = sanitize_title( wp_unslash( $_POST[ $flosc_field ] ) );
			} elseif ( in_array( $setting_key, $url_keys, true ) ) {
				// esc_url_raw() trims leading space itself and encodes a trailing
				// space as %20; the trailing encoded spaces are removed so a URL
				// pasted with a stray space is stored as it always was.
				$fields[ $flosc_field ] = preg_replace( '/(%20)+$/', '', esc_url_raw( wp_unslash( $_POST[ $flosc_field ] ) ) );
			} elseif ( in_array( $setting_key, $key_keys, true ) ) {
				$fields[ $flosc_field ] = sanitize_key( wp_unslash( $_POST[ $flosc_field ] ) );
			} else {
				$fields[ $flosc_field ] = sanitize_text_field( wp_unslash( $_POST[ $flosc_field ] ) );
			}
		}

		return $fields;
	}

	/**
	 * Apply one flow's posted identity fields and nest the identity keys.
	 *
	 * @param array  $settings Existing settings.
	 * @param array  $post     Fields from flosc_read_posted_identity_fields(), already sanitized.
	 * @param string $prefix   Field prefix, including the trailing underscore.
	 * @return array
	 */
	private function flosc_apply_posted_identity_fields( array $settings, array $post, $prefix ) {
		$html_keys = array( 'privacy_policy_content', 'terms_of_service_content', 'data_deletion_content', 'platform_compliance_content' );
		$slug_keys = array( 'privacy_policy_slug', 'terms_of_service_slug', 'data_deletion_slug', 'platform_compliance_slug' );
		$url_keys  = array( 'privacy_policy_external_url', 'terms_of_service_external_url', 'data_deletion_external_url', 'platform_compliance_external_url' );
		$bool_keys = array( 'privacy_policy_use_external_link', 'terms_of_service_use_external_link', 'data_deletion_use_external_link', 'platform_compliance_use_external_link' );
		$prefix    = (string) $prefix;

		foreach ( $post as $key => $value ) {
			if ( 0 !== strpos( (string) $key, $prefix ) ) {
				continue;
			}
			$setting_key = substr( (string) $key, strlen( $prefix ) );
			if ( in_array( $setting_key, $html_keys, true ) ) {
				$settings[ $setting_key ] = wp_kses_post( $value );
			} elseif ( in_array( $setting_key, $slug_keys, true ) ) {
				$settings[ $setting_key ] = sanitize_title( (string) $value );
			} elseif ( in_array( $setting_key, $url_keys, true ) ) {
				$settings[ $setting_key ] = esc_url_raw( trim( (string) $value ) );
			} elseif ( in_array( $setting_key, $bool_keys, true ) ) {
				$settings[ $setting_key ] = ( '1' === (string) $value ) ? '1' : '0';
			} elseif ( 'policy_content_management_status' === $setting_key ) {
				$settings[ $setting_key ] = ( 'inactive' === (string) $value ) ? 'inactive' : 'active';
			} else {
				$settings[ $setting_key ] = sanitize_text_field( $value );
			}
		}

		$id_keys  = array(
			'name',
			'title',
			'tagline',
			'primary_color',
			'chatlogo_url',
			'favicon_url',
			'badgeUrl',
			'share_text',
			'privacy_policy_content',
			'terms_of_service_content',
			'data_deletion_content',
			'platform_compliance_content',
			'privacy_policy_slug',
			'privacy_policy_heading',
			'terms_of_service_slug',
			'terms_of_service_heading',
			'data_deletion_slug',
			'data_deletion_heading',
			'platform_compliance_slug',
			'platform_compliance_heading',
			'policy_content_management_status',
			'privacy_policy_use_external_link',
			'privacy_policy_external_url',
			'terms_of_service_use_external_link',
			'terms_of_service_external_url',
			'data_deletion_use_external_link',
			'data_deletion_external_url',
			'platform_compliance_use_external_link',
			'platform_compliance_external_url',
		);
		$identity = isset( $settings['identity'] ) && is_array( $settings['identity'] ) ? $settings['identity'] : array();
		foreach ( $id_keys as $id_key ) {
			if ( isset( $settings[ $id_key ] ) ) {
				$identity[ $id_key ] = $settings[ $id_key ];
				unset( $settings[ $id_key ] );
			}
		}
		$settings['identity'] = $identity;
		return $settings;
	}

	/**
	 * Admin URL for a settings tab.
	 *
	 * @param string $ivr  IVR filename.
	 * @param string $tab  Tab slug.
	 * @param string $view Optional view slug.
	 * @return string
	 */
	private function flosc_admin_settings_url( $ivr, $tab, $view = '' ) {
		$args = array(
			'page' => 'flosc-settings',
			'ivr'  => sanitize_file_name( (string) $ivr ),
			'tab'  => sanitize_key( (string) $tab ),
		);
		$view = sanitize_key( (string) $view );
		if ( '' !== $view ) {
			$args['view'] = $view;
		}
		return add_query_arg( $args, admin_url( 'admin.php' ) );
	}

	/**
	 * Save one flow's identity fields from the all-flows screen.
	 *
	 * @return void
	 */
	public function handle_save_one_flow_identity() {
		check_admin_referer( 'flosc_save_settings' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to save multi-flow identity settings.', 'flosc' ), '', array( 'response' => 403 ) );
		}
		if ( ! $this->flosc_posted_fields_are_all_text() ) {
			$this->flosc_redirect_notice( $this->flosc_admin_settings_url( '', 'identity', 'all' ), 'That flow could not be saved.', 'error' );
		}
		$save_ivr = isset( $_POST['flosc_save_flow'] ) && is_string( $_POST['flosc_save_flow'] ) ? sanitize_file_name( wp_unslash( $_POST['flosc_save_flow'] ) ) : '';
		$return   = ( isset( $_GET['ivr'] ) && is_string( $_GET['ivr'] ) ) ? sanitize_file_name( wp_unslash( $_GET['ivr'] ) ) : '';
		$row      = $this->flosc_identity_flow_row( $save_ivr );
		if ( '' === $save_ivr || ! in_array( $save_ivr, $this->flosc_admin_ivr_filenames(), true ) ) {
			$this->flosc_redirect_notice( $this->flosc_admin_settings_url( $return, 'identity', 'all' ), 'That flow could not be saved.', 'error' );
		}
		$prefix   = 'flow_' . md5( $save_ivr ) . '_';
		$settings = $this->flosc_apply_posted_identity_fields( $row['settings'], $this->flosc_read_posted_identity_fields( $prefix ), $prefix );
		update_option( $row['key'], $settings );
		$this->flosc_redirect_notice( $this->flosc_admin_settings_url( '' !== $return ? $return : $save_ivr, 'identity', 'all' ), 'Saved: ' . $save_ivr );
	}

	/**
	 * Save every flow's identity fields from the all-flows screen.
	 *
	 * @return void
	 */
	public function handle_save_all_flow_identities() {
		check_admin_referer( 'flosc_save_settings' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to save multi-flow identity settings.', 'flosc' ), '', array( 'response' => 403 ) );
		}
		if ( ! $this->flosc_posted_fields_are_all_text() ) {
			$this->flosc_redirect_notice( $this->flosc_admin_settings_url( '', 'identity', 'all' ), 'The flow identities could not be saved.', 'error' );
		}
		$return = ( isset( $_GET['ivr'] ) && is_string( $_GET['ivr'] ) ) ? sanitize_file_name( wp_unslash( $_GET['ivr'] ) ) : '';
		foreach ( $this->flosc_admin_ivr_filenames() as $ivr_file ) {
			$row      = $this->flosc_identity_flow_row( $ivr_file );
			$prefix   = 'flow_' . md5( $ivr_file ) . '_';
			$settings = $this->flosc_apply_posted_identity_fields( $row['settings'], $this->flosc_read_posted_identity_fields( $prefix ), $prefix );
			update_option( $row['key'], $settings );
		}
		$this->flosc_redirect_notice( $this->flosc_admin_settings_url( $return, 'identity', 'all' ), 'All flows saved!' );
	}

	/**
	 * Flow option for an IVR filename the caller already read.
	 *
	 * The caller reads the query value after check_admin_referer(). This method
	 * does not touch the request.
	 *
	 * @param string $ivr IVR filename.
	 * @return array IVR filename, option key, and settings. Refuses when the flow is not editable.
	 */
	private function flosc_posted_flow_settings( $ivr ) {
		$ivr     = sanitize_file_name( (string) $ivr );
		$flow_id = sanitize_key( pathinfo( $ivr, PATHINFO_FILENAME ) );
		if ( '' === $flow_id || ! function_exists( 'flosc_flows' ) || ! flosc_flows()->can_access_flow_admin( $flow_id ) ) {
			wp_die( esc_html__( 'You do not have permission to manage this flow.', 'flosc' ), '', array( 'response' => 403 ) );
		}
		$key      = flosc_resolve_flow_option_key_for_ivr( $ivr );
		$settings = get_option( $key, array() );
		if ( ! is_array( $settings ) ) {
			$settings = array();
		}
		return array( $ivr, $key, $settings );
	}

	/**
	 * Delete one manual AI feedback row.
	 *
	 * @return void
	 */
	public function handle_delete_feedback() {
		check_admin_referer( 'flosc_save_settings' );
		if ( ! current_user_can( 'edit_others_posts' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'flosc' ), '', array( 'response' => 403 ) );
		}
		$posted_ivr                   = ( isset( $_GET['ivr'] ) && is_string( $_GET['ivr'] ) ) ? sanitize_file_name( wp_unslash( $_GET['ivr'] ) ) : '';
		list( $ivr, $key, $settings ) = $this->flosc_posted_flow_settings( $posted_ivr );
		foreach ( array( 'flosc_delete_feedback' ) as $flosc_field ) {
			if ( isset( $_POST[ $flosc_field ] ) && ! is_string( $_POST[ $flosc_field ] ) ) {
				$this->flosc_redirect_notice( $this->flosc_admin_settings_url( $ivr, 'chat-logs' ), 'Feedback was not deleted.', 'error' );
			}
		}
		$delete_id               = isset( $_POST['flosc_delete_feedback'] ) ? sanitize_text_field( wp_unslash( $_POST['flosc_delete_feedback'] ) ) : '';
		$items                   = isset( $settings['ai_feedback'] ) && is_array( $settings['ai_feedback'] ) ? $settings['ai_feedback'] : array();
		$settings['ai_feedback'] = array_values(
			array_filter(
				$items,
				static function ( $item ) use ( $delete_id ) {
					return ( $item['id'] ?? '' ) !== $delete_id;
				}
			)
		);
		update_option( $key, $settings );
		$this->flosc_redirect_notice( $this->flosc_admin_settings_url( $ivr, 'chat-logs' ), 'Feedback deleted.' );
	}

	/**
	 * Add one manual AI feedback row.
	 *
	 * @return void
	 */
	public function handle_add_feedback() {
		check_admin_referer( 'flosc_save_settings' );
		if ( ! current_user_can( 'edit_others_posts' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'flosc' ), '', array( 'response' => 403 ) );
		}
		$posted_ivr                   = ( isset( $_GET['ivr'] ) && is_string( $_GET['ivr'] ) ) ? sanitize_file_name( wp_unslash( $_GET['ivr'] ) ) : '';
		list( $ivr, $key, $settings ) = $this->flosc_posted_flow_settings( $posted_ivr );
		foreach ( array( 'feedback_user_message', 'feedback_bad_response', 'feedback_admin_note', 'feedback_preferred_response' ) as $flosc_field ) {
			if ( isset( $_POST[ $flosc_field ] ) && ! is_string( $_POST[ $flosc_field ] ) ) {
				$this->flosc_redirect_notice( $this->flosc_admin_settings_url( $ivr, 'chat-logs' ), 'Feedback needs a user message and a note.', 'error' );
			}
		}
		$item = array(
			'id'                 => uniqid( 'corr_' ),
			'timestamp'          => current_time( 'mysql' ),
			'user_message'       => ( isset( $_POST['feedback_user_message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['feedback_user_message'] ) ) : '' ),
			'bad_response'       => ( isset( $_POST['feedback_bad_response'] ) ? sanitize_textarea_field( wp_unslash( $_POST['feedback_bad_response'] ) ) : '' ),
			'admin_note'         => ( isset( $_POST['feedback_admin_note'] ) ? sanitize_textarea_field( wp_unslash( $_POST['feedback_admin_note'] ) ) : '' ),
			'preferred_response' => ( isset( $_POST['feedback_preferred_response'] ) ? sanitize_textarea_field( wp_unslash( $_POST['feedback_preferred_response'] ) ) : '' ),
			'admin_user_id'      => get_current_user_id(),
		);
		if ( '' === $item['user_message'] || '' === $item['admin_note'] ) {
			$this->flosc_redirect_notice( $this->flosc_admin_settings_url( $ivr, 'chat-logs' ), 'Feedback needs a user message and a note.', 'error' );
		}
		$items                   = isset( $settings['ai_feedback'] ) && is_array( $settings['ai_feedback'] ) ? $settings['ai_feedback'] : array();
		$items[]                 = $item;
		$settings['ai_feedback'] = $items;
		update_option( $key, $settings );
		$this->flosc_redirect_notice( $this->flosc_admin_settings_url( $ivr, 'chat-logs' ), 'Feedback added. The AI will follow this guidance on next response.' );
	}

	/**
	 * Delete one manual AI praise row.
	 *
	 * @return void
	 */
	public function handle_delete_praise() {
		check_admin_referer( 'flosc_save_settings' );
		if ( ! current_user_can( 'edit_others_posts' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'flosc' ), '', array( 'response' => 403 ) );
		}
		$posted_ivr                   = ( isset( $_GET['ivr'] ) && is_string( $_GET['ivr'] ) ) ? sanitize_file_name( wp_unslash( $_GET['ivr'] ) ) : '';
		list( $ivr, $key, $settings ) = $this->flosc_posted_flow_settings( $posted_ivr );
		foreach ( array( 'flosc_delete_praise' ) as $flosc_field ) {
			if ( isset( $_POST[ $flosc_field ] ) && ! is_string( $_POST[ $flosc_field ] ) ) {
				$this->flosc_redirect_notice( $this->flosc_admin_settings_url( $ivr, 'chat-logs' ), 'Praise was not deleted.', 'error' );
			}
		}
		$delete_id              = isset( $_POST['flosc_delete_praise'] ) ? sanitize_text_field( wp_unslash( $_POST['flosc_delete_praise'] ) ) : '';
		$items                  = isset( $settings['ai_praises'] ) && is_array( $settings['ai_praises'] ) ? $settings['ai_praises'] : array();
		$settings['ai_praises'] = array_values(
			array_filter(
				$items,
				static function ( $item ) use ( $delete_id ) {
					return ( $item['id'] ?? '' ) !== $delete_id;
				}
			)
		);
		update_option( $key, $settings );
		$this->flosc_redirect_notice( $this->flosc_admin_settings_url( $ivr, 'chat-logs' ), 'Praise deleted.' );
	}

	/**
	 * Add one manual AI praise row.
	 *
	 * @return void
	 */
	public function handle_add_praise() {
		check_admin_referer( 'flosc_save_settings' );
		if ( ! current_user_can( 'edit_others_posts' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'flosc' ), '', array( 'response' => 403 ) );
		}
		$posted_ivr                   = ( isset( $_GET['ivr'] ) && is_string( $_GET['ivr'] ) ) ? sanitize_file_name( wp_unslash( $_GET['ivr'] ) ) : '';
		list( $ivr, $key, $settings ) = $this->flosc_posted_flow_settings( $posted_ivr );
		foreach ( array( 'praise_user_message', 'praise_good_response', 'praise_admin_note' ) as $flosc_field ) {
			if ( isset( $_POST[ $flosc_field ] ) && ! is_string( $_POST[ $flosc_field ] ) ) {
				$this->flosc_redirect_notice( $this->flosc_admin_settings_url( $ivr, 'chat-logs' ), 'Praise needs a user message and a note.', 'error' );
			}
		}
		$item = array(
			'id'            => uniqid( 'praise_' ),
			'timestamp'     => current_time( 'mysql' ),
			'user_message'  => ( isset( $_POST['praise_user_message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['praise_user_message'] ) ) : '' ),
			'good_response' => ( isset( $_POST['praise_good_response'] ) ? sanitize_textarea_field( wp_unslash( $_POST['praise_good_response'] ) ) : '' ),
			'admin_note'    => ( isset( $_POST['praise_admin_note'] ) ? sanitize_textarea_field( wp_unslash( $_POST['praise_admin_note'] ) ) : '' ),
			'admin_user_id' => get_current_user_id(),
		);
		if ( '' === $item['user_message'] || '' === $item['admin_note'] ) {
			$this->flosc_redirect_notice( $this->flosc_admin_settings_url( $ivr, 'chat-logs' ), 'Praise needs a user message and a note.', 'error' );
		}
		$items                  = isset( $settings['ai_praises'] ) && is_array( $settings['ai_praises'] ) ? $settings['ai_praises'] : array();
		$items[]                = $item;
		$settings['ai_praises'] = $items;
		update_option( $key, $settings );
		$this->flosc_redirect_notice( $this->flosc_admin_settings_url( $ivr, 'chat-logs' ), 'Praise added. The AI will reinforce this behavior.' );
	}

	/**
	 * Reset one flow's chat style fields.
	 *
	 * @return void
	 */
	public function handle_reset_chat_style() {
		check_admin_referer( 'flosc_reset_chat_style_nonce', 'flosc_reset_chat_style_nonce' );
		if ( ! current_user_can( 'edit_others_posts' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'flosc' ), '', array( 'response' => 403 ) );
		}
		$posted_ivr                   = ( isset( $_GET['ivr'] ) && is_string( $_GET['ivr'] ) ) ? sanitize_file_name( wp_unslash( $_GET['ivr'] ) ) : '';
		list( $ivr, $key, $settings ) = $this->flosc_posted_flow_settings( $posted_ivr );
		unset( $settings['chat_style_preset'], $settings['chat_style_bubble'], $settings['chat_style_accent'], $settings['chat_style_font'], $settings['chat_style_scale'] );
		update_option( $key, $settings );
		$this->flosc_redirect_notice( $this->flosc_admin_settings_url( $ivr, 'style' ), 'Chat styling reset to defaults.' );
	}

	/**
	 * Build only the flow fields owned by the submitted editor tab.
	 *
	 * An existing flow receives a key only when this form posted it. A new flow
	 * receives the complete default structure.
	 *
	 * @param array $post   Editor fields read and sanitized by handle_save_flow_record().
	 * @param bool  $is_new Whether a new flow is being created.
	 * @return array Flow fields safe to pass to create_flow() or update_flow().
	 */
	private function flosc_flow_record_data( $post, $is_new ) {
		$data = array();

		if ( $is_new || isset( $post['flow_slug'] ) || isset( $post['floscflow_name'] ) || isset( $post['flow_status'] ) || isset( $post['flow_domain'] ) ) {
			$data['slug']          = sanitize_title( (string) ( $post['flow_slug'] ?? '' ) );
			$data['custom_domain'] = sanitize_text_field( (string) ( $post['flow_domain'] ?? '' ) );
			$data['status']        = sanitize_key( (string) ( $post['flow_status'] ?? 'draft' ) );
			$data['identity']      = array(
				'name'          => sanitize_text_field( (string) ( $post['floscflow_name'] ?? '' ) ),
				'title'         => sanitize_text_field( (string) ( $post['floscflow_title'] ?? '' ) ),
				'tagline'       => sanitize_text_field( (string) ( $post['floscflow_tagline'] ?? '' ) ),
				'chatlogo_url'  => esc_url_raw( (string) ( $post['floscflow_chatlogo'] ?? '' ) ),
				'favicon_url'   => esc_url_raw( (string) ( $post['floscflow_favicon'] ?? '' ) ),
				'badgeUrl'      => esc_url_raw( (string) ( $post['floscflow_badge'] ?? '' ) ),
				'primary_color' => sanitize_hex_color( (string) ( $post['floscflow_color'] ?? '#4f46e5' ) ),
				'share_text'    => sanitize_text_field( (string) ( $post['floscflow_share_text'] ?? '' ) ),
			);
		}
		if ( $is_new || isset( $post['ivr_file'] ) ) {
			$data['ivr_file'] = sanitize_file_name( (string) ( $post['ivr_file'] ?? 'flosc_default_technical_ivr.md' ) );
		}
		if ( $is_new || isset( $post['wp_category'] ) ) {
			$data['wp_category_id'] = intval( $post['wp_category'] ?? 0 );
		}
		if ( $is_new || isset( $post['quiz_type'] ) ) {
			$data['quiz_type'] = sanitize_key( (string) ( $post['quiz_type'] ?? '' ) );
		}

		return $data;
	}

	/**
	 * Create or update a flow from the flow editor.
	 *
	 * @return void
	 */
	public function handle_save_flow_record() {
		check_admin_referer( 'flosc_save_flow_record' );
		$flow_id = '';
		if ( isset( $_POST['flow_id'] ) ) {
			if ( ! is_string( $_POST['flow_id'] ) && ! is_numeric( $_POST['flow_id'] ) ) {
				wp_die( esc_html__( 'The flow was not saved. The flow id arrived as a list, so the stored flow was left unchanged.', 'flosc' ), '', array( 'response' => 400 ) );
			}
			$flow_id = sanitize_key( wp_unslash( $_POST['flow_id'] ) );
		}
		$is_new = ( 'new' === $flow_id );
		if ( $is_new && ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Only administrators can create new flows.', 'flosc' ), '', array( 'response' => 403 ) );
		}
		if ( ! $is_new && ( ! function_exists( 'flosc_flows' ) || ! flosc_flows()->can_access_flow_admin( $flow_id ) ) ) {
			wp_die( esc_html__( 'You do not have permission to edit this flow.', 'flosc' ), '', array( 'response' => 403 ) );
		}
		$tab = ( isset( $_POST['flosc_return_tab'] ) && is_string( $_POST['flosc_return_tab'] ) )
			? sanitize_key( wp_unslash( $_POST['flosc_return_tab'] ) )
			: 'identity';
		if ( '' === $tab ) {
			$tab = 'identity';
		}

		/*
		 * Every editor field is read on its own and sanitized at the read, with
		 * the same core function flosc_flow_record_data() applies when it builds
		 * the stored record. A field that arrives as a list is refused below
		 * and the stored flow is left unchanged.
		 */
		$flosc_record_text_keys = array(
			'flosc_return_tab',
			'flow_slug',
			'flow_domain',
			'flow_status',
			'floscflow_name',
			'floscflow_title',
			'floscflow_tagline',
			'floscflow_chatlogo',
			'floscflow_favicon',
			'floscflow_badge',
			'floscflow_color',
			'floscflow_share_text',
			'ivr_file',
			'wp_category',
			'quiz_type',
			'visitor_bar_text',
			'visitor_bar_icon',
		);
		$flosc_record_ok        = true;
		foreach ( $flosc_record_text_keys as $flosc_field ) {
			if ( isset( $_POST[ $flosc_field ] ) && ! is_string( $_POST[ $flosc_field ] ) ) {
				$flosc_record_ok = false;
			}
		}

		$post = array();
		if ( $flosc_record_ok ) {
			if ( isset( $_POST['flow_slug'] ) ) {
				$post['flow_slug'] = sanitize_title( wp_unslash( $_POST['flow_slug'] ) );
			}
			if ( isset( $_POST['flow_domain'] ) ) {
				$post['flow_domain'] = sanitize_text_field( wp_unslash( $_POST['flow_domain'] ) );
			}
			if ( isset( $_POST['flow_status'] ) ) {
				$post['flow_status'] = sanitize_key( wp_unslash( $_POST['flow_status'] ) );
			}
			foreach ( array( 'floscflow_name', 'floscflow_title', 'floscflow_tagline', 'floscflow_share_text', 'floscflow_color', 'wp_category', 'visitor_bar_text', 'visitor_bar_icon' ) as $flosc_field ) {
				if ( isset( $_POST[ $flosc_field ] ) ) {
					$post[ $flosc_field ] = sanitize_text_field( wp_unslash( $_POST[ $flosc_field ] ) );
				}
			}
			foreach ( array( 'floscflow_chatlogo', 'floscflow_favicon', 'floscflow_badge' ) as $flosc_field ) {
				if ( isset( $_POST[ $flosc_field ] ) ) {
					$post[ $flosc_field ] = esc_url_raw( wp_unslash( $_POST[ $flosc_field ] ) );
				}
			}
			if ( isset( $_POST['ivr_file'] ) && is_string( $_POST['ivr_file'] ) ) {
				$post['ivr_file'] = sanitize_file_name( wp_unslash( $_POST['ivr_file'] ) );
			}
			if ( isset( $_POST['quiz_type'] ) ) {
				$post['quiz_type'] = sanitize_key( wp_unslash( $_POST['quiz_type'] ) );
			}
		}

		// The visitor menu is a list of rows, each with a label and an on/off
		// value. A row that is not a list, or a label that is not text, refuses
		// the save.
		if ( $flosc_record_ok && isset( $_POST['visitor_menu_items'] ) ) {
			if ( ! is_array( $_POST['visitor_menu_items'] ) ) {
				$flosc_record_ok = false;
			} else {
				// map_deep() sanitizes every leaf and leaves the nesting as it
				// arrived, so the shape can be checked on the sanitized copy.
				$flosc_menu_rows = map_deep( wp_unslash( $_POST['visitor_menu_items'] ), 'sanitize_text_field' );
				foreach ( $flosc_menu_rows as $flosc_menu_item ) {
					if ( ! is_array( $flosc_menu_item ) ) {
						$flosc_record_ok = false;
						break;
					}
					foreach ( array( 'label', 'enabled' ) as $flosc_menu_field ) {
						if ( isset( $flosc_menu_item[ $flosc_menu_field ] ) && ! is_string( $flosc_menu_item[ $flosc_menu_field ] ) ) {
							$flosc_record_ok = false;
							break 2;
						}
					}
				}
				if ( $flosc_record_ok ) {
					$post['visitor_menu_items'] = $flosc_menu_rows;
				}
			}
		}
		if ( ! $flosc_record_ok ) {
			$this->flosc_redirect_notice(
				add_query_arg(
					array(
						'page'    => 'flosc-flow-edit',
						'flow_id' => $is_new ? 'new' : $flow_id,
						'tab'     => $tab,
					),
					admin_url( 'admin.php' )
				),
				__( 'The flow was not saved. One of its fields arrived as a list, so the stored flow was left unchanged.', 'flosc' ),
				'error'
			);
		}

		if ( current_user_can( 'manage_options' ) && ( isset( $post['visitor_bar_text'] ) || isset( $post['visitor_bar_icon'] ) ) ) {
			$profile_bar = get_option( 'flosc_profile_bar', array() );
			if ( ! is_array( $profile_bar ) ) {
				$profile_bar = array();
			}
			if ( isset( $post['visitor_bar_text'] ) ) {
				$profile_bar['visitor']['badge'] = sanitize_text_field( (string) $post['visitor_bar_text'] );
			}
			if ( isset( $post['visitor_bar_icon'] ) ) {
				$profile_bar['visitor']['icon'] = sanitize_text_field( (string) $post['visitor_bar_icon'] );
			}
			update_option( 'flosc_profile_bar', $profile_bar );
		}

		if ( current_user_can( 'manage_options' ) && isset( $post['visitor_menu_items'] ) && is_array( $post['visitor_menu_items'] ) ) {
			$menu_post  = $post['visitor_menu_items'];
			$menu_items = array();
			foreach ( $menu_post as $menu_key => $menu_item ) {
				$menu_item               = is_array( $menu_item ) ? $menu_item : array();
				$menu_items[ $menu_key ] = array(
					'label'   => sanitize_text_field( (string) ( $menu_item['label'] ?? '' ) ),
					'enabled' => isset( $menu_item['enabled'] ) && '1' === $menu_item['enabled'],
				);
			}
			update_option( 'flosc_visitor_menu_items', $menu_items );
		}

		$data   = $this->flosc_flow_record_data( $post, $is_new );
		$return = add_query_arg(
			array(
				'page'    => 'flosc-flow-edit',
				'flow_id' => $is_new ? 'new' : $flow_id,
				'tab'     => $tab,
			),
			admin_url( 'admin.php' )
		);

		if ( ! $is_new && array() === $data ) {
			wp_safe_redirect( $return );
			exit;
		}

		if ( $is_new ) {
			$data['id'] = '' !== $data['slug'] ? sanitize_key( $data['slug'] ) : 'flow_' . wp_generate_password( 6, false, false );
			$result     = flosc_flows()->create_flow( $data );
			if ( is_wp_error( $result ) ) {
				$this->flosc_redirect_notice( $return, $result->get_error_message(), 'error' );
			}
			wp_safe_redirect( admin_url( 'admin.php?page=flosc-flows&saved=1' ) );
			exit;
		}

		$result = flosc_flows()->update_flow( $flow_id, $data );
		if ( is_wp_error( $result ) ) {
			$this->flosc_redirect_notice( $return, $result->get_error_message(), 'error' );
		}
		$this->flosc_redirect_notice( $return, 'Flow updated successfully.' );
	}

	/**
	 * Replace the editors assigned to one flow.
	 *
	 * @return void
	 */
	public function handle_update_flow_team() {
		check_admin_referer( 'flosc_update_flow_team' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Only administrators can update a flow team.', 'flosc' ), '', array( 'response' => 403 ) );
		}
		if ( isset( $_POST['flow_id'] ) && ! is_string( $_POST['flow_id'] ) ) {
			wp_die( esc_html__( 'You do not have permission to edit this flow.', 'flosc' ), '', array( 'response' => 403 ) );
		}
		// team_users is a flat list of user ids, never one value and never a
		// nested list.
		$selected = array();
		if ( isset( $_POST['team_users'] ) ) {
			if ( ! is_array( $_POST['team_users'] ) ) {
				wp_die( esc_html__( 'You do not have permission to edit this flow.', 'flosc' ), '', array( 'response' => 403 ) );
			}
			$flosc_team_users = map_deep( wp_unslash( $_POST['team_users'] ), 'absint' );
			foreach ( $flosc_team_users as $flosc_team_user ) {
				if ( is_array( $flosc_team_user ) ) {
					wp_die( esc_html__( 'You do not have permission to edit this flow.', 'flosc' ), '', array( 'response' => 403 ) );
				}
			}
			$selected = array_map( 'intval', $flosc_team_users );
		}
		$flow_id = isset( $_POST['flow_id'] ) ? sanitize_key( wp_unslash( $_POST['flow_id'] ) ) : '';
		if ( '' === $flow_id || 'new' === $flow_id || ! function_exists( 'flosc_flows' ) ) {
			wp_die( esc_html__( 'You do not have permission to edit this flow.', 'flosc' ), '', array( 'response' => 403 ) );
		}
		$current     = flosc_flows()->get_flow_users( $flow_id );
		$current_ids = array();
		foreach ( $current as $user ) {
			$current_ids[] = (int) $user->ID;
		}
		$selected_ids = array_map( 'intval', $selected );
		foreach ( $current_ids as $user_id ) {
			if ( ! in_array( (int) $user_id, $selected_ids, true ) ) {
				flosc_flows()->revoke_flow_access( $user_id, $flow_id );
			}
		}
		foreach ( $selected as $user_id ) {
			if ( ! in_array( (int) $user_id, $current_ids, true ) ) {
				flosc_flows()->grant_flow_access( $user_id, $flow_id );
			}
		}
		$this->flosc_redirect_notice(
			add_query_arg(
				array(
					'page'    => 'flosc-flow-edit',
					'flow_id' => $flow_id,
					'tab'     => 'team',
				),
				admin_url( 'admin.php' )
			),
			'Team updated successfully.'
		);
	}

	/**
	 * Delete one flow from the flows list.
	 *
	 * @return void
	 */
	public function handle_delete_flow() {
		check_admin_referer( 'flosc_delete_flow' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Only administrators can delete a flow.', 'flosc' ), '', array( 'response' => 403 ) );
		}
		if ( isset( $_GET['flow_id'] ) && ! is_string( $_GET['flow_id'] ) && ! is_numeric( $_GET['flow_id'] ) ) {
			$this->flosc_redirect_notice( admin_url( 'admin.php?page=flosc-flows' ), 'That flow could not be deleted.', 'error' );
		}
		$flow_id = isset( $_GET['flow_id'] ) ? sanitize_key( wp_unslash( $_GET['flow_id'] ) ) : '';
		$result  = flosc_flows()->delete_flow( $flow_id );
		if ( is_wp_error( $result ) ) {
			$this->flosc_redirect_notice( admin_url( 'admin.php?page=flosc-flows' ), $result->get_error_message(), 'error' );
		}
		wp_safe_redirect( admin_url( 'admin.php?page=flosc-flows&deleted=1' ) );
		exit;
	}
}
